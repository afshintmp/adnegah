<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width , initial-scale=1">
    <title><?php bloginfo('name'); ?> | <?php is_front_page() ? bloginfo('description') : wp_title(''); ?></title>
    <link rel="stylesheet" href="<?php echo DU . "/assets/css/bootstrap.css"?>">
    <link rel="stylesheet" href="<?php echo DU . "/assets/css/swiper/swiper.min.css"?>">
    <link rel="stylesheet" href="<?php echo DU . "/assets/css/Select2/select2.min.css"?>">
    <link rel="stylesheet" href="<?php echo DU . "/assets/css/aos/aos.css"?>">
    <link rel="stylesheet" href="<?php echo DU . "/assets/css/style.css"?>">
    <link rel="stylesheet" href="<?php echo DU . "/assets/css/edit-css.css"?>">
    <?php wp_head(); ?>
</head>