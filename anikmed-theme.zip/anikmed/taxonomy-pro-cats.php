<?php
get_header();
$my_ob = get_queried_object();
?>

<body>

<?php get_template_part("partials/top-bar-menu") ?>
<!--START-CHANGE-->
<div class="loading">
    <div class="detail">
        <img src="<?php echo DU . '/assets/img/Logo 1-0۱.png' ?>" alt="">
        <span class="text">
            لطفا کمی صبر کنید ...
        </span>
        <svg class="spinner" width="35px" height="35px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
            <circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle>
        </svg>
    </div>
</div>
<!--END-CHANGE-->
<!--START-MAIN-->
<main>
    <?php get_template_part('partials/bread-crump-texonomy') ?>

    <!--START-PRODUCTS-->
    <div class="products archive-theme">
        <div class="container">
            <div class="filter-bar" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="0" data-aos-once="true">
                <form action="">
                    <div class="row prl-10px">
                        <div class="col-lg-6 col-12 prl-5px">
                            <div class="form-group">
                                <input onkeyup="proSearch()" id="search-val" type="text"
                                       placeholder="جستجو را همین حالا شروع کنید  . . .">
                                <i class="icon-search absolute-icon"></i>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6 prl-5px">
                            <?php
                            $taxonomy = get_terms(array(
                                'taxonomy' => 'pro-cats',
                                'hide_empty' => false,
                            ));

                            ?>
                            <div class="form-group has-icon">

                                <select class="js-example-basic-single" id="select-val" name="state"
                                        onChange="proTaxonomy(this.selectedIndex)">
                                    <option value="0">
                                        همه
                                    </option>
                                    <?php foreach ($taxonomy as $tax) : ?>
                                        <option <?php echo $tax->term_id == $my_ob->term_id ? "selected" : '' ?>
                                                value="<?php echo $tax->term_id ?>">
                                            <?php echo $tax->name ?>
                                        </option>
                                    <?php endforeach; ?>

                                </select>
                                <i class="icon-menu absolute-icon right-theme"></i>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
            <div class="row prl-5px" id="product-ajax">
                <?php

                $args = array(
                    'post_type' => 'product',
                    'posts_per_page' => 9,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'pro-cats',
                            'terms' => $my_ob->term_id,
                        ),
                    ),
                );

                $the_query = new WP_Query($args);


                if ($the_query->have_posts()) {

                    while ($the_query->have_posts()) {
                        $the_query->the_post();
                        ?>
                        <div class="col-lg-4 col-sm-6 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                             data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                            <div class="item">
                                <div class="bg">
                                    <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id(get_the_ID())) ?>"
                                         alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">

                                    <div class="name morabba">
                                        <?php echo get_the_title() ?>
                                    </div>
                                    <?php $pro_category = get_the_terms(get_the_ID(), "pro-cats");

                                    if ($pro_category) :
                                        ?>
                                        <div class="subtitle">
                                            <?php echo $pro_category[0]->name ?>

                                        </div>
                                    <?php endif; ?>

                                    <a href="<?php echo get_the_permalink() ?>" class="more">
                                        مشاهده جزئیات
                                        <i class="icon-1-left-circle"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="col-12 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                         data-aos-duration="1000"
                         data-aos-delay="200" data-aos-once="true">
                        <style>
                            .active-it {
                                background-color: #208370 !important;
                                color: #ffffff !important;
                            }
                        </style>

                        <ul class="nav nav-pagination">

                            <?php $post_count = $the_query->found_posts;
                            $pageintion = (ceil($post_count / 9)); ?>
                            <?php for ($c = 1; $c <= $pageintion; $c++) : ?>
                                <li class="nav-item">
                                    <a onclick="pageSet(<?php echo $c ?> , '<?php echo $my_ob->term_id ?>' , '' ,this)"
                                       class="nav-link  <?php echo $c == 1 ? " active-it" : ' ' ?>">
                                        <?php echo $c ?>
                                    </a>
                                </li>
                            <?php endfor; ?>


                        </ul>
                    </div>
                    <?php
                } else {

                }

                wp_reset_postdata();


                ?>


            </div>
        </div>
    </div>
    <!--END-PRODUCTS-->


</main>
<!--END-MAIN-->

<?php get_footer() ?>
</body>
</html>
