<?php
define("DU", get_template_directory_uri());
define("DP", get_template_directory());

add_theme_support('post-thumbnails');
add_theme_support('title-tag');

add_filter('nav_menu_link_attributes', 'add_link_atts');
add_filter('nav_menu_css_class', 'atg_menu_classes', 1, 3);
add_action('init', 'jobfinder_custom_posttype');
add_action('admin_print_scripts', 'jobfinder_admin_scripts');
add_action('wp_enqueue_scripts', 'jobfinder_enqueue_assets');
add_action('admin_menu', 'jobfinder_register_menu_setting_page');
add_action('add_meta_boxes', 'jobfinder_register_meta_box');
add_action('save_post', 'jobfinder_post_time_save');
add_action('init', 'jobfinder_create_taxonomy', 0);
add_action('add_meta_boxes', 'jobfinder_register_meta_box');
add_action('save_post', 'jobfinder_product_meta_box_save');


add_filter('comment_form_defaults', 'my_comment_title', 20);
remove_action('set_comment_cookies', 'wp_set_comment_cookies');
if (!function_exists('jobfinder_register_nav_menu')) {

    function jobfinder_register_nav_menu()
    {
        register_nav_menus(array(
            'top_bar_menu' => __('Top Bar Menu', 'jobfinder'),
            'category_menu' => __('Category Menu', 'jobfinder'),
            'footer_menu' => __('Footer Menu', 'jobfinder'),
            'footer_link_menu' => __('Footer Link Menu', 'jobfinder'),
        ));
    }

    add_action('after_setup_theme', 'jobfinder_register_nav_menu', 0);
}

function jobfinder_enqueue_assets()
{

    wp_enqueue_script('jobfinder-bootstrap-js', DU . "/assets/js/Bootstrap/bootstrap.bundle.min.js",
        array('jquery'), '5.0.2', true);
    wp_enqueue_script('jobfinder-swiper-js', DU . "/assets/js/swiper/swiper.min.js",
        array('jquery'), '1.0', true);
    wp_enqueue_script('jobfinder-select2-js', DU . "/assets/js/Select2/select2.min.js",
        array('jquery'), '1.0', true);
    wp_enqueue_script('jobfinder-aos-js', DU . "/assets/js/aos/aos.js",
        array('jquery'), '1.0', true);
    wp_enqueue_script('jobfinder-custom-js', DU . "/assets/js/custom.js",
        array('jquery'), '1.0', true);

    wp_enqueue_script('ajax-js', DU . '/assets/js/ajax-js.js', array('jquery'), "1.1", true);
    wp_localize_script('ajax-js', 'ajax_obj', array('ajax_url' => admin_url('admin-ajax.php')));

}

function atg_menu_classes($classes, $item, $args)
{

    $classes[] = 'nav-item';

    return $classes;
}

function add_link_atts($atts)
{

    $atts['class'] = "nav-link";

    return $atts;
}

function jobfinder_register_meta_box()
{
    $our_teams = ['post'];


    foreach ($our_teams as $our_team) {

        add_meta_box(
            'post-time-read',
            'زمان مطالعه',
            'jobfinder_post_time_html',
            $our_team
        );
    }
    $product = ['product'];


    foreach ($product as $pro) {
        add_meta_box(
            'jobfinder_our_team_email',
            'info',
            'jobfinder_product_meta_box_html',
            $product
        );
    }


}

function jobfinder_product_meta_box_html($post)
{
    $jobfinder_no = get_post_meta($post->ID, 'jobfinder-no', true);
    $jobfinder_vazn = get_post_meta($post->ID, 'jobfinder-vazn', true);
    $jobfinder_size = get_post_meta($post->ID, 'jobfinder-size', true);
    $jobfinder_karbar = get_post_meta($post->ID, 'jobfinder-karbar', true);
    $jobfinder_hamrah = get_post_meta($post->ID, 'jobfinder-hamrah', true);
    $jobfinder_selected = get_post_meta($post->ID, 'jobfinder-selected', true);

    ?>
    <style>
        .w-100 {
            width: 100%;
        }
    </style>
    <p style="width : calc( 33% - 10px);display: inline-block">
        <label for="">نوع :</label>
        <input id="" name="jobfinder-no" class="w-100" type="text"
               value="<?php echo $jobfinder_no ?>">
    </p>
    <p style="width : calc( 33% - 10px);display: inline-block">
        <label for="">وزن :</label>
        <input type="text" name="jobfinder-vazn" class="w-100"
               value="<?php echo $jobfinder_vazn ?>">
    </p>
    <p style="width : calc( 33% - 10px);display: inline-block;text-align: center">

        <input type="checkbox" id="jobfinder-selected" name="jobfinder-selected" class="w-100"
               value="on" <?php echo $jobfinder_selected == "on" ? "checked" : "" ?>>
        <label for="jobfinder-selected">محصول منتخب </label>
    </p>
    <p style="width : calc( 50% - 10px);display: inline-block">
        <label for="">سایز :</label>
        <input name="jobfinder-size" class="w-100" type="text"
               value="<?php echo $jobfinder_size ?>">
    </p>
    <p style="width : calc( 50% - 10px);display: inline-block">
        <label for="">کاربری :</label>
        <input type="text" name="jobfinder-karbar" id="" class="w-100"
               value="<?php echo $jobfinder_karbar ?>">
    </p>
    <p style="width : 100%;display: inline-block">
        <label for="">اقلام همراه :</label>
        <input id="" name="jobfinder-hamrah" class="w-100" type="text"
               value="<?php echo $jobfinder_hamrah ?>">
    </p>

    <?php

}

function jobfinder_product_meta_box_save($post_id)
{
    if (array_key_exists('jobfinder-no', $_POST)) {
        update_post_meta($post_id, 'jobfinder-no', $_POST['jobfinder-no']);
    }
    if (array_key_exists('jobfinder-vazn', $_POST)) {
        update_post_meta($post_id, 'jobfinder-vazn', $_POST['jobfinder-vazn']);
    }
    if (array_key_exists('jobfinder-size', $_POST)) {
        update_post_meta($post_id, 'jobfinder-size', $_POST['jobfinder-size']);
    }
    if (array_key_exists('jobfinder-karbar', $_POST)) {
        update_post_meta($post_id, 'jobfinder-karbar', $_POST['jobfinder-karbar']);
    }
    if (array_key_exists('jobfinder-hamrah', $_POST)) {
        update_post_meta($post_id, 'jobfinder-hamrah', $_POST['jobfinder-hamrah']);
    }

    update_post_meta($post_id, 'jobfinder-selected', $_POST['jobfinder-selected']);


}

function jobfinder_post_time_html($post)
{
    $jobfinder_post_time = get_post_meta($post->ID, 'jobfinder-post-time', true);
    ?>
    <p>
        <label for="time">زمان :</label>
        <input id="time" type="url" name="post-read-time" value="<?php echo $jobfinder_post_time ?>">
        <span>(دقیقه)</span>
    </p>
    <?php

}

function jobfinder_post_time_save($post_id)
{
    if (array_key_exists('post-read-time', $_POST)) {
        update_post_meta($post_id, 'jobfinder-post-time', $_POST['post-read-time']);
    }

}

function my_comment_title($defaults)
{
    $defaults['title_reply'] = "";
    return $defaults;
}

function jobfinder_register_menu_setting_page()
{

    add_menu_page(
        __('تنظیمات قالب', 'jobfinder'),
        'تنظیمات قالب',
        'manage_options',
        'jobfinder-menu-setting',
        'jobfinder_menu_setting_page'


    );
    add_menu_page('تنظیمات اسلایدر',
        'تنظیمات اسلایدر',
        'manage_options',
        'slider-setting',
        'jobfinder_slider_setting_page'


    );
}

function jobfinder_menu_setting_page()
{
    require_once DP . '/partials/admin/menu-setting.php';
}

function jobfinder_slider_setting_page()
{
    require_once DP . '/partials/admin/slider-setting.php';
}

function jobfinder_admin_scripts()
{

    wp_enqueue_script('jquery');
    wp_enqueue_script('media-upload');
    wp_enqueue_media();
    wp_enqueue_script('thickbox');

}

function jobfinder_custom_posttype()
{


    $product_labels = array(
        'name' => "محصولات",
        'singular_name' => "محصولات",
        'menu_name' => "محصولات",
        'parent_item_colon' => "والد",
        'all_items' => "محصولات",
        'view_item' => "مشاهده",
        'add_new_item' => "افزودن جدید",
        'add_new' => "افزودن",
        'edit_item' => "ویرایش",
        'update_item' => "بروز رسانی",
        'search_items' => "جستجو",
        'not_found' => "موردی یافت نشد",
        'not_found_in_trash' => "موردی یافت نشد",
    );
    $product_args = array(
        'label' => "محصولات",
        'description' => "",
        'labels' => $product_labels,
        'supports' => array('title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions',),

        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => true,

    );
    register_post_type('product', $product_args);
    $company_labels = array(
        'name' => "مشتریان ما",
        'singular_name' => "مشتریان ما",
        'menu_name' => "مشتریان ما",
        'parent_item_colon' => "والد",
        'all_items' => "همه",
        'view_item' => "مشاهده",
        'add_new_item' => "افزودن",
        'add_new' => "افزودن",
        'edit_item' => "ویرایش",
        'update_item' => "بروزرسانی",
        'search_items' => "جستجو",
        'not_found' => "موردی یافت نشد",
        'not_found_in_trash' => "موردی یافت نشد",
    );
    $company_args = array(
        'label' => "مشتریان ما",
        'description' => "مشتریان ما",
        'labels' => $company_labels,
        'supports' => array('title', 'thumbnail',),

        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => true,

    );
    register_post_type('companies', $company_args);
}

function jobfinder_create_taxonomy()
{


    $labels = array(
        'name' => "دسته بندی ها",
        'singular_name' => "دسته بندی ها",
        'search_items' => "جستجو",
        'popular_items' => "محبوب",
        'all_items' => "همه",
        'parent_item' => "والد",
        'parent_item_colon' => null,
        'edit_item' => "ویرایش",
        'update_item' => "به روزرسانی",
        'add_new_item' => "افزودن",
        'new_item_name' => "نام",
        'separate_items_with_commas' => __('Separate Time limit with commas'),
        'add_or_remove_items' => __('Add or remove Time limit'),
        'choose_from_most_used' => __('Choose from the most used Time limit'),
        'menu_name' => "دسته بندی",
    );


    register_taxonomy('pro-cats', 'product', array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var' => true,
        'rewrite' => array('slug' => 'pro-cats'),
    ));
}

require_once DP . '/partials/ajax-functions.php';
