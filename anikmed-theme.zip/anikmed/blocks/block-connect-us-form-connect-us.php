<?php global $option;
$google_map = get_option('google-map');
?>
<!--START-FORM-CONTACT-->
<div class="form-contact">
    <div class="container p-0 d-flex flex-wrap">
        <div class="col-xl-6" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
             data-aos-delay="0" data-aos-once="true">
            <div class="time-work">
                <i class="icon-clock"></i>
                <b>
                    ساعت کاری
                </b>
                <?php block_field('ti'); ?>
            </div>
            <div class="header-section right-theme">
                <div class="title">
                    <b class="morabba has-mb">
                        <?php block_field('tt'); ?>
                    </b>
                    <?php block_field('sub-tt'); ?>
                </div>
            </div>

            <?php echo do_shortcode('[contact-form-7 id="153" title="فرم تماس با ما"]'); ?>
            <!-- <div class="form-elements mb-0">
                 <div class="row prl-10px">
                     <div class="col-sm-6 prl-5px">
                         <div class="form-group">
                             <input type="text" placeholder="نام و نام خانوادگی">
                         </div>
                     </div>
                     <div class="col-sm-6 prl-5px">
                         <div class="form-group">
                             <input type="text" placeholder="شماره همراه">
                         </div>
                     </div>
                     <div class="col-xl-12 prl-5px">
                         <div class="form-group">
                             <textarea placeholder="متن پیام خود را یادداشت کنید . . ."></textarea>
                         </div>
                     </div>
                     <div class="col-12 prl-5px">
                         <button class="btn btn-submit">
                             پیام خود را ارسال کنید
                         </button>
                     </div>
                 </div>
             </div>-->
        </div>
        <div class="col-xl-6" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
             data-aos-delay="250" data-aos-once="true">
            <div class="map-section">
                <ul class="nav nav-direct">
                    <li class="nav-item">
                        <a href="" class="nav-link">
                            <i class="icon-google-maps"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link">
                            <i class="icon-waze"></i>
                        </a>
                    </li>
                </ul>

                <iframe src="<?php echo $google_map ?>"
                        width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

            </div>
        </div>
    </div>
</div>
<!--END-FORM-CONTACT-->