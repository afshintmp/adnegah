<!--START-AWARDS-->
<div class="awards" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0"
     data-aos-once="true">
    <div class="container p-0 d-flex flex-wrap align-items-center">
        <div class="col-xl-5 col-lg-6">
            <div class="header-section">
                                <span class="title morabba small-theme">
                                    <b>
                                    <?php block_field('tt'); ?>
                                    </b>
                               <?php block_field('sub-tt'); ?>
                                </span>
            </div>

            <div class="swiper-container swiper-a-thumbs">
                <div class="swiper-wrapper">
                    <!--                    c-tt-1-->
                    <?php if (!empty(block_value('c-tt-1'))) { ?>
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="<?php block_field('c-ax-1'); ?>"
                                 alt="    <?php block_field('c-alt-1'); ?>">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                <?php block_field('c-tt-1'); ?>
                            </div>
                            <p class="text">
                                <?php block_field('c-tx-1'); ?>
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                               <?php block_field('c-da-1'); ?>
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php };
                    if (!empty(block_value('c-tt-1-2'))) { ?>
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="<?php block_field('c-ax-1-2'); ?>"
                                 alt="    <?php block_field('c-alt-1-2'); ?>">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                <?php block_field('c-tt-1-2'); ?>
                            </div>
                            <p class="text">
                                <?php block_field('c-tx-1-2'); ?>
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                               <?php block_field('c-da-1-2'); ?>
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if (!empty(block_value('c-tt-1-3'))) { ?>
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="<?php block_field('c-ax-1-3'); ?>"
                                 alt="<?php block_field('c-alt-1-3'); ?>">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                <?php block_field('c-tt-1-3'); ?>
                            </div>
                            <p class="text">
                                <?php block_field('c-tx-1-3'); ?>
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                               <?php block_field('c-da-1-3'); ?>
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    if (!empty(block_value('c-tt-1-4'))) { ?>
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="<?php block_field('c-ax-1-4'); ?>"
                                 alt="<?php block_field('c-alt-1-4'); ?>">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                <?php block_field('c-tt-1-4'); ?>
                            </div>
                            <p class="text">
                                <?php block_field('c-tx-1-4'); ?>
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                               <?php block_field('c-da-1-4'); ?>
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    if (!empty(block_value('c-tt-1-5'))) { ?>
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="<?php block_field('c-ax-1-5'); ?>"
                                 alt="<?php block_field('c-alt-1-5'); ?>">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                <?php block_field('c-tt-1-5'); ?>
                            </div>
                            <p class="text">
                                <?php block_field('c-tx-1-5'); ?>
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                               <?php block_field('c-da-1-5'); ?>
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>

                </div>
            </div>

        </div>
        <div class="col-xl-7 col-lg-6 d-none d-lg-block">
            <div class="swiper-container swiper-a-sync">
                <div class="swiper-wrapper">
                    <?php
                    if (!empty(block_value('c-ax-1'))) { ?>
                        <div class="swiper-slide item">

                            <img src="<?php block_field('c-ax-1'); ?>"
                                 alt="<?php block_field('c-alt-1'); ?>">
                        </div>
                    <?php }

                    if (!empty(block_value('c-ax-1-2'))) { ?>

                        <div class="swiper-slide item">
                            <img src="<?php block_field('c-ax-1-2'); ?>"
                                 alt="<?php block_field('c-alt-1-2'); ?>">
                        </div>
                    <?php }

                    if (!empty(block_value('c-ax-1-3'))) { ?>

                        <div class="swiper-slide item">
                            <img src="<?php block_field('c-ax-1-3'); ?>"
                                 alt="<?php block_field('c-alt-1-3'); ?>">
                        </div>
                    <?php }

                    if (!empty(block_value('c-ax-1-4'))) { ?>
                        <div class="swiper-slide item">
                            <img src="<?php block_field('c-ax-1-4'); ?>"
                                 alt="<?php block_field('c-alt-1-4'); ?>">
                        </div>
                    <?php }

                    if (!empty(block_value('c-ax-1-5'))) { ?>
                        <div class="swiper-slide item">
                            <img src="<?php block_field('c-ax-1-5'); ?>"
                                 alt="<?php block_field('c-alt-1-5'); ?>">
                        </div>
                    <?php } ?>
                </div>

            </div>
        </div>
    </div>
</div>
<!--END-AWARDS-->
