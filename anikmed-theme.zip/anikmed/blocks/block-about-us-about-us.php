<!--START-ABOUT-US-->
<div class="about-us" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0"
     data-aos-once="true">
    <img class="shape" src="<?php echo DU .'/' ?>assets/img/shape-4.png" alt="">
    <div class="container p-0 d-flex flex-wrap align-items-center">
        <div class="col-xl-6 col-lg-6" data-aos="fade-left" data-aos-easing="ease-in-out" data-aos-duration="1000"
             data-aos-delay="500" data-aos-once="true">
            <div class="header-section right-theme">
                    <span class="title morabba">
                        <b class="has-mb"><?php block_field( 'tt' ); ?></b>
                        <?php block_field( 'sub-tt' ); ?>
                    </span>
            </div>
            <p class="text"><?php block_field( 'txt' ); ?>
            </p>
        </div>
        <div class="col-xl-5 col-lg-6 mr-auto" data-aos="fade-right" data-aos-easing="ease-in-out"
             data-aos-duration="1000" data-aos-delay="700" data-aos-once="true">
            <img class="img" src="<?php block_field( 'pic' ); ?>" alt="<?php block_field( 'alt' ); ?>">
        </div>
    </div>
</div>
<!--END-ABOUT-US-->
