<blockquote class="quote-box" id="t"  data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <span class="title-blog">
                    <i class="icon-quotation1"></i>

<?php block_field( 'tt' ); ?>
                </span>
    <p class="text">

        <?php block_field( 'text' ); ?>
    </p>
</blockquote>