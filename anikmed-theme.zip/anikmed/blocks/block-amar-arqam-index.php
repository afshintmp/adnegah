<!--STATUS-SECTION-->
<div class="status-section">
    <div class="container prl-5px d-flex align-items-center justify-content-between flex-wrap">
        <?php if (!empty(block_value('a-tt-1'))) { ?>

            <div class="col-md-3 col-6 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000"
                 data-aos-delay="0" data-aos-once="true">
                <div class="item">
                    <b class="morabba">
                        <?php block_field('a-tt-1'); ?>
                    </b>
                    <?php block_field('m-tt-1'); ?>
                </div>
            </div>
        <?php } ?>
        <?php if (!empty(block_value('a-tt-1-1'))) { ?>
            <div class="col-md-3 col-6 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000"
                 data-aos-delay="0" data-aos-once="true">
                <div class="item">
                    <b class="morabba">
                        <?php block_field('a-tt-1-1'); ?>
                    </b>
                    <?php block_field('m-tt-1-1'); ?>
                </div>
            </div>


        <?php } ?>
        <?php if (!empty(block_value('a-tt-1-2'))) { ?>
            <div class="col-md-3 col-6 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000"
                 data-aos-delay="0" data-aos-once="true">
                <div class="item">
                    <b class="morabba">
                        <?php block_field('a-tt-1-2'); ?>
                    </b>
                    <?php block_field('m-tt-1-2'); ?>
                </div>
            </div>


        <?php } ?>
        <?php if (!empty(block_value('a-tt-1-3'))) { ?>
            <div class="col-md-3 col-6 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000"
                 data-aos-delay="0" data-aos-once="true">
                <div class="item">
                    <b class="morabba">
                        <?php block_field('a-tt-1-3'); ?>
                    </b>
                    <?php block_field('m-tt-1-3'); ?>
                </div>
            </div>


        <?php } ?>
    </div>
</div>