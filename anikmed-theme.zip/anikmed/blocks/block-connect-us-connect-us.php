<!--START-CONTACT-US-->
<div class="contact-us">
    <div class="container">
        <div class="row prl-10px">

            <div class="grid-div col-xl-2 col-lg-3 prl-5px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="400" data-aos-once="true">
                <div class="item">
                    <img src="<?php echo DU . '/assets/img/c-1.png' ?>" alt="">
                    <div>
                            <span class="title morabba">
                            شماره تماس ها
                        </span>
                        <span class="subtitle">
                            <?php block_field('ph-1'); ?>
                            <br>
                            <?php block_field('ph-2'); ?>
                        </span>
                    </div>
                </div>
            </div>

            <div class="grid-div col-xl-4 col-lg-3 prl-5px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="600" data-aos-once="true">
                <div class="item">
                    <img src="<?php echo DU . '/assets/img/c-2.png' ?>" alt="">
                    <div>
                            <span class="title morabba">
                            دفتر مرکزی
                        </span>
                        <span class="subtitle">
                                      <?php block_field('add'); ?>

                        </span>
                    </div>
                </div>
            </div>

            <div class="grid-div col-xl-3 col-lg-3 prl-5px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="800" data-aos-once="true">
                <div class="item">
                    <img src="<?php echo DU . '/assets/img/c-3.png' ?>" alt="">
                    <div>
                            <span class="title morabba">
                            پست الکترونیک
                        </span>
                        <span class="subtitle">
                                  <?php block_field('em-1'); ?>
                            <br>
                                  <?php block_field('em-2'); ?>
                        </span>
                    </div>
                </div>
            </div>
            <?php
            global $option;


            $instagram_link = get_option('instagram-link');
            $whatsapp_link = get_option('whatsapp-link');
            $telegram_link = get_option('telegram-link');
            ?>

            <?php if (!empty(block_value('scio'))) { ?>
                <div class="grid-div col-xl-3 col-lg-3 prl-5px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                     data-aos-duration="1000" data-aos-delay="1000" data-aos-once="true">
                    <div class="item">
                        <img src="<?php echo DU . '/assets/img/c-4.png' ?>" alt="">
                        <div>
                            <span class="title morabba">
                            شبکه های اجتماعی
                        </span>
                            <ul class="nav nav-social">
                                <?php if (!empty($telegram_link)): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo $telegram_link ?>" class="nav-link">
                                            <i class="icon-telegram1"></i>
                                        </a>
                                    </li>
                                <?php endif;
                                if (!empty($instagram_link)): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo $instagram_link ?>" class="nav-link">
                                            <i class="icon-instagram"></i>
                                        </a>
                                    </li>
                                <?php
                                endif;
                                if (!empty($whatsapp_link)) :
                                    ?>
                                    <li class="nav-item">
                                        <a href="<?php echo $whatsapp_link ?>" class="nav-link">
                                            <i class="icon-whatsapp"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>

                            </ul>
                        </div>
                    </div>
                </div>
            <?php }; ?>
        </div>
    </div>
</div>
<!--END-CONTACT-US-->
