<!--START-OPINION-->
<div class="opinion" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="00"
     data-aos-once="true">
    <div class="container p-0 position-relative d-flex align-items-center flex-wrap">
        <img src="<?php echo DU . '/assets/img/shape-3.png' ?>" alt="" class="shape">

        <div class="col-xl-5 col-lg-6">
            <div class="header-section" data-aos="fade-left" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="0" data-aos-once="true">
                <div class="title morabba">
                    <b>نظـــرات خریـــداران مـــا</b>
                    بــا مــا بهتریــن را تجربــه کنیــد
                </div>
            </div>
            <div class="swiper-container swiper-opinion" data-aos="fade-left" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">


                <div class="swiper-wrapper">
                    <?php if (!empty(block_value('cm-tx-1'))) { ?>
                        <div class="swiper-slide item">
                            <div class="user">

                                <img src="<?php block_field('cm-pix-1') ?>" alt="">
                                <span>

                                    <b><?php block_field('cm-tt-1') ?></b>
                                    <?php block_field('cm-st-1') ?>

                                </span>
                            </div>
                            <p class="text">
                                <?php block_field('cm-tx-1') ?>

                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                <?php block_field('cm-ra-1') ?>
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                    <?php } ?>


                    <?php if (!empty(block_value('cm-tx-1-1'))) { ?>
                        <div class="swiper-slide item">
                            <div class="user">

                                <img src="<?php block_field('cm-pix-1-1') ?>" alt="">
                                <span>

                                    <b><?php block_field('cm-tt-1-1') ?></b>
                                    <?php block_field('cm-st-1-1') ?>

                                </span>
                            </div>
                            <p class="text">
                                <?php block_field('cm-tx-1-1') ?>

                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                <?php block_field('cm-ra-1-1') ?>
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                    <?php } ?>

                    <?php if (!empty(block_value('cm-tx-1-2'))) { ?>
                        <div class="swiper-slide item">
                            <div class="user">

                                <img src="<?php block_field('cm-pix-1-2') ?>" alt="">
                                <span>

                                    <b><?php block_field('cm-tt-1-2') ?></b>
                                    <?php block_field('cm-st-1-2') ?>

                                </span>
                            </div>
                            <p class="text">
                                <?php block_field('cm-tx-1-2') ?>

                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                <?php block_field('cm-ra-1-2') ?>
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                    <?php } ?>

                    <?php if (!empty(block_value('cm-tx-1-3'))) { ?>
                        <div class="swiper-slide item">
                            <div class="user">

                                <img src="<?php block_field('cm-pix-1-3') ?>" alt="">
                                <span>

                                    <b><?php block_field('cm-tt-1-3') ?></b>
                                    <?php block_field('cm-st-1-3') ?>

                                </span>
                            </div>
                            <p class="text">
                                <?php block_field('cm-tx-1-3') ?>

                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                <?php block_field('cm-ra-1-3') ?>
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                    <?php } ?>

                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 prl-5px d-none d-lg-flex flex-wrap mr-auto">
            <div class="col-lg-6 prl-10px" data-aos="fade-right" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="600" data-aos-once="true">
                <div class="img">
                    <img src="<?php block_field('back-1'); ?>" alt="<?php block_field('alt-1'); ?>">
                </div>
            </div>
            <div class="col-lg-6 prl-10px" data-aos="fade-right" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="700" data-aos-once="true">
                <div class="img has-mt">
                    <img src="<?php block_field('back-2'); ?>" alt="<?php block_field('alt-2'); ?>">
                </div>
            </div>
        </div>
    </div>
</div>
<!--END-OPINION-->