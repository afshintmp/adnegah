<!--START-VIDEO-SECTION-->
<div class="video-section">
    <div class="container">
        <!--START-CHANGE-->
        <div class="main" data-aos="zoom-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
            <div class="img play-vid" style="background-image: url(<?php block_field('cover'); ?>)" onclick="playVid1()">
                <i class="icon-youtube"></i>
                <span class="subtitle">
                         <?php block_field('tt'); ?>
                    </span>
                <span class="title morabba">
                        <?php block_field('sub-tt'); ?>
                    </span>
            </div>
            <div class="main-video">
                <video src="<?php block_field('vid'); ?>" id="video1"
                       controls
                       preload="none">
                </video>
                <div class="btn btn-close" onclick="pauseVid1()">
                    <i class="icon-close"></i>
                </div>
            </div>
        </div>
        <!--END-CHANGE-->

    </div>
</div>
<!--END-VIDEO-SECTION-->



<script>
    var vid1 = document.getElementById("video1");
    function playVid1() {vid1.play()}
    function pauseVid1() {vid1.pause()}

    jQuery('.play-vid').click( function () {
        jQuery(this).parent().find('.main-video').show();
    })
    jQuery('.main-video .btn-close').click( function () {
        jQuery(this).parent().parent().find('.main-video').hide();
    })
</script>