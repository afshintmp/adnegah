<?php global $option;
$slider_img = get_option('slider-img');
if (empty($slider_img)) {
    $slider_img = DU . '/assets/img/shape-1.png';

}
$slider_alt = get_option('slider-alt');


$sliderone = get_option('sliderone');

$slidertwo = get_option('slidertwo');
$slidertree = get_option('slidertree');
$sliderfour = get_option('sliderfour');


$s_1_b_1_1 = get_option('s-1-b-1-1');

$s_1_b_1_2 = get_option('s-1-b-1-2');
$s_1_b_2_1 = get_option('s-1-b-2-1');
$s_1_b_2_2 = get_option('s-1-b-2-2');

$s_2_b_1_1 = get_option('s-2-b-1-1');
$s_2_b_1_2 = get_option('s-2-b-1-2');
$s_2_b_2_1 = get_option('s-2-b-2-1');
$s_2_b_2_2 = get_option('s-2-b-2-2');

$s_3_b_1_1 = get_option('s-3-b-1-1');
$s_3_b_1_2 = get_option('s-3-b-1-2');
$s_3_b_2_1 = get_option('s-3-b-2-1');
$s_3_b_2_2 = get_option('s-3-b-2-2');

$s_4_b_1_1 = get_option('s-4-b-1-1');
$s_4_b_1_2 = get_option('s-4-b-1-2');
$s_4_b_2_1 = get_option('s-4-b-2-1');
$s_4_b_2_2 = get_option('s-4-b-2-2');
?>

<!--START-MAIN-SLIDE-->
<div class="main-slide">
    <div class="container p-0 position-relative">
        <div data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="600"
             data-aos-once="true">
            <img src="<?php echo $slider_img ?>" alt="<?php echo $slider_alt ?>" class="shape">
        </div>
        <div class="col-lg-6">
            <div class="swiper-container swiper-main-slide">
                <div class="swiper-wrapper">
                    <?php if (!empty($sliderone)) : ?>

                        <div class="swiper-slide">
                            <div class="slider-control morabba"  data-aos="fade-up" data-aos-easing="ease-in-out"
                                 data-aos-duration="1000"
                                 data-aos-delay="1100" data-aos-once="true">

                                <?php
                                echo $sliderone;
                                ?>
                            </div>
                            <ul class="nav mt-4" data-aos="fade-up" data-aos-easing="ease-in-out"
                                data-aos-duration="1000"
                                data-aos-delay="1100" data-aos-once="true">
                               <?php if(!empty($s_1_b_1_1)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo $s_1_b_1_2 ?>" class="nav-link bg-theme">
                                        <?php echo $s_1_b_1_1 ?>
                                    </a>
                                </li>
                                <?php endif;
                                if(!empty($s_1_b_2_1)):
                                    ?>
                                <li class="nav-item">
                                    <a href="<?php echo $s_1_b_2_2 ?>" class="nav-link">
                                        <?php echo $s_1_b_2_1 ?>
                                        <i class="icon-left-arrow"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                            <div class="d-flex" data-aos="fade-up" data-aos-easing="ease-in-out"
                                 data-aos-duration="1000" data-aos-delay="1200" data-aos-once="true">
                                <button class="btn swiper-button-prev-main-slide">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-main-slide">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($slidertwo)) : ?>


                        <div class="swiper-slide">
                            <div class="slider-control morabba"  data-aos="fade-up" data-aos-easing="ease-in-out"
                                 data-aos-duration="1000"
                                 data-aos-delay="1100" data-aos-once="true">
                                <?php echo $slidertwo ?>
                            </div>
                            <ul class="nav mt-4">
	                            <?php if(!empty($s_2_b_1_1)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo $s_2_b_1_2 ?>" class="nav-link bg-theme">
                                        <?php echo $s_2_b_1_1 ?>
                                    </a>
                                </li>
	                            <?php endif;
	                            if(!empty($s_2_b_2_1)):
	                            ?>
                                <li class="nav-item">
                                    <a href="<?php echo $s_2_b_2_2 ?>" class="nav-link">
                                        <?php echo $s_2_b_2_1 ?>
                                        <i class="icon-left-arrow"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-main-slide">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-main-slide">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($slidertree)) : ?>


                        <div class="swiper-slide">
                            <div class="slider-control morabba"  data-aos="fade-up" data-aos-easing="ease-in-out"
                                 data-aos-duration="1000"
                                 data-aos-delay="1100" data-aos-once="true">
                                <?php echo $slidertree ?>
                            </div>
                            <ul class="nav mt-4">
	                            <?php if(!empty($s_3_b_1_1)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo $s_3_b_1_2 ?>" class="nav-link bg-theme">
                                        <?php echo $s_3_b_1_1 ?>
                                    </a>
                                </li>
	                            <?php endif;
	                            if(!empty($s_3_b_2_1)):
	                            ?>
                                <li class="nav-item">
                                    <a href="<?php echo $s_3_b_2_2 ?>" class="nav-link">
                                        <?php echo $s_3_b_2_1 ?>
                                        <i class="icon-left-arrow"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-main-slide">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-main-slide">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($sliderfour)) : ?>


                        <div class="swiper-slide">
                            <div class="slider-control morabba" data-aos="fade-up" data-aos-easing="ease-in-out"
                                 data-aos-duration="1000"
                                 data-aos-delay="1100" data-aos-once="true">
                                <?php echo $sliderfour ?>
                            </div>
                            <ul class="nav mt-4">
	                            <?php if(!empty($s_4_b_1_1)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo $s_4_b_1_2 ?>" class="nav-link bg-theme">
                                        <?php echo $s_4_b_1_1 ?>
                                    </a>
                                </li>
	                            <?php endif;
	                            if(!empty($s_3_b_2_1)):
	                            ?>
                                <li class="nav-item">
                                    <a href="<?php echo $s_4_b_2_2 ?>" class="nav-link">
                                        <?php echo $s_4_b_2_1 ?>
                                        <i class="icon-left-arrow"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-main-slide">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-main-slide">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!--END-MAIN-SLIDE-->
