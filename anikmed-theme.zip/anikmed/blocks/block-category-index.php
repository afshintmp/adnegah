<!--START-OUR-PRODUCTS-->
<div class="our-products">

    <div class="container p-0 position-relative d-flex flex-wrap align-items-center justify-content-between">
        <div data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0"
             data-aos-once="true">
            <img class="shape" src="<?php echo DU . '/assets/img/shape-2.png' ?>" alt="">
        </div>
        <div class="col-xl-5 col-lg-6 prl-5px d-flex flex-wrap">
            <?php if (!empty(block_value('c-1-t'))) : ?>

                <div class="col-sm-6 prl-10px" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
                     data-aos-delay="100" data-aos-once="true">
                    <a href="<?php block_field('link-c-1') ?>" class="item h-con">
                        <img src="<?php block_field('c-1-p'); ?>" alt="<?php block_field('c-1-t'); ?>">
                        <b class="morabba">
                            <?php block_field('c-1-t'); ?>
                        </b>
                        <?php block_field('c-1-x'); ?>
                    </a>
                </div>
            <?php endif; ?>
            <?php if (!empty(block_value('c-1-t-1'))) : ?>
                <div class="col-sm-6 prl-10px" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
                     data-aos-delay="200" data-aos-once="true">
                    <a href="<?php block_field('link-c-1-1') ?>" class="item  has-m-t h-con">
                        <img src="<?php block_field('c-1-p-1'); ?>" alt="<?php block_field('c-1-t-1'); ?>">
                        <b class="morabba">
                            <?php block_field('c-1-t-1'); ?>
                        </b>
                        <?php block_field('c-1-x-1'); ?>
                    </a>
                </div>
            <?php endif; ?>
            <?php if (!empty(block_value('c-1-t-2'))) : ?>
                <div class="col-sm-6 prl-10px" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
                     data-aos-delay="300" data-aos-once="true">
                    <a href="<?php block_field('link-c-1-2') ?>" class="item h-con">
                        <img src="<?php block_field('c-1-p-2'); ?>" alt="<?php block_field('c-1-t-2'); ?>">
                        <b class="morabba">
                            <?php block_field('c-1-t-2'); ?>
                        </b>
                        <?php block_field('c-1-x-2'); ?>
                    </a>
                </div>
            <?php endif; ?>
            <?php if (!empty(block_value('c-1-t-3'))) : ?>
                <div class="col-sm-6 prl-10px" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
                     data-aos-delay="400" data-aos-once="true">
                    <a href="<?php block_field('link-c-1-3') ?>" class="item has-m-t h-con">
                        <img src="<?php block_field('c-1-p-3'); ?>" alt="<?php block_field('c-1-t-3'); ?>">
                        <b class="morabba">
                            <?php block_field('c-1-t-3'); ?>
                        </b>
                        <?php block_field('c-1-x-3'); ?>        </a>
                </div>
            <?php endif; ?>
        </div>
        <div class="col-xl-6 col-lg-6">

                <span class="title morabba" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
                      data-aos-delay="500" data-aos-once="true">
<?php block_field('tt'); ?>
                </span>
            <span class="subtitle" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
                  data-aos-delay="600" data-aos-once="true">
<?php block_field('sub-tt'); ?>
                </span>
            <div class="text" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
               data-aos-delay="700" data-aos-once="true">
                <?php block_field('txt'); ?>
            </div>
            <div data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="900"
                 data-aos-once="true">
                <a href="<?php block_field('btn-link'); ?>" class="more">
                    <?php block_field('btn-txt'); ?>
                    <i class="icon-left-arrow"></i>
                </a>
            </div>
        </div>
    </div>
</div>
<!--END-OUR-PRODUCTS-->
