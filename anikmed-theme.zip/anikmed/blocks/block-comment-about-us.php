<!--START-TESTIMONIAL-SECTION-->
<div class="testimonial-section">
    <div class="container position-relative">
        <div class="header-section center-theme" data-aos="zoom-in-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
            <div class="title">
                <?php block_field('tt'); ?>
                <b class="morabba has-mt">
                    <?php block_field('sub-tt'); ?>
                </b>
            </div>
        </div>
        <div class="position-relative"  data-aos="zoom-in-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
            <img class="shape" src="<?php echo DU .'/assets/img/square.png'?>" alt="">
            <div class="button-nav prev swiper-button-prev-testimonial">
                <i class="icon-right-chevron"></i>
            </div>
            <div class="button-nav next swiper-button-next-testimonial">
                <i class="icon-left-chevron"></i>
            </div>
            <div class="slider-container">
                <div class="swiper-container swiper-testimonial">
                    <div class="swiper-wrapper">
                       <?php
                       if (!empty(block_value('c-tx-1'))) { ?>
                           <div class="swiper-slide item">
                               <i class="icon-quotation"></i>
                               <p class="text">
                                   <?php block_field('c-tx-1'); ?>
                                          </p>
                               <div class="user">
                                   <img src="<?php block_field('c-ax-1'); ?>" alt="<?php block_field('c-nm-1'); ?>">
                                   <span>
                                    <b>
                                         <?php block_field('c-nm-1'); ?>
                                    </b>
                                     <?php block_field('c-snm-1'); ?>
                                </span>
                               </div>
                           </div>
                        <?php } ?>

                        <?php
                        if (!empty(block_value('c-tx-1-2'))) { ?>
                            <div class="swiper-slide item">
                                <i class="icon-quotation"></i>
                                <p class="text">
                                    <?php block_field('c-tx-1-2'); ?>
                                </p>
                                <div class="user">
                                    <img src="<?php block_field('c-ax-1-2'); ?>" alt="">
                                    <span>
                                    <b>
                                         <?php block_field('c-nm-1-2'); ?>
                                    </b>
                                     <?php block_field('c-snm-1-2'); ?>
                                </span>
                                </div>
                            </div>
                        <?php } ?>
                        <?php
                        if (!empty(block_value('c-tx-1-3'))) { ?>
                            <div class="swiper-slide item">
                                <i class="icon-quotation"></i>
                                <p class="text">
                                    <?php block_field('c-tx-1-3'); ?>
                                </p>
                                <div class="user">
                                    <img src="<?php block_field('c-ax-1-3'); ?>" alt="">
                                    <span>
                                    <b>
                                         <?php block_field('c-nm-1-3'); ?>
                                    </b>
                                     <?php block_field('c-snm-1-3'); ?>
                                </span>
                                </div>
                            </div>
                        <?php } ?>
                        <?php
                        if (!empty(block_value('c-tx-1-4'))) { ?>
                            <div class="swiper-slide item">
                                <i class="icon-quotation"></i>
                                <p class="text">
                                    <?php block_field('c-tx-1-4'); ?>
                                </p>
                                <div class="user">
                                    <img src="<?php block_field('c-ax-1-4'); ?>" alt="">
                                    <span>
                                    <b>
                                         <?php block_field('c-nm-1-4'); ?>
                                    </b>
                                     <?php block_field('c-snm-1-4'); ?>
                                </span>
                                </div>
                            </div>
                        <?php } ?>
                            <?php
                        if (!empty(block_value('c-tx-1-5'))) { ?>
                        <div class="swiper-slide item">
                            <i class="icon-quotation"></i>
                            <p class="text">
                                <?php block_field('c-tx-1-5'); ?>
                            </p>
                            <div class="user">
                                <img src="<?php block_field('c-ax-1-5'); ?>" alt="<?php block_field('c-nm-1-5'); ?>">
                                <span>
                                    <b>
                                         <?php block_field('c-nm-1-5'); ?>
                                    </b>
                                     <?php block_field('c-snm-1-5'); ?>
                                </span>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--END-TESTIMONIAL-SECTION-->