<!--START-ARTICLES-->
<div class="articles">
    <div class="container">
        <div class="header-section"  data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
            <div class="title">
                    <span class="d-none d-lg-block">
                        <b class="morabba has-mb"><?php block_field('tt'); ?></b>
                    <?php block_field('sub-tt'); ?>
                    </span>

                <b class="morabba m-0 d-block d-lg-none">مقالات و اطلاعیه ها</b>

            </div>
            <a href="<?php echo home_url() .'/مقالات/'?>" class="see-all">
                    <span class="d-none d-lg-block">
                        مشاهده آرشیو مقالات
                    </span>
                <div class="icon">
                    <i class="icon-1-folder"></i>
                </div>
            </a>
        </div>
        <div class="row prl-5px">
            <?php
            $args = array('posts_per_page' => 4,
                'post_type' => 'post'
            );
            $the_query = new WP_Query($args);
            $cu = 1;
            if ($the_query->have_posts()) {

                while ($the_query->have_posts()) {
                    $the_query->the_post();
                    if ($cu == 1 || $cu == 4) {
                        $wrapper_class = "col-xl-7  ";
                    } else {
                        $wrapper_class = "col-xl-5  ";

                    }
                    ?>


                    <div class="<?php echo $wrapper_class ?> col-md-6 prl-10px" data-aos="fade-up"
                         data-aos-easing="ease-in-out"
                         data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                        <a href="<?php echo get_the_permalink() ?>" class="item">
                            <div class="img" style="background-image: url(<?php echo
                            wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()))
                            ?>)">
                                <article>
                                    <?php $terms = get_the_terms(get_the_ID(), "category") ?>
                                    <span class="subtitle">
                                    دسته بندی
                                        <?php echo $terms[0]->name ?>
                                </span>
                                    <span class="title morabba">
                            <?php echo get_the_title() ?>
                                </span>
                                    <ul class="nav nav-info">
                                        <li class="nav-item">
                                            <div class="icon">
                                                <i class="icon-calendar"></i>
                                            </div>
                                            <span>
                                        منتشر شده
                                        <b>
                                        <?php echo get_the_date('dS M Y', $post->ID) . ' ' ?>
                                        </b>
                                    </span>
                                        </li>
                                        <li class="nav-item">
                                            <div class="icon">
                                                <i class="icon-chat"></i>
                                            </div>
                                            <span>
                                        تعداد نظرات
                                      <?php
                                      $comments = get_comment_count(get_the_ID());
                                      ?>
                                        <b>
                                          <?php echo $comments['total_comments']; ?>
                                             نظر ثبت شده
                                        </b>
                                    </span>
                                        </li>
                                    </ul>
                                </article>
                            </div>
                        </a>
                    </div>

                    <?php
                    $cu++;
                }


            } else {

            }

            wp_reset_postdata();
            ?>      </div>
    </div>
</div>
<!--END-ARTICLES-->