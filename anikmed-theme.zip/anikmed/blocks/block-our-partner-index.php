<!--START-BRANDS-SECTION-->
<div class="brands-section">
    <div class="container">
        <div class="header-section center-theme" data-aos="fade-up" data-aos-easing="ease-in-out"
             data-aos-duration="1000" data-aos-delay="00" data-aos-once="true">
            <div class="title">
                <?php block_field('tt'); ?>
                <b class="morabba"> <?php block_field('sub-tt'); ?></b>
            </div>
        </div>
        <div class="swiper-container swiper-brands" data-aos="fade-up" data-aos-easing="ease-in-out"
             data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
            <div class="swiper-wrapper">
                <?php
                $args = array(
                        'posts_per_page' => -1,
                        'post_type' => 'companies'
                    );
                $the_query = new WP_Query($args); ?>

                <?php if ($the_query->have_posts()) : ?>


                    <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
                        <?php  $alt_text = get_post_meta(get_post_thumbnail_id(get_the_ID()) , '_wp_attachment_image_alt', true); ?>
                        <a href="" class="swiper-slide">
                            <img src="<?php echo
                            wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()))
                            ?>" alt="<?php echo $alt_text ?>">
                        </a>

                    <?php endwhile; ?>


                    <?php wp_reset_postdata(); ?>

                <?php else : ?>
                    <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
                <?php endif; ?>


            </div>
        </div>
    </div>
</div>
<!--END-BRANDS-SECTION-->