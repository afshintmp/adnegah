<!--START-PRODUCTS-->
<div class="products">
    <div class="container">
        <div class="header-section">
            <div class="title" data-aos="fade-left" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="00" data-aos-once="true">
                    <span class="d-none d-lg-block">
                        <b class="morabba has-mb">
                            <?php block_field('tt'); ?>
                        </b>
                    <?php block_field('sub-tt'); ?>
                    </span>

                <b class="morabba m-0 d-block d-lg-none">محصولات برتر</b>

            </div>
            <a href="<?php echo get_home_url() .'/محصولات/'?>" class="see-all" data-aos="fade-right" data-aos-easing="ease-in-out" data-aos-duration="1000"
               data-aos-delay="200" data-aos-once="true">
                    <span class="d-none d-lg-block">
                        مشاهده همه محصولات
                    </span>
                <div class="icon">
                    <i class="icon-1-folder"></i>
                </div>
            </a>
        </div>
        <div class="slider-container" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
             data-aos-delay="400" data-aos-once="true">
            <div class="swiper-container swiper-products">
                <div class="swiper-wrapper">
                    <?php $args = array(
                        'post_type' => 'product',
                        'posts_per_page' => 9,
                        'orderby' => 'date',
                        'order'   => 'DESC',
                        'suppress_filters' => true,
                        'meta_query' => array(
                            array(
                                'key' => 'jobfinder-selected'
                            )
                        )

                    );
                    $the_query = new WP_Query($args);


                    if ($the_query->have_posts()) {

                        while ($the_query->have_posts()) {
                            $the_query->the_post();
                          ?>
                            <div class="swiper-slide item">
                                <div class="bg">
                                    <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id(get_the_ID())) ?>"
                                         alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">

                                    <div class="name morabba">
                                        <?php echo get_the_title() ?>
                                    </div>
                                    <?php $pro_category = get_the_terms(get_the_ID(), "pro-cats");

                                    if ($pro_category) :
                                        ?>
                                        <div class="subtitle">
                                            <?php echo $pro_category[0]->name ?>
                                        </div>

                                    <?php endif; ?>

                                    <a href="<?php echo get_the_permalink() ?>" class="more">
                                        مشاهده جزئیات
                                        <i class="icon-1-left-circle"></i>
                                    </a>
                                </div>
                            </div>

                    <?php
                        }

                    } else {

                    }

                    wp_reset_postdata();
                    ?>


                </div>
            </div>
            <button class="btn btn-nav prev swiper-button-prev-products">
                <i class="icon-right-chevron"></i>
            </button>
            <button class="btn btn-nav next swiper-button-next-products">
                <i class="icon-left-chevron"></i>
            </button>
        </div>
    </div>
</div>
<!--END-PRODUCTS-->