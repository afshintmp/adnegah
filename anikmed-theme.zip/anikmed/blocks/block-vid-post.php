<div class="video-box"  data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
    <img src="<?php block_field('cover'); ?>" alt="<?php block_field('alt-text'); ?>">

    <!--START-CHANGE-->
    <div class="btn-play play-vid" onclick="playVid1()">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">
            <path fill="#000" d="M512 0c-282.334 0-512 229.688-512 512s229.666 512 512 512 512-229.688 512-512-229.666-512-512-512zM715.542 529.938l-298.666 192c-3.5 2.27-7.542 3.396-11.542 3.396-3.5 0-7.042-0.876-10.208-2.604-6.876-3.75-11.126-10.918-11.126-18.73v-384c0-7.812 4.25-14.98 11.126-18.73 6.75-3.708 15.208-3.48 21.75 0.792l298.666 192c6.084 3.916 9.792 10.688 9.792 17.938s-3.708 14.020-9.792 17.938z"></path>
        </svg>
    </div>
    <div class="main-video">
        <video src="<?php block_field('vid'); ?>" id="video1"
               controls
               preload="none">
        </video>
        <div class="btn btn-close" onclick="pauseVid1()">
            <i class="icon-close"></i>
        </div>
    </div>
    <!--END-CHANGE-->



</div>
<script>
    var vid1 = document.getElementById("video1");
    function playVid1() {vid1.play()}
    function pauseVid1() {vid1.pause()}

    jQuery('.play-vid').click( function () {
        jQuery(this).parent().find('.main-video').show();
    })
    jQuery('.main-video .btn-close').click( function () {
        jQuery(this).parent().parent().find('.main-video').hide();
    })
</script>