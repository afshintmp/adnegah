<!--START-STATUS-SECTION-->
<div class="status-section-about" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
     data-aos-delay="0" data-aos-once="true">
    <img class="shape" src="<?php echo DU . '/' ?>assets/img/shape-5.png" alt="">
    <div class="container p-0 d-flex align-items-center flex-wrap">
        <div class="col-lg-6" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
             data-aos-delay="0" data-aos-once="true">
            <div class="circle">
                <div class="line"></div>
                <div class="line mid"></div>
                <div class="line small"></div>
                <div class="brand">
                    <img src="<?php echo DU . '/' ?>assets/img/logo-white.png" alt="">
                </div>
                <?php if (!empty(block_value('num-1'))) { ?>
                    <div class="item pt">


                        <div class="number morabba">
                            <?php block_field('num-1'); ?>
                        </div>
                        <?php block_field('tt-1'); ?>
                    </div>
                    <?php
                }
                ?>
                <?php if (!empty(block_value('num-2'))) { ?>
                    <div class="item pr">
                        <div class="number morabba">
                            <?php block_field('num-2'); ?>
                        </div>
                        <?php block_field('tt-2'); ?>
                    </div>
                    <?php
                }
                ?>
                <?php if (!empty(block_value('num-3'))) { ?>
                    <div class="item pb">
                        <div class="number morabba">
                            <?php block_field('num-3'); ?>
                        </div>
                        <?php block_field('tt-3'); ?>
                    </div>
                    <?php
                }
                ?>
                <?php if (!empty(block_value('num-4'))) { ?>
                    <div class="item pl">
                        <div class="number morabba">
                            <?php block_field('num-4'); ?>
                        </div>
                        <?php block_field('tt-4'); ?>
                    </div>
                    <?php
                }
                ?>

            </div>
        </div>
        <div class="col-lg-6" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
             data-aos-delay="200" data-aos-once="true">
            <div class="header-section right-theme">

                    <span class="title">
                        <b class="has-mb morabba">
                            <?php block_field('tt'); ?>
                        </b>
                          <?php block_field('sub-tt'); ?>
                        </span>
            </div>
            <p class="text">
                <?php block_field('txt'); ?>
            </p>
        </div>
    </div>
</div>
<!--END-STATUS-SECTION-->
