<div class="video-box">
    <!--START-CHANGE-->
    <div class="main play-vid" onclick="playVid1()">
        <div class="img" style="background-image: url(<?php block_field('cover'); ?>)">
            <article>
                <button class="btn btn-play">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">
                        <g id="icomoon-ignore">
                        </g>
                        <path fill="#000" d="M872.34 356.648c-15.066-9.391-34.877-4.797-44.262 10.264s-4.792 34.871 10.264 44.257c35.037 21.85 55.95 59.543 55.95 100.834s-20.913 78.984-55.95 100.834l-526.935 328.555c-37.174 23.178-82.234 24.318-120.532 3.068-38.303-21.256-61.171-60.1-61.171-103.902v-657.115c0-43.802 22.867-82.646 61.171-103.902 38.298-21.25 83.358-20.11 120.532 3.068l306.748 191.265c15.061 9.38 34.871 4.792 44.262-10.264 9.386-15.056 4.792-34.871-10.264-44.257l-306.748-191.259c-57.268-35.707-126.684-37.479-185.707-4.728-59.008 32.746-94.238 92.589-94.238 160.077v657.11c0 67.489 35.23 127.331 94.243 160.077 28.109 15.597 58.569 23.365 88.964 23.365 33.415 0 66.75-9.391 96.738-28.093l526.935-328.555c53.98-33.661 86.206-91.732 86.206-155.349s-32.226-121.688-86.206-155.349z"></path>
                    </svg>
                </button>
                <span class="subtitle">
                                   <?php block_field('tt'); ?>
                                </span>
                <span class="title morabba">
                                  <?php block_field('sub-tt'); ?>
                                </span>
            </article>
        </div>
    </div>
    <div class="main-video">
        <video src="<?php block_field('vid-link'); ?>" id="video1"
               controls
               preload="none">
        </video>
        <div class="btn btn-close" onclick="pauseVid1()">
            <i class="icon-close"></i>
        </div>
    </div>
    <!--END-CHANGE-->
</div>

<script>
    var vid1 = document.getElementById("video1");
    function playVid1() {vid1.play()}
    function pauseVid1() {vid1.pause()}

    jQuery('.play-vid').click( function () {
        jQuery(this).parent().find('.main-video').show();
    })
    jQuery('.main-video .btn-close').click( function () {
        jQuery(this).parent().parent().find('.main-video').hide();
    })
</script>