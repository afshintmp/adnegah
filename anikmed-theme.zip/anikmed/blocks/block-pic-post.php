<?php
$i = 0;
if (!empty(block_value('pic-1'))) {
    $i++;
}
if (!empty(block_value('pic-2'))) {
    $i++;
}
if (!empty(block_value('pic-3'))) {
    $i++;
}
switch ($i) {
    case 1:
    case 0 :
        $conroller_class = "col-lg-12 col-md-12";
        break;
    case 2 :
        $conroller_class = "col-lg-6 col-md-6";
        break;
    case 3:
        $conroller_class = "col-lg-4 col-md-6";
        break;
}

?>
<div class="row gallery-row prl-5px" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
     data-aos-delay="0" data-aos-once="true">
    <?php if (!empty(block_value('pic-1'))) : ?>
        <div class="<?php echo $conroller_class ?> prl-10px">
            <div class="img-gallery">
                <img src="<?php block_field('pic-1'); ?>" alt="<?php block_field('alt-1'); ?>">
            </div>
        </div>
    <?php endif; ?>
    <?php if (!empty(block_value('pic-2'))) : ?>
        <div class="<?php echo $conroller_class ?> prl-10px">
            <div class="img-gallery">
                <img src="<?php block_field('pic-2'); ?>" alt="<?php block_field('alt-2'); ?>">
            </div>
        </div>
    <?php endif; ?>
    <?php if (!empty(block_value('pic-3'))) : ?>
        <div class="<?php echo $conroller_class ?> prl-10px">
            <div class="img-gallery">
                <img src="<?php block_field('pic-3'); ?>" alt="<?php block_field('alt-3'); ?>">
            </div>
        </div>
    <?php endif; ?>
</div>