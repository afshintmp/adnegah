<?php get_header();
global $post;
?>
<body>

<?php get_template_part("partials/top-bar-menu") ?>

<!--START-MAIN-->
<main>
    <?php get_template_part('partials/bread-crump') ?>

    <!--START-PRODUCT-SINGLE-->
    <div class="product-single">
        <div class="container p-0 d-flex flex-wrap flex-column-reverse flex-xl-row">
            <div class="col-xl-6" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="500" data-aos-once="true">
                <div class="title morabba d-none d-xl-block">
                    <?php echo get_the_title() ?>
                </div>
                <?php $pro_category = get_the_terms(get_the_ID(), "pro-cats");

                if ($pro_category) :
                    ?>
                    <div class="subtitle morabba d-none d-xl-block">
                        <?php echo $pro_category[0]->name ?>

                    </div>
                <?php endif; ?>
                <div class="lines d-none d-xl-block">
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
                <div class="text">
                    <?php the_content(); ?>
                </div>

            </div>
            <div class="col-xl-6" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="1000" data-aos-once="true">
                <div class="title morabba d-blok d-xl-none">
                    <?php echo get_the_title() ?>
                </div>
                <?php
                if ($pro_category) :
                    ?>
                    <div class="subtitle morabba d-blok d-xl-none">
                        <?php echo $pro_category[0]->name ?>
                    </div>
                <?php endif; ?>
                <div class="lines d-blok d-xl-none">
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
                <div class="slide-box">
                    <?php
                    $gallery_img_ids = get_post_meta(get_the_ID(), 'vdw_gallery_id', true);

                    ?>
                    <div class="swiper-container swiper-single">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide item">
                                <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id(get_the_ID())) ?>"
                                     alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">
                            </div>
                            <?php

                            foreach ($gallery_img_ids as $gallery_img_id) :
                                ?>
                                <div class="swiper-slide item">
                                    <img src="<?php echo wp_get_attachment_url($gallery_img_id) ?>"
                                         alt="<?php echo get_post_meta($gallery_img_id, '_wp_attachment_image_alt', true); ?>">
                                </div>
                            <?php endforeach; ?>

                        </div>
                        <div class="btn-nav prev swiper-button-prev-single">
                            <i class="icon-right-chevron"></i>
                        </div>
                        <div class="btn-nav next swiper-button-next-single">
                            <i class="icon-left-chevron"></i>
                        </div>
                    </div>
                </div>
                <div class="info-list">
                    <?php
                    $jobfinder_no = get_post_meta($post->ID, 'jobfinder-no', true);
                    $jobfinder_vazn = get_post_meta($post->ID, 'jobfinder-vazn', true);
                    $jobfinder_size = get_post_meta($post->ID, 'jobfinder-size', true);
                    $jobfinder_karbar = get_post_meta($post->ID, 'jobfinder-karbar', true);
                    $jobfinder_hamrah = get_post_meta($post->ID, 'jobfinder-hamrah', true);
                    ?>
                    <div class="row prl-10px">
                        <?php if (!empty($jobfinder_no)) : ?>
                            <div class="col-lg-4 col-sm-6 prl-5px">
                                <div class="th morabba">
                                    نوع
                                </div>
                                <div class="td">
                                    <i class="icon-left-chevron"></i>
                                    <?php echo $jobfinder_no; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($jobfinder_vazn)) : ?>
                            <div class="col-lg-4 col-sm-6 prl-5px">
                                <div class="th morabba">
                                    وزن
                                </div>
                                <div class="td">
                                    <i class="icon-left-chevron"></i>
                                    <?php echo $jobfinder_vazn; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($jobfinder_size)) : ?>
                            <div class="col-lg-4 col-sm-6 prl-5px">
                                <div class="th morabba">
                                    سایز
                                </div>
                                <div class="td">
                                    <i class="icon-left-chevron"></i>
                                    <?php echo $jobfinder_size; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($jobfinder_karbar)) : ?>
                            <div class="col-lg-4 col-sm-6 prl-5px">
                                <div class="th morabba">
                                    کاربری
                                </div>
                                <div class="td">
                                    <i class="icon-left-chevron"></i>
                                    <?php echo $jobfinder_karbar; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($jobfinder_hamrah)) : ?>
                            <div class="col-lg-8 prl-5px">
                                <div class="th morabba">
                                    اقلام همراه
                                </div>
                                <div class="td">
                                    <i class="icon-left-chevron"></i>
                                    <?php echo $jobfinder_hamrah; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--END-PRODUCT-SINGLE-->

    <!--START-FORM-ELEMENTS-->
    <div class="form-elements">
        <div class="container">
            <div class="header-section center-theme" data-aos="fade-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <div class="title ">
                    کیفیت و تجربه را از ما بخواهید
                    <b class="morabba has-mt">تکمیــــل فــــرم سفــــارش محصــــول</b>
                </div>
            </div>

            <?php echo do_shortcode("[contact-form-7 id='73' title='فرم درخواست محصول']") ?>
        </div>
    </div>
    <!--END-FORM-ELEMENTS-->
    <?php
    $related_post_category_id = $pro_category[0]->term_id;

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 9,
        array(
            'taxonomy' => 'pro-ctas',

            'terms' => $related_post_category_id,
        ),

    );

    $the_query = new WP_Query($args);


    if ($the_query->have_posts()) {
        ?>
        <!--START-PRODUCTS-->
        <div class="products">
            <div class="container">
                <div class="header-section center-theme" data-aos="fade-up" data-aos-easing="ease-in-out"
                     data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                    <div class="title ">
                    <span class="d-none d-lg-block">
                        مشاهده , بررسی و سفارش
                        <b class="morabba has-mt">لیــــست محصــــولات مرتبــــط</b>
                    </span>

                        <b class="morabba m-0 d-block d-lg-none"> محصــــولات مرتبــــط</b>

                    </div>
                </div>
                <div class="slider-container" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
                     data-aos-delay="200" data-aos-once="true">
                    <div class="swiper-container swiper-products">
                        <div class="swiper-wrapper">


                            <?php

                            while ($the_query->have_posts()) {
                                $the_query->the_post();
                                ?>
                                <div class="swiper-slide item">
                                    <div class="bg">
                                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id(get_the_ID())) ?>"
                                             alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">

                                        <div class="name morabba">
                                            <?php echo get_the_title() ?>
                                        </div>
                                        <?php $pro_category = get_the_terms(get_the_ID(), "pro-cats");

                                        if ($pro_category) :
                                            ?>
                                            <div class="subtitle">
                                                <?php echo $pro_category[0]->name ?>
                                            </div>

                                        <?php endif; ?>

                                        <a href="<?php echo get_the_permalink() ?>" class="more">
                                            مشاهده جزئیات
                                            <i class="icon-1-left-circle"></i>
                                        </a>
                                    </div>
                                </div>

                                <?php

                            }
                            ?>

                        </div>
                    </div>
                    <button class="btn btn-nav prev swiper-button-prev-products">
                        <i class="icon-right-chevron"></i>
                    </button>
                    <button class="btn btn-nav next swiper-button-next-products">
                        <i class="icon-left-chevron"></i>
                    </button>
                </div>
            </div>
        </div>
        <!--END-PRODUCTS-->

        <?php
    } else {

    }

    wp_reset_postdata();
    ?>

</main>
<!--END-MAIN-->
<?php get_footer() ?>
</body>
</html>
