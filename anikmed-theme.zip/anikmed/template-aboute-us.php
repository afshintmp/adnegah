<?php
/* Template Name: Page Full Template */
get_header();

?>

<body>

<?php get_template_part("partials/top-bar-menu") ?>

<!--START-MAIN-->
<main>
    <?php get_template_part('partials/bread-crump') ?>

    <?php the_content(); ?>
    
</main>
<!--END-MAIN-->

<?php get_footer() ?>
</body>
</html>
