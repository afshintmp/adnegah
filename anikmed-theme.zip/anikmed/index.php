<?php get_header() ?>


<body>

<?php get_template_part("partials/top-bar-menu") ?>

<!--START-MAIN-->
<main>
    <!--START-MAIN-SLIDE-->
    <div class="main-slide">
        <div class="container p-0 position-relative">
            <div data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="600" data-aos-once="true">
                <img src="<?php echo DU .'/assets/img/shape-1.png'?>" alt="" class="shape" >
            </div>
            <div class="col-lg-6">
                <div class="swiper-container swiper-main-slide">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <span class="title morabba" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="800" data-aos-once="true">
                    تجهیـــــزات کلینیـــــک زیبایـــــی
                </span>
                            <span class="subtitle morabba" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="900" data-aos-once="true">
                    گـــــــــروه صنعتـــــــــی آنیکمـــــــــد
                </span>
                            <p class="text" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="1000" data-aos-once="true">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد .
                            </p>
                            <ul class="nav" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="1100" data-aos-once="true">
                                <li class="nav-item">
                                    <a href="" class="nav-link bg-theme">
                                        درباره ما بیشتر بدانید
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link">
                                        مشاهده محصولات
                                        <i class="icon-left-arrow"></i>
                                    </a>
                                </li>
                            </ul>
                            <div class="d-flex" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="1200" data-aos-once="true">
                                <button class="btn swiper-button-prev-main-slide">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-main-slide">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <span class="title morabba">
                    تجهیـــــزات کلینیـــــک زیبایـــــی
                </span>
                            <span class="subtitle morabba">
                    گـــــــــروه صنعتـــــــــی آنیکمـــــــــد
                </span>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد .
                            </p>
                            <ul class="nav">
                                <li class="nav-item">
                                    <a href="" class="nav-link bg-theme">
                                        درباره ما بیشتر بدانید
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link">
                                        مشاهده محصولات
                                        <i class="icon-left-arrow"></i>
                                    </a>
                                </li>
                            </ul>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-main-slide">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-main-slide">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <span class="title morabba">
                    تجهیـــــزات کلینیـــــک زیبایـــــی
                </span>
                            <span class="subtitle morabba">
                    گـــــــــروه صنعتـــــــــی آنیکمـــــــــد
                </span>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد .
                            </p>
                            <ul class="nav">
                                <li class="nav-item">
                                    <a href="" class="nav-link bg-theme">
                                        درباره ما بیشتر بدانید
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link">
                                        مشاهده محصولات
                                        <i class="icon-left-arrow"></i>
                                    </a>
                                </li>
                            </ul>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-main-slide">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-main-slide">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <span class="title morabba">
                    تجهیـــــزات کلینیـــــک زیبایـــــی
                </span>
                            <span class="subtitle morabba">
                    گـــــــــروه صنعتـــــــــی آنیکمـــــــــد
                </span>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد .
                            </p>
                            <ul class="nav">
                                <li class="nav-item">
                                    <a href="" class="nav-link bg-theme">
                                        درباره ما بیشتر بدانید
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="nav-link">
                                        مشاهده محصولات
                                        <i class="icon-left-arrow"></i>
                                    </a>
                                </li>
                            </ul>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-main-slide">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-main-slide">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--END-MAIN-SLIDE-->

    <!--START-OUR-PRODUCTS-->
    <div class="our-products">
        <div class="container p-0 position-relative d-flex flex-wrap align-items-center justify-content-between">
            <div data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <img class="shape" src="<?php DU .'/assets/img/shape-2.png'?>" alt="">
            </div>
            <div class="col-xl-5 col-lg-6 prl-5px d-flex flex-wrap">
                <div class="col-sm-6 prl-10px" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="100" data-aos-once="true">
                    <div class="item">
                        <img src="<?php echo DU .'/assets/img/s-1.png'?>" alt="">
                        <b class="morabba">
                            کلینیک زیبایی
                        </b>
                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است .
                    </div>
                </div>
                <div class="col-sm-6 prl-10px" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
                    <div class="item has-m-t">
                        <img src="<?php UD.'/assets/img/s-2.png' ?>" alt="">
                        <b class="morabba">
                            آزمایشگاهی
                        </b>
                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است .
                    </div>
                </div>
                <div class="col-sm-6 prl-10px" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="300" data-aos-once="true">
                    <div class="item">
                        <img src="<?php UD.'/assets/img/s-3.png' ?>" alt="">
                        <b class="morabba">
                            سایر محصولات
                        </b>
                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است .
                    </div>
                </div>
                <div class="col-sm-6 prl-10px" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="400" data-aos-once="true">
                    <div class="item has-m-t">
                        <img src="<?php echo DU .'/assets/img/s-4.png' ?>" alt="">
                        <b class="morabba">
                            درمانگاه و بیمارستان
                        </b>
                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است .
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">

                <span class="title morabba" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="500" data-aos-once="true">
دستـــه بنـــدی محصــــولات
                </span>
                <span class="subtitle" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="600" data-aos-once="true">
پیشرفــــــت و توسعــــــه
                </span>
                <p class="text" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="700" data-aos-once="true">
                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد .
                </p>
                <div data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="900" data-aos-once="true">
                    <a href="" class="more">
                        بیشتر بدانید
                        <i class="icon-left-arrow"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!--END-OUR-PRODUCTS-->

    <!--START-BRANDS-SECTION-->
    <div class="brands-section">
        <div class="container">
            <div class="header-section center-theme" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="00" data-aos-once="true">
                <div class="title">
                    تولیـــــدکننـــــده برتـــــر کشـــــور
                    <b class="morabba">خانـــــواده بـــــزرگ آنیکــــمد</b>
                </div>
            </div>
            <div class="swiper-container swiper-brands" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
                <div class="swiper-wrapper">
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU.'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU.'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU .'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU .'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU.'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU.'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU .'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU .'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU.'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU.'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU .'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                    <a href="" class="swiper-slide">
                        <img src="<?php echo DU .'/assets/img/brand-1.png' ?>" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!--END-BRANDS-SECTION-->

    <!--START-PRODUCTS-->
    <div class="products">
        <div class="container">
            <div class="header-section">
                <div class="title"  data-aos="fade-left" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="00" data-aos-once="true">
                    <span class="d-none d-lg-block">
                        <b class="morabba has-mb">محصــــــولات مــــــنتخب و برتــــــر</b>
                    واردات از بهتریـــــن شرکت هـــــا دنیـــــا
                    </span>

                    <b class="morabba m-0 d-block d-lg-none">محصولات برتر</b>

                </div>
                <a href="#" class="see-all" data-aos="fade-right" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
                    <span class="d-none d-lg-block">
                        مشاهده همه محصولات
                    </span>
                    <div class="icon">
                        <i class="icon-1-folder"></i>
                    </div>
                </a>
            </div>
            <div class="slider-container" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="400" data-aos-once="true">
                <div class="swiper-container swiper-products">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide item">
                            <div class="bg">
                                <img src="<?php echo DU .'/assets/img/p-1.png' ?>" alt="">
                                <div class="name morabba">
                                    دستگاه لیزر Dual Mode Q
                                </div>
                                <div class="subtitle">
                                    ویژه مراکز و کلینیک های زیبایی
                                </div>
                                <a href="" class="more">
                                    مشاهده جزئیات
                                    <i class="icon-1-left-circle"></i>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <div class="bg">
                                <img src="<?php echo DU .'/assets/img/p-1.png' ?>" alt="">
                                <div class="name morabba">
                                    دستگاه لیزر Dual Mode Q
                                </div>
                                <div class="subtitle">
                                    ویژه مراکز و کلینیک های زیبایی
                                </div>
                                <a href="" class="more">
                                    مشاهده جزئیات
                                    <i class="icon-1-left-circle"></i>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <div class="bg">
                                <img src="<?php echo DU .'/assets/img/p-1.png' ?>" alt="">
                                <div class="name morabba">
                                    دستگاه لیزر Dual Mode Q
                                </div>
                                <div class="subtitle">
                                    ویژه مراکز و کلینیک های زیبایی
                                </div>
                                <a href="" class="more">
                                    مشاهده جزئیات
                                    <i class="icon-1-left-circle"></i>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <div class="bg">
                                <img src="<?php echo DU .'/assets/img/p-1.png' ?>" alt="">
                                <div class="name morabba">
                                    دستگاه لیزر Dual Mode Q
                                </div>
                                <div class="subtitle">
                                    ویژه مراکز و کلینیک های زیبایی
                                </div>
                                <a href="" class="more">
                                    مشاهده جزئیات
                                    <i class="icon-1-left-circle"></i>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <div class="bg">
                                <img src="<?php echo DU .'/assets/img/p-1.png' ?>" alt="">
                                <div class="name morabba">
                                    دستگاه لیزر Dual Mode Q
                                </div>
                                <div class="subtitle">
                                    ویژه مراکز و کلینیک های زیبایی
                                </div>
                                <a href="" class="more">
                                    مشاهده جزئیات
                                    <i class="icon-1-left-circle"></i>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <div class="bg">
                                <img src="<?php echo DU .'/assets/img/p-1.png' ?>" alt="">
                                <div class="name morabba">
                                    دستگاه لیزر Dual Mode Q
                                </div>
                                <div class="subtitle">
                                    ویژه مراکز و کلینیک های زیبایی
                                </div>
                                <a href="" class="more">
                                    مشاهده جزئیات
                                    <i class="icon-1-left-circle"></i>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <div class="bg">
                                <img src="<?php echo DU .'/assets/img/p-1.png' ?>" alt="">
                                <div class="name morabba">
                                    دستگاه لیزر Dual Mode Q
                                </div>
                                <div class="subtitle">
                                    ویژه مراکز و کلینیک های زیبایی
                                </div>
                                <a href="" class="more">
                                    مشاهده جزئیات
                                    <i class="icon-1-left-circle"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="btn btn-nav prev swiper-button-prev-products">
                    <i class="icon-right-chevron"></i>
                </button>
                <button class="btn btn-nav next swiper-button-next-products">
                    <i class="icon-left-chevron"></i>
                </button>
            </div>
        </div>
    </div>
    <!--END-PRODUCTS-->

    <!--START-OPINION-->
    <div class="opinion"  data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="00" data-aos-once="true">
        <div class="container p-0 position-relative d-flex align-items-center flex-wrap">
            <img src="<?php echo DU .'/assets/img/shape-3.'?>png" alt="" class="shape">

            <div class="col-xl-5 col-lg-6">
                <div class="header-section"  data-aos="fade-left" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                    <div class="title morabba">
                        <b>نظـــرات خریـــداران مـــا</b>
                        بــا مــا بهتریــن را تجربــه کنیــد
                    </div>
                </div>
                <div class="swiper-container swiper-opinion"  data-aos="fade-left" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide item">
                            <div class="user">
                                <img src="<?php echo DU .'/assets/img/user.png'?>" alt="">
                                <span>
                                    <b>سیـــــد منصـــــور خســـــروی</b>
مدیریت آزمایشگاه رازی
                                </span>
                            </div>
                            <p class="text">
                                <b>
                                    دستگاه   TF800UX
                                </b>
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز خواهد بود .
                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                4.9
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                        <div class="swiper-slide item">
                            <div class="user">
                                <img src="<?php echo DU .'/assets/img/user.png'?>" alt="">
                                <span>
                                    <b>سیـــــد منصـــــور خســـــروی</b>
مدیریت آزمایشگاه رازی
                                </span>
                            </div>
                            <p class="text">
                                <b>
                                    دستگاه   TF800UX
                                </b>
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز خواهد بود .
                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                4.9
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                        <div class="swiper-slide item">
                            <div class="user">
                                <img src="<?php echo DU .'/assets/img/user.png'?>" alt="">
                                <span>
                                    <b>سیـــــد منصـــــور خســـــروی</b>
مدیریت آزمایشگاه رازی
                                </span>
                            </div>
                            <p class="text">
                                <b>
                                    دستگاه   TF800UX
                                </b>
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز خواهد بود .
                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                4.9
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                        <div class="swiper-slide item">
                            <div class="user">
                                <img src="<?php echo DU .'/assets/img/user.png'?>" alt="">
                                <span>
                                    <b>سیـــــد منصـــــور خســـــروی</b>
مدیریت آزمایشگاه رازی
                                </span>
                            </div>
                            <p class="text">
                                <b>
                                    دستگاه   TF800UX
                                </b>
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز خواهد بود .
                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                4.9
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                        <div class="swiper-slide item">
                            <div class="user">
                                <img src="<?php echo DU .'/assets/img/user.png'?>" alt="">
                                <span>
                                    <b>سیـــــد منصـــــور خســـــروی</b>
مدیریت آزمایشگاه رازی
                                </span>
                            </div>
                            <p class="text">
                                <b>
                                    دستگاه   TF800UX
                                </b>
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز خواهد بود .
                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                4.9
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                        <div class="swiper-slide item">
                            <div class="user">
                                <img src="<?php echo DU .'/assets/img/user.png"'?> alt="">
                                <span>
                                    <b>سیـــــد منصـــــور خســـــروی</b>
مدیریت آزمایشگاه رازی
                                </span>
                            </div>
                            <p class="text">
                                <b>
                                    دستگاه   TF800UX
                                </b>
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز خواهد بود .
                            </p>
                            <div class="rate">
                                <i class="icon-1-star"></i>
                                4.9
                            </div>
                            <div class="d-flex">
                                <button class="btn swiper-button-prev-opinion">
                                    <i class="icon-right-chevron"></i>
                                </button>
                                <button class="btn swiper-button-next-opinion">
                                    <i class="icon-left-chevron"></i>
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 prl-5px d-none d-lg-flex flex-wrap mr-auto">
                <div class="col-lg-6 prl-10px" data-aos="fade-right" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="600" data-aos-once="true">
                    <div class="img">
                        <img src="<?php echo DU .'/assets/img/img-1.png'?>" alt="">
                    </div>
                </div>
                <div class="col-lg-6 prl-10px" data-aos="fade-right" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="700" data-aos-once="true">
                    <div class="img has-mt">
                        <img src="<?php echo DU .'/assets/img/img-2.png'?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--END-OPINION-->

    <!--START-ARTICLES-->
    <div class="articles">
        <div class="container">
            <div class="header-section"  data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <div class="title">
                    <span class="d-none d-lg-block">
                        <b class="morabba has-mb">اخبـــار , مقـــالات و اطلاعیه هـــا</b>
                    بـــا مـــا همیشـــه بـــروز باشیـــد
                    </span>

                    <b class="morabba m-0 d-block d-lg-none">مقالات و اطلاعیه ها</b>

                </div>
                <a href="#" class="see-all">
                    <span class="d-none d-lg-block">
                        مشاهده آرشیو مقالات
                    </span>
                    <div class="icon">
                        <i class="icon-1-folder"></i>
                    </div>
                </a>
            </div>
            <div class="row prl-5px">
                <div class="col-xl-7 col-md-6 prl-10px" data-aos="zoom-in-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
                    <a href="" class="item">
                        <div class="img" style="background-image: url(<?php echo DU .'/assets/img/b-a-1.png' ?>)">
                            <article>
                                <span class="subtitle">
                                    دسته بندی پزشکی و بهداشتی
                                </span>
                                <span class="title morabba">
                                    درمان کبد چرب؛ رژیم غذایی مناسب و روش‌های خانگی اثربخش
                                </span>
                                <ul class="nav nav-info">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                        منتشر شده
                                        <b>
26 مرداد ماه 1400
                                        </b>
                                    </span>
                                    </li>
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-chat"></i>
                                        </div>
                                        <span>
                                        تعداد نظرات
                                        <b>
                                            36 نظر ثبت شده
                                        </b>
                                    </span>
                                    </li>
                                </ul>
                            </article>
                        </div>
                    </a>
                </div>
                <div class="col-xl-5 col-md-6 prl-10px" data-aos="zoom-in-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="400" data-aos-once="true">
                    <a href="" class="item">
                        <div class="img" style="background-image: url('<?php echo DU .'/assets/img/b-a-2.png' ?>)">
                            <article>
                                <span class="subtitle">
                                    دسته بندی پزشکی و بهداشتی
                                </span>
                                <span class="title morabba">
                                    31 خاصیت منحصر‌به‌فرد چای سیاه
برای سلامتی بدن، پوست و مو
                                </span>
                                <ul class="nav nav-info">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                        منتشر شده
                                        <b>
26 مرداد ماه 1400
                                        </b>
                                    </span>
                                    </li>
                                </ul>
                            </article>
                        </div>
                    </a>
                </div>
                <div class="col-xl-5 col-md-6 prl-10px" data-aos="zoom-in-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
                    <a href="" class="item">
                        <div class="img" style="background-image: url(<?php echo DU .'/assets/img/b-a-2.png' ?>)">
                            <article>
                                <span class="subtitle">
                                    دسته بندی پزشکی و بهداشتی
                                </span>
                                <span class="title morabba">
                                    31 خاصیت منحصر‌به‌فرد چای سیاه
برای سلامتی بدن، پوست و مو
                                </span>
                                <ul class="nav nav-info">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                        منتشر شده
                                        <b>
26 مرداد ماه 1400
                                        </b>
                                    </span>
                                    </li>
                                </ul>
                            </article>
                        </div>
                    </a>
                </div>
                <div class="col-xl-7 col-md-6 prl-10px" data-aos="zoom-in-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="400" data-aos-once="true">
                    <a href="" class="item">
                        <div class="img" style="background-image: url('assets/img/b-a-1.png')">
                            <article>
                                <span class="subtitle">
                                    دسته بندی پزشکی و بهداشتی
                                </span>
                                <span class="title morabba">
                                    درمان کبد چرب؛ رژیم غذایی مناسب و روش‌های خانگی اثربخش
                                </span>
                                <ul class="nav nav-info">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                        منتشر شده
                                        <b>
26 مرداد ماه 1400
                                        </b>
                                    </span>
                                    </li>
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-chat"></i>
                                        </div>
                                        <span>
                                        تعداد نظرات
                                        <b>
                                            36 نظر ثبت شده
                                        </b>
                                    </span>
                                    </li>
                                </ul>
                            </article>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!--END-ARTICLES-->

    <!--START-AWARDS-->
    <div class="awards">
        <div class="container p-0 d-flex flex-wrap align-items-center">
            <div class="col-xl-5 col-lg-6"   data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <div class="header-section">
                                <span class="title morabba small-theme">
                                    <b>
                                        گـــواهینامه و تقدیرنامـــه هـــا
                                    </b>
                                افتخــــار همراهــــی بــــا شــــما را داریــــم
                                </span>
                </div>

                <div class="swiper-container swiper-a-thumbs">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="<?php echo DU .'/assets/img/awards.png'?>" alt="">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                عنوان برترین گروه پزشکی کشور
                            </div>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی می باشد .
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                                اردیبهشت ماه 1398
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="assets/img/awards.png" alt="">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                عنوان برترین گروه پزشکی کشور
                            </div>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی می باشد .
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                                اردیبهشت ماه 1398
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="assets/img/awards.png" alt="">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                عنوان برترین گروه پزشکی کشور
                            </div>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی می باشد .
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                                اردیبهشت ماه 1398
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide item">
                            <img class="d-block d-lg-none" src="assets/img/awards.png" alt="">
                            <div class="titr">
                                <div class="lines">
                                    <div class="line"></div>
                                    <div class="line"></div>
                                </div>
                                عنوان برترین گروه پزشکی کشور
                            </div>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی می باشد .
                            </p>
                            <div class="d-flex">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <div class="icon">
                                            <i class="icon-calendar"></i>
                                        </div>
                                        <span>
                                            دریافت در تاریخ
                                            <b>
                                                اردیبهشت ماه 1398
                                            </b>
                                        </span>
                                    </li>
                                </ul>
                                <div class="navigation">
                                    <div class="btn swiper-button-prev-a-sync">
                                        <i class="icon-right-chevron"></i>
                                    </div>
                                    <div class="btn swiper-button-next-a-sync">
                                        <i class="icon-left-chevron"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-xl-7 col-lg-6 d-none d-lg-block"   data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
                <div class="swiper-container swiper-a-sync">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide item">
                            <img src="assets/img/awards.png" alt="">
                        </div>
                        <div class="swiper-slide item">
                            <img src="assets/img/awards.png" alt="">
                        </div>
                        <div class="swiper-slide item">
                            <img src="assets/img/awards.png" alt="">
                        </div>
                        <div class="swiper-slide item">
                            <img src="assets/img/awards.png" alt="">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--END-AWARDS-->

    <!--STATUS-SECTION-->
    <div class="status-section">
        <div class="container prl-5px d-flex align-items-center justify-content-between flex-wrap">
            <div class="col-md-3 col-6 prl-10px"  data-aos="zoom-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <div class="item">
                    <b class="morabba">+۸۰۰</b>
                    نفر پرسنل
                </div>
            </div>
            <div class="col-md-3 col-6 prl-10px"  data-aos="zoom-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
                <div class="item">
                    <b class="morabba">+۲۰</b>
                    دستگاه وارد شده
                </div>
            </div>
            <div class="col-md-3 col-6 prl-10px"  data-aos="zoom-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="400" data-aos-once="true">
                <div class="item">
                    <b class="morabba">+۴</b>
                    شعبه و نمایندگی
                </div>
            </div>
            <div class="col-md-3 col-6 prl-10px"  data-aos="zoom-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="600" data-aos-once="true">
                <div class="item">
                    <b class="morabba">+۵۰</b>
                    میلیون دلار سرمایه
                </div>
            </div>
        </div>
    </div>
</main>
<!--END-MAIN-->
<?php get_footer() ?>
</body>
</html>

