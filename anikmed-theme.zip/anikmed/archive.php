<?php
get_header();
$my_ob = get_queried_object();

?>

<body>

<?php get_template_part("partials/top-bar-menu") ?>

<!--START-CHANGE-->
<div class="loading">
    <div class="detail">
        <img src="<?php echo DU .'/assets/img/Logo 1-0۱.png' ?>" alt="">
        <span class="text">
            لطفا کمی صبر کنید ...
        </span>
        <svg class="spinner" width="35px" height="35px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
            <circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle>
        </svg>
    </div>
</div>
<!--END-CHANGE-->
<!--START-MAIN-->
<main>
    <?php get_template_part('partials/bread-crump-texonomy') ?>
    <!--START-ARTICLES-->
    <div class="articles single-section">
        <div class="container">
            <form action="" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0"
                  data-aos-once="true">
                <div class="form-group">
                    <input type="text" id="post-search" onkeyup="postsearch()" placeholder="برای جستجو حداقل 3 کاراکتر را وارد کنید ...">
                </div>
                <button class="btn btn-search">
                    <i class="icon-search"></i>
                </button>
            </form>
            <ul class="nav nav-filter" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
                data-aos-delay="200" data-aos-once="true">
                <?php
                $post_categories = get_terms(array(
                    'taxonomy' => 'category',
                    'hide_empty' => false,
                ));
                ?>
                <li class="nav-item tab-item" onclick="categoriesTest(0)" data-filter="0">
                    همه
                </li>
                <?php
                foreach ($post_categories as $post_category):
                    ?>
                    <li class="nav-item tab-item <?php echo $post_category->term_id == $my_ob->term_id ? " active " : " " ?> " onclick="categoriesTest(<?php echo $post_category->term_id ?>)"
                        data-filter="<?php echo $post_category->term_id ?>">
                        <?php echo $post_category->name ?>
                    </li>
                <?php endforeach; ?>


            </ul>


            <div class="row prl-5px mb-0" id="ajax-mode">
                <?php
                $args = array('posts_per_page' => 4,
                        'post_type' => 'post' ,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'category',
                            'terms'    => $my_ob->term_id,
                        ),
                    ),
                );
                $the_query = new WP_Query($args);
                $cu = 1;
                if ($the_query->have_posts()) {

                    while ($the_query->have_posts()) {
                        $the_query->the_post();
                        if ($cu == 1 || $cu == 4) {
                            $wrapper_class = "col-xl-7  ";
                        } else {
                            $wrapper_class = "col-xl-5  ";

                        }
                        ?>


                        <div class="<?php echo $wrapper_class ?> col-md-6 prl-10px" data-aos="fade-up"
                             data-aos-easing="ease-in-out"
                             data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                            <a href="<?php echo get_the_permalink() ?>" class="item">
                                <div class="img" style="background-image: url(<?php echo
                                wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()))
                                ?>)">
                                    <article>
                                        <?php $terms = get_the_terms(get_the_ID(), "category") ?>
                                        <span class="subtitle">
                                    دسته بندی
                                        <?php echo $terms[0]->name ?>
                                </span>
                                        <span class="title morabba">
                            <?php echo get_the_title() ?>
                                </span>
                                        <ul class="nav nav-info">
                                            <li class="nav-item">
                                                <div class="icon">
                                                    <i class="icon-calendar"></i>
                                                </div>
                                                <span>
                                        منتشر شده
                                        <b>
                                        <?php echo get_the_date('dS M Y', $post->ID) . ' ' ?>
                                        </b>
                                    </span>
                                            </li>
                                            <li class="nav-item">
                                                <div class="icon">
                                                    <i class="icon-chat"></i>
                                                </div>
                                                <span>
                                        تعداد نظرات
                                      <?php
                                      $comments = get_comment_count(get_the_ID());
                                      ?>
                                        <b>
                                          <?php echo $comments['total_comments']; ?>
                                             نظر ثبت شده
                                        </b>
                                    </span>
                                            </li>
                                        </ul>
                                    </article>
                                </div>
                            </a>
                        </div>

                        <?php
                        $cu++;
                    }
                    $post_count = $the_query->found_posts;
                    $pageintion = (ceil($post_count / 4));
                    ?>
                    <div class="col-12 prl-10px" data-aos="fade-up" data-aos-easing="ease-in-out"
                         data-aos-duration="1000"
                         data-aos-delay="200" data-aos-once="true">
                        <ul class="nav nav-pagination">
                            <style>
                                .active-it {
                                    background-color: #208370!important;
                                    color: #ffffff!important;
                                }
                            </style>

                            <?php for ($c = 1; $c <= $pageintion; $c++) : ?>
                                <li class="nav-item">
                                    <a  onclick="pageSet(<?php echo $c ?> , '<?php echo $my_ob->term_id ?>' , '' ,this)" class="nav-link  <?php echo  $c==1 ? " active-it" : ' '  ?>">
                                        <?php echo $c ?>
                                    </a>
                                </li>
                            <?php endfor; ?>


                        </ul>
                    </div>
                    <?php
                } else {

                }

                wp_reset_postdata();
                ?>


            </div>

        </div>
    </div>
    <!--END-ARTICLES-->

</main>
<!--END-MAIN-->

<?php get_footer() ?>
</body>
</html>
