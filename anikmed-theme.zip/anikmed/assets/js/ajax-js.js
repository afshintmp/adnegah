function categoriesTest(catTerm) {

    jQuery('.loading').fadeIn();
    jQuery.ajax({
        type: 'POST',
        url: ajax_obj.ajax_url,
        // dataType: 'json',
        data: {
            'action': 'jobfinder_post_categories',
            'cat_id': catTerm
        },
        success: function (data) {

            jQuery("#ajax-mode").html(data);
            jQuery('.loading').fadeOut();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            // alert(errorThrown);
        }
    });
}

function postsearch() {
    setTimeout(function () {

        if (jQuery("#post-search").val().length > 2 || jQuery("#post-search").val().length == 0) {
            jQuery('.loading').fadeIn()

            jQuery.ajax({
                type: 'POST',
                url: ajax_obj.ajax_url,
                // dataType: 'json',
                data: {
                    'action': 'jobfinder_post_search',
                    'cat_id': jQuery("#select-val").val(),
                    'search_val': jQuery("#post-search").val()
                },
                success: function (data) {

                    jQuery("#ajax-mode").html(data);
                    jQuery('.loading').fadeOut();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    // alert(errorThrown);
                }
            });

        }
    }, 100);
}

function pageSet(pageInt, catTerm, serachval, elemnt) {
    jQuery('.loading').fadeIn();
    jQuery.ajax({
        type: 'POST',
        url: ajax_obj.ajax_url,
        // dataType: 'json',
        data: {
            'action': 'jobfinder_post_page',
            'page_int': pageInt,
            'cat_id': catTerm,
            'search_val': serachval,
        },
        success: function (data) {

            jQuery("#ajax-mode").html(data);
            jQuery('.loading').fadeOut();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });

}

function propageSet(pageInt, catTerm, searchVal, elemnt) {
    jQuery('.loading').fadeIn()
    jQuery.ajax({
        type: 'POST',
        url: ajax_obj.ajax_url,
        // dataType: 'json',
        data: {
            'action': 'jobfinder_pro_page',
            'page_int': pageInt,
            'cat_id': catTerm,
            'searchVal': searchVal,
        },
        success: function (data) {

            jQuery("#product-ajax").html(data)
            jQuery('.loading').fadeOut();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function proTaxonomy(indexVal) {
    setTimeout(function () {
        jQuery('.loading').fadeIn()

        jQuery.ajax({
            type: 'POST',
            url: ajax_obj.ajax_url,
            // dataType: 'json',
            data: {
                'action': 'jobfinder_product_categories',
                'cat_id': jQuery("#select-val").val()
            },
            success: function (data) {

                jQuery("#product-ajax").html(data);
                jQuery('.loading').fadeOut();
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                // alert(errorThrown);
            }
        });


    }, 100);

}

function proSearch() {
    setTimeout(function () {

        if (jQuery("#search-val").val().length > 2 || jQuery("#post-search").val().length == 0) {
            jQuery('.loading').fadeIn()
            jQuery.ajax({
                type: 'POST',
                url: ajax_obj.ajax_url,
                // dataType: 'json',
                data: {
                    'action': 'jobfinder_pro_search',
                    'cat_id': jQuery("#select-val").val(),
                    'search_val': jQuery("#search-val").val()
                },
                success: function (data) {

                    jQuery("#product-ajax").html(data);
                    jQuery('.loading').fadeOut();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    // alert(errorThrown);
                }
            });
        }

    }, 100);

}

function menuSearchBox() {

    setTimeout(function () {
        jQuery('.loading-box').show();
        jQuery(".a-res").hide()
        if (jQuery("#menu-search-box").val().length > 0) {
            jQuery(".ul-results").show()
        }
        // alert(jQuery("#menu-search-box").val().length)
        if (jQuery("#menu-search-box").val().length == 0) {
            jQuery(".ul-results").hide()
        }
        if (jQuery("#menu-search-box").val().length > 2) {

            jQuery.ajax({
                type: 'POST',
                url: ajax_obj.ajax_url,
                // dataType: 'json',
                data: {
                    'action': 'jobfinder_menu_search',

                    'search_val': jQuery("#menu-search-box").val()
                },
                success: function (data) {

                    jQuery(".a-res").html(data);
                    jQuery('.a-res').show();
                    jQuery('.loading-box').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    // alert(errorThrown);
                }
            });
            // alert(jQuery("#menu-search-box").val())
        }


    }, 100);
}