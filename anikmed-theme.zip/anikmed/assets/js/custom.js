var $ = jQuery
/* SELECT 2*/
/* SELECT 2*/
/* SELECT 2*/
$(document).ready(function() {
    $('.js-example-basic-single').select2({
        dir:'rtl',
    });
});


$('.btn-menu , .btn-product').click(function () {
    $('.menu-responsive').fadeIn();
    $('.menu-responsive').addClass('show')
})
$('.btn-menu').click(function () {
    $('.menu-responsive').find('.nav-category').hide()
    $('.menu-responsive').find('.nav-menu').show()
})
$('.btn-product').click(function () {
    $('.menu-responsive').find('.nav-menu').hide()
    $('.menu-responsive').find('.nav-category').show()
})
$('.menu-responsive .btn-close').click(function () {
    $('.menu-responsive').fadeOut();
    $('.menu-responsive').removeClass('show')
})


$('.show-popup-video').click(function () {
    $('.video-popup').fadeIn()
})
$('.video-popup .btn-close').click(function () {
    $('.video-popup').fadeOut()
})
$(document).ready(function(){
    // clicking button with class "category-button"
    $(".tab-item").click(function(){
        // get the data-filter value of the button
        var filterValue = $(this).attr('data-filter');

        $('.filter-item').not('.'+filterValue).hide();
        $('.filter-item').filter('.'+filterValue).show();

        $(this).parent().find('.active').removeClass('active')
        $(this).addClass('active');
    });
});

var swipermainslide = new Swiper('.swiper-main-slide', {
    spaceBetween: 0,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-main-slide',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-main-slide',
        prevEl: '.swiper-button-prev-main-slide',
    },
});

var swiperbrands = new Swiper('.swiper-brands', {
    spaceBetween: 20,
    slidesPerView: 7,
    pagination: {
        el: '.swiper-pagination-brands',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-brands',
        prevEl: '.swiper-button-prev-brands',
    },
    breakpoints: {
        992 : {
            spaceBetween: 15,
            slidesPerView: 'auto',
            freeMode:true,
        },
        1200 : {
            slidesPerView: 5,

        },
    }
});

var swiperproducts = new Swiper('.swiper-products', {
    spaceBetween: 20,
    slidesPerView: 3,
    pagination: {
        el: '.swiper-pagination-products',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-products',
        prevEl: '.swiper-button-prev-products',
    },
    breakpoints: {
        992 : {
            spaceBetween: 15,
            slidesPerView: 'auto',
            freeMode:true,
        },
        1200 : {
            slidesPerView: 2,
        },
    }
});

var swiperopinion = new Swiper('.swiper-opinion', {
    spaceBetween: 0,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-opinion',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-opinion',
        prevEl: '.swiper-button-prev-opinion',
    },
});

var thumbs = new Swiper('.swiper-a-thumbs', {
    spaceBetween: 15,
    slidesPerView: 1,
    watchSlidesVisibility: true,
    watchSlidesProgress: true,
});
var sync = new Swiper('.swiper-a-sync', {
    spaceBetween: 15,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-a-sync',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-a-sync',
        prevEl: '.swiper-button-prev-a-sync',
    },
    thumbs: {
        swiper: thumbs,
    },
});

var swipertestimonial = new Swiper('.swiper-testimonial', {
    spaceBetween: 50,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-testimonial',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-testimonial',
        prevEl: '.swiper-button-prev-testimonial',
    },
    breakpoints: {
        992 : {
            slidesPerView: 'auto',
            freeMode:true,
        },
    }
});

var swiperblog = new Swiper('.swiper-blog', {
    spaceBetween: 20,
    slidesPerView: 2,
    pagination: {
        el: '.swiper-pagination-blog',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-blog',
        prevEl: '.swiper-button-prev-blog',
    },
    breakpoints: {
        1200 : {
            slidesPerView: 1,
        },
    }
});

var swipermainsingle = new Swiper('.swiper-single', {
    spaceBetween: 0,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-single',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-single',
        prevEl: '.swiper-button-prev-single',
    },
});