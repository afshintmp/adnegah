<?php
if (isset($_POST['mysave'])) {

    var_dump("ok");
    if (!empty($_POST['slider-img'])) {
        update_option('slider-img', $_POST['slider-img']);
    } else {
        update_option('slider-img', DU . '/assets/img/Logo.png');
    }

    update_option('slider-alt', $_POST['slider-alt']);

    update_option('sliderone', $_POST['sliderone']);
    update_option('slidertwo', $_POST['slidertwo']);
    update_option('slidertree', $_POST['slidertree']);
    update_option('sliderfour', $_POST['slidertfour']);

    update_option('s-1-b-1-1', $_POST['s-1-b-1-1']);
    update_option('s-1-b-1-2', $_POST['s-1-b-1-2']);
    update_option('s-1-b-2-1', $_POST['s-1-b-2-1']);
    update_option('s-1-b-2-2', $_POST['s-1-b-2-2']);

    update_option('s-2-b-1-1', $_POST['s-2-b-1-1']);
    update_option('s-2-b-1-2', $_POST['s-2-b-1-2']);
    update_option('s-2-b-2-1', $_POST['s-2-b-2-1']);
    update_option('s-2-b-2-2', $_POST['s-2-b-2-2']);

    update_option('s-3-b-1-1', $_POST['s-3-b-1-1']);
    update_option('s-3-b-1-2', $_POST['s-3-b-1-2']);
    update_option('s-3-b-2-1', $_POST['s-3-b-2-1']);
    update_option('s-3-b-2-2', $_POST['s-3-b-2-2']);

    update_option('s-4-b-1-1', $_POST['s-4-b-1-1']);
    update_option('s-4-b-1-2', $_POST['s-4-b-1-2']);
    update_option('s-4-b-2-1', $_POST['s-4-b-2-1']);
    update_option('s-4-b-2-2', $_POST['s-4-b-2-2']);

}


$slider_img = get_option('slider-img');

$slider_alt = get_option('slider-alt');

$sliderone = get_option('sliderone');

$slidertwo = get_option('slidertwo');
$slidertree = get_option('slidertree');
$sliderfour = get_option('sliderfour');


$s_1_b_1_1 = get_option('s-1-b-1-1');

$s_1_b_1_2 = get_option('s-1-b-1-2');
$s_1_b_2_1 = get_option('s-1-b-2-1');
$s_1_b_2_2 = get_option('s-1-b-2-2');

$s_2_b_1_1 = get_option('s-2-b-1-1');
$s_2_b_1_2 = get_option('s-2-b-1-2');
$s_2_b_2_1 = get_option('s-2-b-2-1');
$s_2_b_2_2 = get_option('s-2-b-2-2');

$s_3_b_1_1 = get_option('s-3-b-1-1');
$s_3_b_1_2 = get_option('s-3-b-1-2');
$s_3_b_2_1 = get_option('s-3-b-2-1');
$s_3_b_2_2 = get_option('s-3-b-2-2');

$s_4_b_1_1 = get_option('s-4-b-1-1');
$s_4_b_1_2 = get_option('s-4-b-1-2');
$s_4_b_2_1 = get_option('s-4-b-2-1');
$s_4_b_2_2 = get_option('s-4-b-2-2');

?>
<style>
    .upload{
        margin-bottom: 15px;
    }
    .clear-fix {
        clear: both;
    }

    .slider-controller {
        width: calc(50% - 10px);
        display: inline-block;
    }

    .slider-controller > .slider-controller-child {
        background: #fff;
        -webkit-border-radius: 10px;
        -moz-border-radius: 10px;
        border-radius: 10px;
        margin-right: 10px;
        margin-left: 10px;
        position: relative;
        overflow: hidden;
    }

    .meta {
        position: absolute;
        bottom: 40px;
        right: 0;
        width: 100%;
        display: inline-block;
        vertical-align: top;
        margin-right: 10px;
    }

    .meta-field {
        width: calc(50% - 15px);
    }

    .editor-slider {
        width: 100%;
        display: inline-block;
        vertical-align: top
    }

    .slider-tt {
        padding-top: 10px;
        padding-right: 15px;
        font-weight: bold;
    }
</style>
<div class="setting-col">


    <form action="" name="editorForm" method="post">

        <div>

            <div class="m-l-2">

                <div class="upload m-l-2 guid-fire" data-guid="img-upload">
                    <p class="font-bold">
                        عکس اسلایدر :
                    </p>
                    <img data-src="<?php echo DU . '/assets/img/shape-1.png' ?>"
                         src="<?php echo !empty($slider_img) ? $slider_img : DU . '/assets/img/shape-1.png' ?>"
                         width="400"
                         height=""/>
                    <div style="margin-bottom: 20px;">
                        <p class="font-bold">متن جایگزین :
                        </p>
                        <input type="text" id="imga-alt" style="width: 400px;" name="slider-alt" value="<?php echo $slider_alt ?>">
                    </div>
                    <div>
                        <input type="hidden" name="slider-img" id="RssFeedIcon_settings"
                               value="<?php echo !empty($slider_img) ? $slider_img : DU . '/assets/img/shape-1.png' ?>"/>
                        <button type="submit" class="upload_image_button button">افزودن</button>
                        <button type="submit" class="remove_image_button button">&times;</button>
                    </div>
                </div>

            </div>
            <div class="slider-controller">
                <div class="slider-controller-child">
                    <p class="slider-tt">
                        اسلایدر اول :
                    </p>
                    <div class="editor-slider">

                        <?php

                        $settings = array('media_buttons' => false);


                        $editor_id = 'sliderone';
                        $content = $sliderone;
                        wp_editor($content, $editor_id, $settings);

                        ?>
                    </div>
                    <div class="meta">
                        <hr>
                        <hr>

                        <input class="meta-field" type="text" placeholder="متن دکمه اول" name="s-1-b-1-1"
                               value="<?php echo $s_1_b_1_1 ?>">

                        <input class="meta-field" placeholder="لینک دکمه ی اول" name="s-1-b-1-2"
                               value="<?php echo $s_1_b_1_2 ?>">
                        <hr>
                        <hr>
                        <input class="meta-field" type="text" placeholder="متن دکمه ی دوم" name="s-1-b-2-1"
                               value="<?php echo $s_1_b_2_1 ?>">

                        <input class="meta-field" type="text" placeholder="لینک دکمه ی دوم" name="s-1-b-2-2"
                               value="<?php echo $s_1_b_2_2 ?>">
                    </div>

                </div>
            </div>
            <div class="slider-controller">
                <div class="slider-controller-child">
                    <p class="slider-tt">
                        اسلایدر دوم :
                    </p>
                    <div class="editor-slider">

                        <?php
                        $content = $slidertwo;
                        $editor_id = 'slidertwo';

                        wp_editor($content, $editor_id, $settings);

                        ?>
                    </div>
                    <div class="meta">
                        <hr>
                        <hr>

                        <input class="meta-field" type="text" placeholder="متن دکمه اول" name="s-2-b-1-1" value="<?php echo $s_2_b_1_1 ?>">

                        <input class="meta-field" placeholder="لینک دکمه ی اول" name="s-2-b-1-2" value="<?php echo $s_2_b_1_2 ?>">
                        <hr>
                        <hr>
                        <input class="meta-field" type="text" placeholder="متن دکمه ی دوم" name="s-2-b-2-1" value="<?php echo $s_2_b_2_1 ?>">

                        <input class="meta-field" type="text" placeholder="لینک دکمه ی دوم" name="s-2-b-2-2" value="<?php echo $s_2_b_2_2 ?>">
                    </div>

                </div>
            </div>
            <div class="slider-controller">
                <div class="slider-controller-child">
                    <p class="slider-tt">
                        اسلایدر سوم :
                    </p>
                    <div class="editor-slider">

                        <?php
                        $content = $slidertree;
                        $editor_id = 'slidertree';

                        wp_editor($content, $editor_id, $settings);

                        ?>
                    </div>
                    <div class="meta">
                        <hr>
                        <hr>

                        <input class="meta-field" type="text" placeholder="متن دکمه اول" name="s-3-b-1-1" value="<?php echo $s_3_b_1_1 ?>">

                        <input class="meta-field" placeholder="لینک دکمه ی اول" name="s-3-b-1-2" value="<?php echo $s_3_b_1_2 ?>">
                        <hr>
                        <hr>
                        <input class="meta-field" type="text" placeholder="متن دکمه ی دوم" name="s-3-b-2-1" value="<?php echo $s_3_b_2_1 ?>">

                        <input class="meta-field" type="text" placeholder="لینک دکمه ی دوم" name="s-3-b-2-2" value="<?php echo $s_3_b_2_2 ?>">
                    </div>

                </div>
            </div>
            <div class="slider-controller">
                <div class="slider-controller-child">
                    <p class="slider-tt">
                        اسلایدر چهارم :
                    </p>
                    <div class="editor-slider">

                        <?php
                        $content = $sliderfour;
                        $editor_id = 'sliderfour';

                        wp_editor($content, $editor_id, $settings);

                        ?>
                    </div>
                    <div class="meta">
                        <hr>
                        <hr>

                        <input class="meta-field" type="text" placeholder="متن دکمه اول" name="s-4-b-1-1" value="<?php echo $s_4_b_1_1 ?>">

                        <input class="meta-field" placeholder="لینک دکمه ی اول" name="s-4-b-1-2" value="<?php echo $s_4_b_1_2 ?>">
                        <hr>
                        <hr>
                        <input class="meta-field" type="text" placeholder="متن دکمه ی دوم" name="s-4-b-2-1" value="<?php echo $s_4_b_2_1 ?>">

                        <input class="meta-field" type="text" placeholder="لینک دکمه ی دوم" name="s-4-b-2-2" value="<?php echo $s_4_b_2_2 ?>">
                    </div>

                </div>
            </div>
            <div>
                <input type="submit" style="margin-top: 15px" name="mysave" value="ذخیره">

            </div>
        </div>


    </form>
</div>


<script>
    jQuery('.upload_image_button').click(function (e) {
        e.preventDefault()
        var send_attachment_bkp = wp.media.editor.send.attachment;
        var button = jQuery(this);
        wp.media.editor.send.attachment = function (props, attachment) {
            jQuery(button).parent().prev().attr('src', attachment.url);
            jQuery("#imga-alt").val(attachment.alt)
            jQuery(button).prev().val(attachment.url);
            wp.media.editor.send.attachment = send_attachment_bkp;
        }
        wp.media.editor.open(button);
        return false;
    });
    jQuery('.remove_image_button').click(function () {
        var answer = confirm('Are you sure?');
        if (answer == true) {
            var src = jQuery(this).parent().prev().attr('data-src');
            jQuery(this).parent().prev().attr('src', src);
            jQuery(this).prev().prev().val('');
        }
        return false;
    });
</script>