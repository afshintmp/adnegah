<?php
if (isset($_POST['save'])) {


    if (!empty($_POST['logo-img'])) {
        update_option('logo-img', $_POST['logo-img']);
    } else {
        update_option('logo-img', DU . '/assets/img/Logo.png');
    }


    update_option('copy-write-text', $_POST['copy-write-text']);

    update_option('footer-address', $_POST['footer-address']);
    update_option('footer-phone-number', $_POST['footer-phone-number']);
    update_option('footer-email', $_POST['footer-email']);


    update_option('instagram-link', $_POST['instagram-link']);

    update_option('whatsapp-link', $_POST['whatsapp-link']);
    update_option('telegram-link', $_POST['telegram-link']);
    update_option('google-map', $_POST['google-map']);


}


$logo_img = get_option('logo-img');

$copy_write_text = get_option('copy-write-text');

$footer_email = get_option('footer-email');
$footer_phone_number = get_option('footer-phone-number');
$footer_address = get_option('footer-address');


$instagram_link = get_option('instagram-link');
$whatsapp_link = get_option('whatsapp-link');

$telegram_link = get_option('telegram-link');
$google_map = get_option('google-map');

?>
<div class="setting-col">

    <form action="" method="post">

        <div>

            <div class="m-l-2">

                <div class="upload m-l-2 guid-fire" data-guid="img-upload">
                    <p class="font-bold">
                        بارگزاری لگو :
                    </p>
                    <img data-src="<?php echo DU . '/assets/img/Logo.png' ?>"
                         src="<?php echo !empty($logo_img) ? $logo_img : DU . '/assets/img/Logo.png' ?>" width="150"
                         height=""/>
                    <div>
                        <input type="hidden" name="logo-img" id="RssFeedIcon_settings"
                               value="<?php echo !empty($logo_img) ? $logo_img : DU . '/assets/img/Logo.png' ?>"/>
                        <button type="submit" class="upload_image_button button">افزودن</button>
                        <button type="submit" class="remove_image_button button">&times;</button>
                    </div>
                </div>

            </div>
            <div style="margin-top: 15px;">
                <label style="vertical-align:top;margin-top: 15px; " for="">متن فوتر :</label>
                <textarea style="display: block;margin-top: 5px;width: 400px;" name="copy-write-text" id="" cols="30"
                          rows="10"><?php echo $copy_write_text ?></textarea>
            </div>
            <div style="margin-top: 15px;">
                <label for="">ادرس</label>
                <textarea name="footer-address"
                          style="display: block;width: 400px;height: 150px;"><?php echo $footer_address ?></textarea>

            </div>
            <div style="margin-top: 15px;">
                <label for="">شماره تماس</label>
                <input style="display: block;width: 400px;text-align: left;direction: ltr" type="text"
                       name="footer-phone-number" value="<?php echo $footer_phone_number ?>">
            </div>
            <div style="margin-top: 15px;">
                <label for="">ایمیل</label>
                <input style="display: block;width: 400px;text-align: left;direction: ltr" type="text"
                       name="footer-email" value="<?php echo $footer_email ?>">
            </div>


            <div style="margin-top: 15px;">
                <label for="">لینک واتس اپ</label>
                <input style="display: block;width: 400px;text-align: left;direction: ltr" type="text"
                       name="whatsapp-link" value="<?php echo $whatsapp_link ?>">
            </div>
            <div style="margin-top: 15px;">
                <label for="">لینک اینستاگرام</label>
                <input style="display: block;width: 400px;text-align: left;direction: ltr" type="text"
                       name="instagram-link" value="<?php echo $instagram_link ?>">
            </div>
            <div style="margin-top: 15px;">
                <label for="">لینک تلگرام</label>
                <input style="display: block;width: 400px;text-align: left;direction: ltr" type="text"
                       name="telegram-link" value="<?php echo $telegram_link ?>">
            </div>


            <div style="margin-top: 15px;">
                <label for="">لینک گوگل مپ</label>
                <textarea name="google-map" style="display: block;width: 400px;height: 200px;text-align: left;direction: ltr" ><?php echo $google_map ?></textarea>

            </div>
            <div>
                <input type="submit" style="margin-top: 15px" name="save" value="ذخیره">
            </div>
        </div>


    </form>
</div>


<script>
    jQuery('.upload_image_button').click(function (e) {
        e.preventDefault()
        var send_attachment_bkp = wp.media.editor.send.attachment;
        var button = jQuery(this);
        wp.media.editor.send.attachment = function (props, attachment) {
            jQuery(button).parent().prev().attr('src', attachment.url);
            jQuery(button).prev().val(attachment.url);
            wp.media.editor.send.attachment = send_attachment_bkp;
        }
        wp.media.editor.open(button);
        return false;
    });
    jQuery('.remove_image_button').click(function () {
        var answer = confirm('Are you sure?');
        if (answer == true) {
            var src = jQuery(this).parent().prev().attr('data-src');
            jQuery(this).parent().prev().attr('src', src);
            jQuery(this).prev().prev().val('');
        }
        return false;
    });
</script>