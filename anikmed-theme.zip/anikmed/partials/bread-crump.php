<!--START-BREAD-CRUMB-->
<div class="bread-crumb" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
     data-aos-delay="0" data-aos-once="true">
    <div class="container d-flex align-items-center justify-content-between flex-wrap">
            <span class="title morabba" data-aos="fade-down" data-aos-easing="ease-in-out" data-aos-duration="1000"
                  data-aos-delay="600" data-aos-once="true">
                 <?php echo get_the_title() ?>
            </span>
        <ul class="nav" data-aos="fade-down" data-aos-easing="ease-in-out" data-aos-duration="1000"
            data-aos-delay="700" data-aos-once="true">
            <li class="nav-item">
                <a href="<?php echo get_home_url() ?>" class="nav-link">
                    <i class="icon-house"></i>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php ?>" class="nav-link">
                    <?php echo get_the_title() ?>
                </a>
            </li>
        </ul>

    </div>
</div>
<!--END-BREAD-CRUMB-->