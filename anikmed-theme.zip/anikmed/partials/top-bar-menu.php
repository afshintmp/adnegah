<?php global $options;
$logo_img = get_option('logo-img');

?>
<!--START-MENU-RESPONSIVE-->
<div class="menu-responsive">
    <div class="container position-relative">
        <button class="btn btn-close">
            <i class="icon-close"></i>
        </button>
        <a href="<?php echo get_home_url() ?>" class="brand">
            <img src="<?php echo DU . '/assets/img/logo-white.png' ?>" alt="انیک مد">
        </a>
        <?php wp_nav_menu(array(
            'container' => "ul",
            'theme_location' => "top_bar_menu",
            'menu_class' => "nav nav-menu"
        )); ?>



        <?php wp_nav_menu(array(
            'container' => "ul",
            'theme_location' => "category_menu",
            'menu_class' => "nav nav-category"
        )); ?>


    </div>
</div>
<!--END-MENU-RESPONSIVE-->

<!--START-HEADER-->
<header class="header" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0"
        data-aos-once="true">
    <div class="container d-flex align-items-center">
        <a href="<?php echo get_home_url() ?>" class="brand" data-aos="fade-down" data-aos-easing="ease-in-out"
           data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
            <img src="<?php echo $logo_img ?>" alt="">
        </a>
        <div class="bars">
            <div class="top-bar d-none d-lg-block" data-aos="fade-down" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">

                <?php wp_nav_menu(array(
                    'container' => "ul",
                    'theme_location' => "top_bar_menu",
                    'menu_class' => "nav"
                )); ?>

                <div class="lines">
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </div>
            <div class="bottom-bar" data-aos="fade-down" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="400" data-aos-once="true">
                <?php wp_nav_menu(array(
                    'container' => "ul",
                    'theme_location' => "category_menu",
                    'menu_class' => "nav  d-none d-lg-flex"
                )); ?>

                <!--START-CHANGE-->
                <form action="">
                    <div class="form-group">
                        <input class="__has-results" id="menu-search-box" type="text" onkeyup="menuSearchBox()"
                               placeholder="جستجو را شروع کنید . . .">

                        <div class="ul-results" style="display: none">
                            <div class="a-res"></div>
                            <div class="loading-box">
                            <span class="text">
                              برای جستجو حداقل 3 کاراکتر را وارد کنید ...
                            </span>
                                <svg class="spinner" width="35px" height="35px" viewBox="0 0 66 66"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33"
                                            cy="33"
                                            r="30"></circle>
                                </svg>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-search">
                        <i class="icon-search"></i>
                    </button>
                </form>
                <!--END-CHANGE-->
                <!--  <form action="">
                      <div class="form-group position-relative">
                          <input type="text" id="menu-search-box" onkeyup="menuSearchBox()" placeholder="جستجو را شروع کنید . . .">

                      </div>

                      <button class="btn btn-search">
                          <i class="icon-search"></i>
                      </button>
                  </form>-->
            </div>
        </div>
        <div class="mobile-bar d-flex d-lg-none">
            <button class="btn btn-menu">
                <i class="icon-menu"></i>
                مشاهده منو
            </button>
            <button class="btn btn-product">
                دسته بندی محصولات
            </button>
        </div>
    </div>
</header>
<!--END-HEADER-->