<?php

function jobfinder_post_categories()
{
    $cat_id = $_POST['cat_id'];
    $search_val = $_POST['search_val'];

    if ($cat_id == 0) {
        $args = array(
            'posts_per_page' => 4,
            'post_type' => 'post',


        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }
    } else {
        $args = array(
            'posts_per_page' => 4,
            'post_type' => 'post',
            'tax_query' => array(array(
                'taxonomy' => 'category',
                'terms' => $cat_id,
            ),)
        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }

    }


    $the_query = new WP_Query($args);
    $cu = 1;
    if ($the_query->have_posts()) {

        while ($the_query->have_posts()) {
            $the_query->the_post();
            if ($cu == 1 || $cu == 4) {
                $wrapper_class = "col-xl-7  ";
            } else {
                $wrapper_class = "col-xl-5  ";

            }
            ?>


            <div class="<?php echo $wrapper_class ?> col-md-6 prl-10px" data-aos="fade-up"
                 data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <a href="<?php echo get_the_permalink() ?>" class="item">
                    <div class="img" style="background-image: url(<?php echo
                    wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()))
                    ?>)">
                        <article>
                            <?php $terms = get_the_terms(get_the_ID(), "category") ?>
                            <span class="subtitle">
                                    دسته بندی
                                        <?php echo $terms[0]->name ?>
                                </span>
                            <span class="title morabba">
                            <?php echo get_the_title() ?>
                                </span>
                            <ul class="nav nav-info">
                                <li class="nav-item">
                                    <div class="icon">
                                        <i class="icon-calendar"></i>
                                    </div>
                                    <span>
                                        منتشر شده
                                        <b>
                                        <?php echo get_the_date('dS M Y', get_the_ID()) . ' ' ?>
                                        </b>
                                    </span>
                                </li>
                                <li class="nav-item">
                                    <div class="icon">
                                        <i class="icon-chat"></i>
                                    </div>
                                    <span>
                                        تعداد نظرات
                                      <?php
                                      $comments = get_comment_count(get_the_ID());
                                      ?>
                                        <b>
                                          <?php echo $comments['total_comments']; ?>
                                             نظر ثبت شده
                                        </b>
                                    </span>
                                </li>
                            </ul>
                        </article>
                    </div>
                </a>
            </div>

            <?php
            $cu++;
        }

        $post_count = $the_query->found_posts;
        $pageintion = (ceil($post_count / 4));
        ?>
        <div class="col-12 prl-10px" data-aos="fade-up" data-aos-easing="ease-in-out"
             data-aos-duration="1000"
             data-aos-delay="200" data-aos-once="true">
            <ul class="nav nav-pagination">
                <style>
                    .active-it {
                        background-color: #208370 !important;
                        color: #ffffff !important;
                    }
                </style>

                <?php for ($c = 1; $c <= $pageintion; $c++) : ?>
                    <li class="nav-item remove-active ">
                        <a onclick="pageSet(<?php echo $c ?> , '<?php echo $cat_id ?>' ,'<?php echo $search_val ?>' ,this)"
                           class="nav-link <?php echo $c == 1 ? " active-it" : ' ' ?>">
                            <?php echo $c ?>
                        </a>
                    </li>
                <?php endfor; ?>


            </ul>
        </div>
        <?php
    } else {

    }

    wp_reset_postdata();
    wp_die();

}

add_action('wp_ajax_jobfinder_post_categories', 'jobfinder_post_categories');
add_action('wp_ajax_nopriv_jobfinder_post_categories', 'jobfinder_post_categories');


function jobfinder_post_search()
{
    $cat_id = $_POST['cat_id'];
    $search_val = $_POST['search_val'];

    if ($cat_id == 0) {
        $args = array(
            'posts_per_page' => 4,
            'post_type' => 'post',


        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }
    } else {
        $args = array(
            'posts_per_page' => 4,
            'post_type' => 'post',
            'tax_query' => array(array(
                'taxonomy' => 'category',
                'terms' => $cat_id,
            ),)
        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }

    }


    $the_query = new WP_Query($args);
    $cu = 1;
    if ($the_query->have_posts()) {

        while ($the_query->have_posts()) {
            $the_query->the_post();
            if ($cu == 1 || $cu == 4) {
                $wrapper_class = "col-xl-7  ";
            } else {
                $wrapper_class = "col-xl-5  ";

            }
            ?>


            <div class="<?php echo $wrapper_class ?> col-md-6 prl-10px" data-aos="fade-up"
                 data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <a href="<?php echo get_the_permalink() ?>" class="item">
                    <div class="img" style="background-image: url(<?php echo
                    wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()))
                    ?>)">
                        <article>
                            <?php $terms = get_the_terms(get_the_ID(), "category") ?>
                            <span class="subtitle">
                                    دسته بندی
                                        <?php echo $terms[0]->name ?>
                                </span>
                            <span class="title morabba">
                            <?php echo get_the_title() ?>
                                </span>
                            <ul class="nav nav-info">
                                <li class="nav-item">
                                    <div class="icon">
                                        <i class="icon-calendar"></i>
                                    </div>
                                    <span>
                                        منتشر شده
                                        <b>
                                        <?php echo get_the_date('dS M Y', get_the_ID()) . ' ' ?>
                                        </b>
                                    </span>
                                </li>
                                <li class="nav-item">
                                    <div class="icon">
                                        <i class="icon-chat"></i>
                                    </div>
                                    <span>
                                        تعداد نظرات
                                      <?php
                                      $comments = get_comment_count(get_the_ID());
                                      ?>
                                        <b>
                                          <?php echo $comments['total_comments']; ?>
                                             نظر ثبت شده
                                        </b>
                                    </span>
                                </li>
                            </ul>
                        </article>
                    </div>
                </a>
            </div>

            <?php
            $cu++;
        }

        $post_count = $the_query->found_posts;
        $pageintion = (ceil($post_count / 4));
        ?>
        <div class="col-12 prl-10px" data-aos="fade-up" data-aos-easing="ease-in-out"
             data-aos-duration="1000"
             data-aos-delay="200" data-aos-once="true">
            <ul class="nav nav-pagination">
                <style>
                    .active-it {
                        background-color: #208370 !important;
                        color: #ffffff !important;
                    }
                </style>

                <?php for ($c = 1; $c <= $pageintion; $c++) : ?>
                    <li class="nav-item remove-active ">
                        <a onclick="pageSet(<?php echo $c ?> , '<?php echo $cat_id ?>' ,'<?php echo $search_val ?>' ,this)"
                           class="nav-link <?php echo $c == 1 ? " active-it" : ' ' ?>">
                            <?php echo $c ?>
                        </a>
                    </li>
                <?php endfor; ?>


            </ul>
        </div>
        <?php
    } else {

    }

    wp_reset_postdata();
    wp_die();
}

add_action('wp_ajax_jobfinder_post_search', 'jobfinder_post_search');
add_action('wp_ajax_nopriv_jobfinder_post_search', 'jobfinder_post_search');

function jobfinder_post_page()
{
    $cat_id = $_POST['cat_id'];
    $page_int = $_POST['page_int'];
    $search_val = $_POST['search_val'];
    $offset = ($page_int - 1) * 4;
    if ($cat_id == 0) {
        $args = array(
            'posts_per_page' => 4,
            'post_type' => 'post',
            'offset' => $offset,

        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }
    } else {
        $args = array(
            'posts_per_page' => 4,
            'post_type' => 'post',
            'offset' => $offset,
            'tax_query' => array(array(
                'taxonomy' => 'category',
                'terms' => $cat_id,
            ),)
        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }

    }


    $the_query = new WP_Query($args);
    $cu = 1;
    if ($the_query->have_posts()) {

        while ($the_query->have_posts()) {
            $the_query->the_post();
            if ($cu == 1 || $cu == 4) {
                $wrapper_class = "col-xl-7  ";
            } else {
                $wrapper_class = "col-xl-5  ";

            }
            ?>


            <div class="<?php echo $wrapper_class ?> col-md-6 prl-10px" data-aos="fade-up"
                 data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <a href="<?php echo get_the_permalink() ?>" class="item">
                    <div class="img" style="background-image: url(<?php echo
                    wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()))
                    ?>)">
                        <article>
                            <?php $terms = get_the_terms(get_the_ID(), "category") ?>
                            <span class="subtitle">
                                    دسته بندی
                                        <?php echo $terms[0]->name ?>
                                </span>
                            <span class="title morabba">
                            <?php echo get_the_title() ?>
                                </span>
                            <ul class="nav nav-info">
                                <li class="nav-item">
                                    <div class="icon">
                                        <i class="icon-calendar"></i>
                                    </div>
                                    <span>
                                        منتشر شده
                                        <b>
                                        <?php echo get_the_date('dS M Y', get_the_ID()) . ' ' ?>
                                        </b>
                                    </span>
                                </li>
                                <li class="nav-item">
                                    <div class="icon">
                                        <i class="icon-chat"></i>
                                    </div>
                                    <span>
                                        تعداد نظرات
                                      <?php
                                      $comments = get_comment_count(get_the_ID());
                                      ?>
                                        <b>
                                          <?php echo $comments['total_comments']; ?>
                                             نظر ثبت شده
                                        </b>
                                    </span>
                                </li>
                            </ul>
                        </article>
                    </div>
                </a>
            </div>

            <?php
            $cu++;
        }

        $post_count = $the_query->found_posts;
        $pageintion = (ceil($post_count / 4));
        ?>
        <div class="col-12 prl-10px" data-aos="fade-up" data-aos-easing="ease-in-out"
             data-aos-duration="1000"
             data-aos-delay="200" data-aos-once="true">
            <ul class="nav nav-pagination">
                <style>
                    .active-it {
                        background-color: #208370 !important;
                        color: #ffffff !important;
                    }
                </style>

                <?php for ($c = 1; $c <= $pageintion; $c++) : ?>
                    <li class="nav-item remove-active ">
                        <a onclick="pageSet(<?php echo $c ?> , '<?php echo $cat_id ?>' , '<?php echo $search_val ?>' ,this)"
                           class="nav-link <?php echo $c == $page_int ? " active-it" : ' ' ?>">
                            <?php echo $c ?>
                        </a>
                    </li>
                <?php endfor; ?>


            </ul>
        </div>
        <?php
    } else {

    }

    wp_reset_postdata();
    wp_die();

}

add_action('wp_ajax_jobfinder_post_page', 'jobfinder_post_page');
add_action('wp_ajax_nopriv_jobfinder_post_page', 'jobfinder_post_page');


function jobfinder_product_categories()
{
    $cat_id = $_POST['cat_id'];

    $search_val = $_POST['search_val'];

    if ($cat_id == 0) {
        $args = array(
            'posts_per_page' => 9,
            'post_type' => 'product',


        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }
    } else {
        $args = array(
            'posts_per_page' => 9,
            'post_type' => 'product',

            'tax_query' => array(array(
                'taxonomy' => 'pro-cats',
                'terms' => $cat_id,
            ),)
        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }
    }
    $the_query = new WP_Query($args);
    if ($the_query->have_posts()) {

        while ($the_query->have_posts()) {
            $the_query->the_post();
            ?>
            <div class="col-lg-4 col-sm-6 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <div class="item">
                    <div class="bg">
                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id(get_the_ID())) ?>"
                             alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">

                        <div class="name morabba">
                            <?php echo get_the_title() ?>
                        </div>
                        <?php $pro_category = get_the_terms(get_the_ID(), "pro-cats");

                        if ($pro_category) :
                            ?>
                            <div class="subtitle">
                                <?php echo $pro_category[0]->name ?>

                            </div>
                        <?php endif; ?>

                        <a href="<?php echo get_the_permalink() ?>" class="more">
                            مشاهده جزئیات
                            <i class="icon-1-left-circle"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        <div class="col-12 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
             data-aos-duration="1000"
             data-aos-delay="200" data-aos-once="true">
            <style>
                .active-it {
                    background-color: #208370 !important;
                    color: #ffffff !important;
                }
            </style>

            <ul class="nav nav-pagination">

                <?php $post_count = $the_query->found_posts;
                $pageintion = (ceil($post_count / 9)); ?>
                <?php for ($c = 1; $c <= $pageintion; $c++) : ?>
                    <li class="nav-item">
                        <a onclick="propageSet(<?php echo $c ?> , '<?php echo $cat_id ?>','<?php echo $search_val ?>' ,this)"
                           class="nav-link  <?php echo $c == 1 ? " active-it" : ' ' ?>">
                            <?php echo $c ?>
                        </a>
                    </li>
                <?php endfor; ?>


            </ul>
        </div>
        <?php
    } else {

    }

    wp_reset_postdata();
    wp_die();

}

add_action('wp_ajax_jobfinder_product_categories', 'jobfinder_product_categories');
add_action('wp_ajax_nopriv_jobfinder_product_categories', 'jobfinder_product_categories');


function jobfinder_pro_page()
{
    $cat_id = $_POST['cat_id'];
    $page_int = $_POST['page_int'];
    $search_val = $_POST['search_val'];

    $offset = ($page_int - 1) * 9;
    if ($cat_id == 0) {
        $args = array(
            'posts_per_page' => 9,
            'post_type' => 'product',
            'offset' => $offset,

        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }
    } else {
        $args = array(
            'posts_per_page' => 9,
            'post_type' => 'product',
            'offset' => $offset,
            'tax_query' => array(array(
                'taxonomy' => 'pro-cats',
                'terms' => $cat_id,
            ),)
        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }

    }


    $the_query = new WP_Query($args);
    $cu = 1;
    if ($the_query->have_posts()) {

        while ($the_query->have_posts()) {
            $the_query->the_post();
            ?>
            <div class="col-lg-4 col-sm-6 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <div class="item">
                    <div class="bg">
                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id(get_the_ID())) ?>"
                             alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">

                        <div class="name morabba">
                            <?php echo get_the_title() ?>
                        </div>
                        <?php $pro_category = get_the_terms(get_the_ID(), "pro-cats");

                        if ($pro_category) :
                            ?>
                            <div class="subtitle">
                                <?php echo $pro_category[0]->name ?>

                            </div>
                        <?php endif; ?>

                        <a href="<?php echo get_the_permalink() ?>" class="more">
                            مشاهده جزئیات
                            <i class="icon-1-left-circle"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        <div class="col-12 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
             data-aos-duration="1000"
             data-aos-delay="200" data-aos-once="true">
            <style>
                .active-it {
                    background-color: #208370 !important;
                    color: #ffffff !important;
                }
            </style>

            <ul class="nav nav-pagination">

                <?php $post_count = $the_query->found_posts;
                $pageintion = (ceil($post_count / 9)); ?>
                <?php for ($c = 1; $c <= $pageintion; $c++) : ?>
                    <li class="nav-item">
                        <a onclick="propageSet(<?php echo $c ?> , '<?php echo $cat_id ?>'  , '<?php echo $search_val ?>' ,this)"
                           class="nav-link  <?php echo $c == $page_int ? " active-it" : ' ' ?>">
                            <?php echo $c ?>
                        </a>
                    </li>
                <?php endfor; ?>


            </ul>
        </div>
        <?php
    } else {

    }

    wp_reset_postdata();
    wp_die();

}

add_action('wp_ajax_jobfinder_pro_page', 'jobfinder_pro_page');
add_action('wp_ajax_nopriv_jobfinder_pro_page', 'jobfinder_pro_page');

function jobfinder_pro_search()
{
    $cat_id = $_POST['cat_id'];

    $search_val = $_POST['search_val'];

    if ($cat_id == 0) {
        $args = array(
            'posts_per_page' => 9,
            'post_type' => 'product',


        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }
    } else {
        $args = array(
            'posts_per_page' => 9,
            'post_type' => 'product',

            'tax_query' => array(array(
                'taxonomy' => 'pro-cats',
                'terms' => $cat_id,
            ),)
        );
        if (!empty($search_val)) {
            $args['s'] = $search_val;
        }
    }


    $the_query = new WP_Query($args);
    $cu = 1;
    if ($the_query->have_posts()) {

        while ($the_query->have_posts()) {
            $the_query->the_post();
            ?>
            <div class="col-lg-4 col-sm-6 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <div class="item">
                    <div class="bg">
                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id(get_the_ID())) ?>"
                             alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">

                        <div class="name morabba">
                            <?php echo get_the_title() ?>
                        </div>
                        <?php $pro_category = get_the_terms(get_the_ID(), "pro-cats");

                        if ($pro_category) :
                            ?>
                            <div class="subtitle">
                                <?php echo $pro_category[0]->name ?>

                            </div>
                        <?php endif; ?>

                        <a href="<?php echo get_the_permalink() ?>" class="more">
                            مشاهده جزئیات
                            <i class="icon-1-left-circle"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        <div class="col-12 prl-10px" data-aos="zoom-in" data-aos-easing="ease-in-out"
             data-aos-duration="1000"
             data-aos-delay="200" data-aos-once="true">
            <style>
                .active-it {
                    background-color: #208370 !important;
                    color: #ffffff !important;
                }
            </style>

            <ul class="nav nav-pagination">

                <?php $post_count = $the_query->found_posts;
                $pageintion = (ceil($post_count / 9)); ?>
                <?php for ($c = 1; $c <= $pageintion; $c++) : ?>
                    <li class="nav-item">
                        <a onclick="propageSet(<?php echo $c ?> , '<?php echo $cat_id ?>', '<?php echo $search_val ?>' ,this)"
                           class="nav-link  <?php echo $c == 1 ? " active-it" : ' ' ?>">
                            <?php echo $c ?>
                        </a>
                    </li>
                <?php endfor; ?>


            </ul>
        </div>
        <?php
    } else {

    }

    wp_reset_postdata();
    wp_die();

}

add_action('wp_ajax_jobfinder_pro_search', 'jobfinder_pro_search');
add_action('wp_ajax_nopriv_jobfinder_pro_search', 'jobfinder_pro_search');

function jobfinder_menu_search()
{


    $search_val = $_POST['search_val'];


    $args = array(
        "s" => $search_val,


    );


    $the_query = new WP_Query($args);
    if ($the_query->have_posts()) {
        echo "<ul>";
        while ($the_query->have_posts()) {
            $the_query->the_post();
            ?>
            <li class="nav-item">
                <a href="<?php echo get_the_permalink() ?>" class="nav-link">
                    <?php echo get_the_title() ?>
                </a>
            </li>
            <?php
        }
        ?>

        </ul>
        <?php
    } else {
        echo "<p class='co-res'>نتیجه ای یافت نشد!!</p>";
    }

    wp_reset_postdata();
    wp_die();

}

add_action('wp_ajax_jobfinder_menu_search', 'jobfinder_menu_search');
add_action('wp_ajax_nopriv_jobfinder_menu_search', 'jobfinder_menu_search');

