<?php
/* Template Name: Index Template */
get_header();
global $page;
?>

<body>

<?php get_template_part("partials/top-bar-menu") ?>
<!--START-MAIN-->
<main>
    <?php the_content(); ?>

</main>
<!--END-MAIN-->
<?php get_footer() ?>
</body>
</html>

