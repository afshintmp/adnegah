<?php get_header();
global $post;
$author_id = $post->post_author;
$display_name = get_the_author_meta('display_name', $author_id);
?>


<body>

<?php get_template_part("partials/top-bar-menu") ?>
<style>
    .reply-box.form-elements input {
        border: 0;
        background: #fff;
        box-shadow: 0px 8px 80px 0px rgb(0 0 0 / 10%);

    }

</style>
<!--START-MAIN-->
<main>
    <?php get_template_part('partials/bread-crump') ?>
    <!--START-BLOG-SINGLE-->
    <div class="blog-single">
        <div class="container">
            <div class="img" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="0" data-aos-once="true">
                <img src="<?php echo
                wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()))
                ?>" alt="">

                <article>
                    <?php $terms = get_the_terms(get_the_ID(), "category") ?>
                    <div class="subtitle">
                        دسته بندی مقالات
                        <?php echo $terms[0]->name ?>
                    </div>
                    <span class="title morabba">
                        <?php echo get_the_title() ?>
                </span>
                    <ul class="nav">
                        <li class="nav-item">
                            <div class="icon">
                                <i class="icon-smiling"></i>
                            </div>
                            <span>
                            نویسنده
                            <b>
                                <?php echo $display_name ?>
                            </b>
                        </span>
                        </li>
                        <li class="nav-item">
                            <div class="icon">
                                <i class="icon-calendar"></i>
                            </div>
                            <span>
                            منتشر شده
                            <b>
                               <?php echo get_the_date('dS M Y', $post->ID) . ' ' ?>
                            </b>
                        </span>
                        </li>
                        <?php $time_read = get_post_meta(get_the_ID(), "jobfinder-post-time", true);
                        if (!empty($time_read)) : ?>
                            <li class="nav-item">
                                <div class="icon">
                                    <i class="icon-clock1"></i>
                                </div>
                                <span>
                            زمان مطالعه
                            <b>
                                <?php echo $time_read . ' '; ?>
                                 دقیقه می باشد
                            </b>
                        </span>
                            </li>
                        <?php endif; ?>
                    </ul>

                </article>
            </div>
            <div class="text" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="0"
                 data-aos-once="true">
                <?php the_content(); ?>
            </div>

            <div class="box-recent" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
                 data-aos-delay="0" data-aos-once="true">
                <?php $post_tags = get_the_terms(get_the_ID(), "post_tag");
                ?>
                <div class="title-box">
                    <div class="icon">
                        <i class="icon-list1"></i>
                    </div>
                    <span>
                        موضوعات مرتبط
                        <b>
                            با این مقاله
                        </b>
                    </span>
                </div>
                <ul class="nav">
                    <?php foreach ($post_tags as $post_tag): ?>
                        <li class="nav-item">
                            <a href="" class="nav-link">
                                <?php echo $post_tag->name ?>
                            </a>
                        </li>
                    <?php endforeach; ?>

                </ul>
            </div>
        </div>
    </div>
    <!--END-BLOG-SINGLE-->

    <!--START-BLOG-ARCHIVE-->
    <div class="articles slider-theme" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="1000"
         data-aos-delay="0" data-aos-once="true">
        <div class="container">
            <div class="header-section center-theme">
                <div class="title">
                    با ما همیشه بروز باشید
                    <b class="morabba has-mt">اخبــــار و مقــــالات مرتبــــط</b>
                </div>
            </div>
            <div class="slider-container">
                <div class="swiper-container swiper-blog">
                    <div class="swiper-wrapper">

                        <?php

                        $args = array(
                            'category__in' => $terms[0]->term_id,

                            'posts_per_page' => 8,
                            'post_type' => 'post',
                        );

                        $the_query = new WP_Query($args);


                        if ($the_query->have_posts()) {

                            while ($the_query->have_posts()) {
                                $the_query->the_post();
                                ?>
                                <div class="swiper-slide item">
                                    <a href="<?php echo get_the_permalink() ?>">
                                        <div class="img" style="background-image: url(<?php echo
                                        wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()))
                                        ?>)">
                                            <article>
                                                <?php $terms = get_the_terms(get_the_ID(), "category") ?>

                                                <span class="subtitle">
                                    دسته بندی مقالات           <?php echo $terms[0]->name ?>
                                </span>
                                                <span class="title morabba">
                          <?php echo get_the_title() ?>
                                </span>
                                                <ul class="nav nav-info">
                                                    <li class="nav-item">
                                                        <div class="icon">
                                                            <i class="icon-calendar"></i>
                                                        </div>
                                                        <span>
                                        منتشر شده
                                        <b>
                                            <?php echo get_the_date('dS M Y', $post->ID) . ' ' ?>
                                        </b>
                                    </span>
                                                    </li>
                                                    <li class="nav-item">
                                                        <div class="icon">
                                                            <i class="icon-chat"></i>
                                                        </div>
                                                        <span>
                                        تعداد نظرات
                                        <b>

                                            <?php
                                            $comments = get_comment_count(get_the_ID());
                                            echo $comments['total_comments']; ?>
                                             نظر ثبت شده
                                        </b>
                                    </span>
                                                    </li>
                                                </ul>
                                            </article>
                                        </div>
                                    </a>
                                </div>
                                <?php
                            }

                        } else {
                            // no posts found
                        }

                        wp_reset_postdata();
                        ?>


                    </div>
                </div>
                <div class="button-nav next swiper-button-next-blog">
                    <i class="icon-left-chevron"></i>
                </div>
                <div class="button-nav prev swiper-button-prev-blog">
                    <i class="icon-right-chevron"></i>
                </div>
            </div>
        </div>
    </div>
    <!--END-BLOG-ARCHIVE-->

    <!--START-FORM-ELEMNETS-->
    <div class="form-elements blog-theme">
        <div class="container">
            <div class="header-section center-theme" data-aos="fade-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
                <div class="title">
                    نظرات کاربران پیرامون مقاله
                    <b class="morabba has-mt">
                        ارســــال نظــــرات کاربــــران
                    </b>
                </div>
            </div>
            <form action="https://anikmed.com/wp-comments-post.php" method="post">
                <div class="row prl-10px">
                    <?php if (!is_user_logged_in()) : ?>
                        <div class="col-xl-6 col-md-6 prl-5px" data-aos="fade-in" data-aos-easing="ease-in-out"
                             data-aos-duration="1000" data-aos-delay="100" data-aos-once="true">
                            <div class="form-group">
                                <input type="text" name="author" required placeholder="نام و نام خانوادگی">
                            </div>
                        </div>

                        <div class="col-xl-6 col-md-6 prl-5px" data-aos="fade-in" data-aos-easing="ease-in-out"
                             data-aos-duration="1000" data-aos-delay="300" data-aos-once="true">
                            <div class="form-group">
                                <input type="email" name="email" required placeholder="پست اکترونیک">
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="col-xl-12 prl-5px" data-aos="fade-in" data-aos-easing="ease-in-out"
                         data-aos-duration="1000" data-aos-delay="500" data-aos-once="true">
                        <div class="form-group">
                            <textarea name="comment" required
                                      placeholder="متن نظر خود پیرامون این مقاله را یادداشت کنید . . ."></textarea>
                        </div>
                    </div>
                    <div class="col-12 prl-5px d-flex align-items-center justify-content-end" data-aos="fade-in"
                         data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="600"
                         data-aos-once="true">
                        <input name="submit" type="submit" id="submit" class="btn btn-submit mr-0"
                               value="نظر خود را ارسال کنید">
                        <input type="hidden" name="comment_post_ID" value="<?php echo get_the_ID() ?>"
                               id="comment_post_ID">
                        <input type="hidden" name="comment_parent" id="comment_parent" value="0">

                    </div>
                </div>
            </form>
        </div>
    </div>
    <!--END-FORM-ELEMENTS-->

    <!--START-COMMENT-SECTION-->
    <div class="comment-section">
        <div class="container">
            <div class="header-section center-theme" data-aos="fade-in" data-aos-easing="ease-in-out"
                 data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
        <span class="title morabba">
            نظرات کاربران پیرامون مقاله
                    <b class="has-mt-morabba">مشاهــــده نظــــرات کاربــــران مــــا</b>
                </span>
            </div>
            <?php $comments = get_comments(array(
                    'post_id' => get_the_ID(),
                    'parent' => 0,
                )
            );

            foreach ($comments as $comment) :
                ?>

                <div class="item d-block" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000"
                     data-aos-delay="200" data-aos-once="true">

                    <div class="d-flex flex-lg-nowrap flex-wrap">
                        <img src="<?php echo DU . '/assets/img/gary.png' ?>" alt="">
                        <div class="info">
                    <span class="name">
                        <?php echo $comment->comment_author ?>
                    </span>
                            <span class="date">
                                <?php
                                $comment_date = get_comment_date("dS M Y", $comment->comment_ID);
                                echo $comment_date;
                                ?>

                    </span>

                            <button class="btn btn-reply">
                                پاسخ دادن
                            </button>
                        </div>
                        <p class="text">
                            <?php echo $comment->comment_content ?>
                        </p>
                    </div>

                    <div class="reply-box form-elements">
                        <form action="https://anikmed.com/wp-comments-post.php" method="post">
                            <div class="row prl-10px">
                                <?php if (!is_user_logged_in()) : ?>
                                    <div class="col-xl-6 col-md-6 prl-5px" data-aos="fade-in"
                                         data-aos-easing="ease-in-out"
                                         data-aos-duration="1000" data-aos-delay="100" data-aos-once="true">
                                        <div class="form-group">
                                            <input type="text" name="author" required placeholder="نام و نام خانوادگی">
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-md-6 prl-5px" data-aos="fade-in"
                                         data-aos-easing="ease-in-out"
                                         data-aos-duration="1000" data-aos-delay="300" data-aos-once="true">
                                        <div class="form-group">
                                            <input type="email" name="email" required placeholder="پست اکترونیک">
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="col-xl-12 prl-5px" data-aos="fade-in" data-aos-easing="ease-in-out"
                                     data-aos-duration="1000" data-aos-delay="500" data-aos-once="true">
                                    <div class="form-group">
                            <textarea name="comment" required
                                      placeholder="متن پاسخ خود پیرامون این مقاله را یادداشت کنید . . ."></textarea>
                                    </div>
                                </div>
                                <div class="col-12 prl-5px d-flex align-items-center justify-content-end"
                                     data-aos="fade-in"
                                     data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="600"
                                     data-aos-once="true">
                                    <input name="submit" type="submit" id="submit" class="btn btn-send"
                                           value="نظر خود را ارسال کنید">
                                    <input type="hidden" name="comment_post_ID" value="<?php echo get_the_ID() ?>"
                                           id="comment_post_ID">
                                    <input type="hidden" name="comment_parent" id="comment_parent"
                                           value="<?php echo $comment->comment_ID ?>">

                                </div>
                            </div>
                        </form>
                    </div>


                </div>
                <?php $replay_comments = get_comments(array(
                    'post_id' => get_the_ID(),
                    'parent' => $comment->comment_ID,
                )
            );
                foreach ($replay_comments as $replay_comment) :
                    ?>

                    <div class="item reply d-block" data-aos="fade-in" data-aos-easing="ease-in-out"
                         data-aos-duration="1000"
                         data-aos-delay="300" data-aos-once="true">
                        <div class="d-flex flex-lg-nowrap flex-wrap">
                            <img src="<?php echo DU . '/assets/img/gary.png' ?>" alt="">
                            <div class="info">
                    <span class="name">
                         <?php echo $replay_comment->comment_author ?>
                    </span>
                                <span class="date">
                       <?php
                       $replay_comment_date = get_comment_date("dS M Y", $replay_comment->comment_ID);
                       echo $replay_comment_date;
                       ?>
                    </span>

                                <button class="btn btn-reply">
                                    پاسخ دادن
                                </button>
                            </div>
                            <p class="text">
                                <?php echo $replay_comment->comment_content ?>
                            </p>
                        </div>


                        <div class="reply-box form-elements">
                            <form action="https://anikmed.com/wp-comments-post.php" method="post">
                                <div class="row prl-10px">
                                    <?php if (!is_user_logged_in()) : ?>
                                        <div class="col-xl-6 col-md-6 prl-5px" data-aos="fade-in"
                                             data-aos-easing="ease-in-out"
                                             data-aos-duration="1000" data-aos-delay="100" data-aos-once="true">
                                            <div class="form-group">
                                                <input type="text" name="author" required
                                                       placeholder="نام و نام خانوادگی">
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-md-6 prl-5px" data-aos="fade-in"
                                             data-aos-easing="ease-in-out"
                                             data-aos-duration="1000" data-aos-delay="300" data-aos-once="true">
                                            <div class="form-group">
                                                <input type="email" name="email" required placeholder="پست اکترونیک">
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-xl-12 prl-5px" data-aos="fade-in" data-aos-easing="ease-in-out"
                                         data-aos-duration="1000" data-aos-delay="500" data-aos-once="true">
                                        <div class="form-group">
                            <textarea name="comment" required
                                      placeholder="متن پاسخ خود پیرامون این مقاله را یادداشت کنید . . ."></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12 prl-5px d-flex align-items-center justify-content-end"
                                         data-aos="fade-in"
                                         data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="600"
                                         data-aos-once="true">
                                        <input name="submit" type="submit" id="submit" class="btn btn-send"
                                               value="نظر خود را ارسال کنید">
                                        <input type="hidden" name="comment_post_ID" value="<?php echo get_the_ID() ?>"
                                               id="comment_post_ID">
                                        <input type="hidden" name="comment_parent" id="comment_parent"
                                               value="<?php echo $replay_comment->comment_ID ?>">

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php $replay_two_comments = get_comments(array(
                        'post_id' => get_the_ID(),
                        'parent' => $replay_comment->comment_ID,
                    )
                );
                    foreach ($replay_two_comments as $replay_two_comment) :
                        ?>
                        <div class="item green-theme reply d-block" data-aos="fade-in" data-aos-easing="ease-in-out"
                             data-aos-duration="1000"
                             data-aos-delay="300" data-aos-once="true">
                            <div class="d-flex flex-lg-nowrap flex-wrap">
                                <img src="<?php echo DU . '/assets/img/green.png' ?>" alt="">
                                <div class="info">
                    <span class="name">
                         <?php echo $replay_two_comment->comment_author ?>
                    </span>
                                    <span class="date">
                       <?php
                       $replay_two_comment_date = get_comment_date("dS M Y", $replay_two_comment->comment_ID);
                       echo $replay_two_comment_date;
                       ?>
                    </span>


                                </div>
                                <p class="text">
                                    <?php echo $replay_two_comment->comment_content ?>
                                </p>
                            </div>



                        </div>

                    <?php
                    endforeach;
                endforeach;
            endforeach; ?>

        </div>
    </div>
    <!--END-COMMENT-SECTION-->
</main>
<!--END-MAIN-->
<?php get_footer() ?>
</body>
</html>
