<?php

$logo_img = get_option('logo-img');

$copy_write_text = get_option('copy-write-text');

$footer_email = get_option('footer-email');
$footer_phone_number = get_option('footer-phone-number');
$footer_address = get_option('footer-address');


$instagram_link = get_option('instagram-link');
$whatsapp_link = get_option('whatsapp-link');

$telegram_link = get_option('telegram-link');
?>
<!--START-FOOTER-->
<footer class="footer" data-aos="fade-in" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0"
        data-aos-once="true">
    <img class="shape" src="<?php echo DU . '/assets/img/shape-footer.png' ?>" alt="">
    <div class="container prl-10px d-flex flex-wrap justify-content-between">
        <div class="col-xl-4 col-12 prl-5px" data-aos="fade-right" data-aos-easing="ease-in-out"
             data-aos-duration="1000" data-aos-delay="0" data-aos-once="true">
            <a href="" class="brand">
                <img src="<?php echo $logo_img ?>" alt="">
            </a>
            <p class="text">
                <?php echo $copy_write_text ?>
            </p>
            <div class="line"></div>
            <p class="text email-theme">
                <?php echo $footer_email ?>
            </p>
            <span class="number morabba">
                <?php echo $footer_phone_number ?>
            </span>
        </div>
        <div class="col-xl-auto col-lg-4 col-md-4 col-6 prl-5px" data-aos="fade-right" data-aos-easing="ease-in-out"
             data-aos-duration="1000" data-aos-delay="200" data-aos-once="true">
            <span class="title morabba">
                خدمات گروه ما
            </span>
            <div class="line"></div>
            <?php wp_nav_menu(array(
                'container'         => "ul",
                'theme_location'    => "footer_menu",
                'menu_class'        => "nav nav-menu"
            )); ?>
           <!-- <ul class="nav nav-menu">
                <li class="nav-item">
                    <a href="" class="nav-link">
                        آزمایشگاهی
                    </a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                        کلینیک های زیبایی
                    </a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                        درمانگاه
                    </a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                        بیمارستان ها
                    </a>
                </li>
            </ul>-->

        </div>
        <div class="col-xl-auto col-lg-4 col-md-4 col-6 prl-5px" data-aos="fade-right" data-aos-easing="ease-in-out"
             data-aos-duration="1000" data-aos-delay="400" data-aos-once="true">
            <span class="title morabba">
                لینک های کاربردی
            </span>
            <div class="line"></div>
            <!--<ul class="nav nav-menu">
                <li class="nav-item">
                    <a href="" class="nav-link">
                        درباره ما
                    </a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                        محصولات ما
                    </a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                        قوانین و مقررات
                    </a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                        وبلاگ
                    </a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                        تماس با ما
                    </a>
                </li>
            </ul>-->
            <?php wp_nav_menu(array(
                'container'         => "ul",
                'theme_location'    => "footer_link_menu",
                'menu_class'        => "nav nav-menu"
            )); ?>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-4 prl-5px" data-aos="fade-right" data-aos-easing="ease-in-out"
             data-aos-duration="1000" data-aos-delay="600" data-aos-once="true">
            <span class="title morabba">
                نشانی دفتر مرکزی
            </span>
            <div class="line">

            </div>
            <p class="text">
                <?php echo $footer_address ?>
            </p>
            <ul class="nav nav-social">
                <?php if (!empty($telegram_link)): ?>
                    <li class="nav-item">
                        <a href="<?php echo $telegram_link ?>" class="nav-link">
                            <i class="icon-telegram1"></i>
                        </a>
                    </li>
                <?php endif;
                if (!empty($instagram_link)): ?>
                    <li class="nav-item">
                        <a href="<?php echo  $instagram_link ?>" class="nav-link">
                            <i class="icon-instagram"></i>
                        </a>
                    </li>
                <?php
                endif;
                if (!empty($whatsapp_link)) :
                    ?>
                    <li class="nav-item">
                        <a href="<?php echo $whatsapp_link ?>" class="nav-link">
                            <i class="icon-whatsapp"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    <img class="shape" src="<?php echo DU . '/assets/img/shape-footer.png' ?>" alt="">
</footer>
<!--END-FOOTER-->


<?php wp_footer(); ?>
<script>
    AOS.init({
        disable: 'mobile'
    });
</script>
<script>
    jQuery('.btn-reply').click(function () {
        $(this).parent().parent().parent().find('.reply-box').slideToggle()
    })
</script>