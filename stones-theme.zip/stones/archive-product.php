<?php
get_header('shop');
global $wp, $post, $option;
$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
    <style>
        html {
            overflow-x: hidden;
        }
    </style>
    <div class="alert-popup success">
        <div class="container">
            محصول مورد نظر به سبد خرید اضافه شد
            <span><a href="<?php echo get_home_url() . '/cart' ?>">مشاهده ی سبد خرید</a></span>
        </div>
    </div>

    <div class="filter-popup">
        <div class="main-menu">
            <div class="sidebar-public gray-theme">
                <div class="btn btn-close">
                    بستن
                </div>

                <form action="">
                    <div class="form-group">
                        <input class="search" id="keyword" type="text" placeholder="جستجو را شروع کنید . . .">
                        <button class="btn btn-search">
                            <i class="icon-search"></i>
                        </button>
                    </div>

                    <div class="box">
                        <div class="title">
                            <i class="icon-menu"></i>
                            دسته بندی محصولات
                        </div>
                        <div class="body">
                            <?php $terms = get_terms(array(
                                'taxonomy' => 'product_cat',

                            ));

                            foreach ($terms as $term) { ?>
                                <div class="form-check">
                                    <input type="checkbox" class="catsetm" id="<?php echo 'm-' . $term->term_id ?>"
                                           onchange="getcheckedM()" name="cat"
                                           value="<?php echo $term->term_id ?>">
                                    <label class="label-check" for="<?php echo 'm-' . $term->term_id ?>">
                                             <span class="icon">
                                                     <i class="icon-tick"></i>
                                              </span>
                                        <?php echo $term->name ?>
                                    </label>
                                </div>
                                <?php
                            }
                            ?>


                        </div>
                    </div>

                    <div class="box">
                        <div class="title">
                            <i class="icon-menu"></i>

                            کالکشن
                        </div>
                        <div class="body">
                            <?php $terms = get_terms(array(
                                'taxonomy' => 'colection',

                            ));


                            foreach ($terms as $term) { ?>
                                <div class="form-check">
                                    <input type="checkbox" class="colectsetm" id="<?php echo 'm-' . $term->term_id ?>"
                                           onchange="getcheckedM()" name="cat"
                                           value="<?php echo $term->term_id ?>">
                                    <label class="label-check" for="<?php echo 'm-' . $term->term_id ?>">
                                             <span class="icon">
                                                     <i class="icon-tick"></i>
                                              </span>
                                        <?php echo $term->name ?>
                                    </label>
                                </div>
                                <?php

                            }
                            ?>


                        </div>
                    </div>
                    <div class="box">
                                 <span class="title">
                                    بر اساس وزن طلا
                                 </span>
                        <div class="body">
                            <div class="form-check">
                                <input type="checkbox" class="gramsetm" onclick="getcheckedM()" id="cm-1"
                                       name="c" value="c-1">
                                <label class="label-check" for="cm-1">
                                                  <span class="icon">
                                            <i class="icon-tick"></i>
                                         </span>
                                    1 گرم تا 2 گرم

                                </label>
                            </div>
                            <div class="form-check">
                                <input type="checkbox"
                                       id="cm-2" class="gramsetm" onclick="getcheckedM()" name="c"
                                       value="c-2">
                                <label class="label-check" for="cm-2">

                                    <span class="icon">
                                        <i class="icon-tick"></i>
                                    </span>
                                    2 گرم تا 4 گرم
                                </label>

                            </div>
                            <div class="form-check">
                                <input type="checkbox"
                                       id="cm-3" class="gramsetm" onclick="getcheckedM()" name="c"
                                       value="c-3">
                                <label class="label-check" for="cm-3">

                                    <span class="icon">
                                        <i class="icon-tick"></i>
                                    </span>
                                    4 گرم تا 6 گرم
                                </label>

                            </div>

                            <input type="checkbox" id="cm-4" onclick="getcheckedM()"
                                   name="c" class="gramsetm" value="c-4">
                            <label class="label-check" for="cm-4">
                                                       <span class="icon">
                                        <i class="icon-tick"></i>
                                    </span>
                                6 گرم به بالا
                            </label>

                        </div>
                    </div>

                    <div class="box drop-down-theme">
    <span class="title drop-click">
                                بر اساس عیار طلا

                                <i class="icon-down-chevron drop-icon"></i>
                                <i class="icon-up-chevron drop-icon" style="display: none"></i>
                            </span>
                        <?php $terms = get_terms(array(
                            'taxonomy' => 'ayar',

                        ));
                        foreach ($terms as $term) { ?>

                            <div class="body" style="display: none">

                                <div class="form-check">
                                    <input type="checkbox"
                                           id="<?php echo 'm-' . $term->term_id; ?>" class="ayarsetm" name="m"
                                           onchange="getcheckedM()" value="<?php echo $term->term_id; ?>">
                                    <label class="label-check" for="<?php echo 'm-' . $term->term_id; ?>">
                                                <span class="icon">
                                                    <i class="icon-tick"></i>
                                                </span>
                                        <?php echo $term->name; ?>

                                    </label>
                                </div>

                            </div>
                        <?php } ?>
                    </div>


                </form>
            </div>
        </div>
        <div class="after"></div>
    </div>

<?php get_template_part('partials/stones', 'head') ?>
<?php

$args = array(
    'post_type' => 'product',
    'posts_per_page' => 9,

);


$the_query = new WP_Query($args); ?>

    <main>

        <div class="bread-crumb">
            <div class="container d-flex align-items-center flex-wrap">
                <ul class="nav nav-bread">
                    <li class="nav-item">
                        <a href="<?php echo get_home_url() ?>" class="nav-link">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo $url ?>" class="nav-link">
                            فروشگاه
                        </a>
                    </li>
                </ul>

                <ul class="nav nav-sort d-lg-flex d-none">
                    <!--START-CHANGE-->
                    <li class="nav-item">
                        <input type="radio" onchange="getchecked()" class="d-none sortselect" id="sort-n" name="sort"
                               value="nosort" checked>
                        <label for="sort-n">
                            جدید ترین
                        </label>
                    </li>
                    <li class="nav-item">
                        <input type="radio" onchange="getchecked()" class="d-none sortselect" id="sort-1" name="sort"
                               value="ASC">
                        <label for="sort-1">
                            ارزان ترین
                        </label>
                    </li>
                    <li class="nav-item">
                        <input type="radio" onchange="getchecked()" class="d-none sortselect" id="sort-2" name="sort"
                               value="DESC">
                        <label for="sort-2">
                            گران ترین
                        </label>
                    </li>
                    <!--END-CHANGE-->
                </ul>
                <div class="form-group d-lg-block d-none">
                    <input type="checkbox" id="checkbox" class="instock" value="instock" onchange="getchecked()">
                    <label for="checkbox" class="label-switch">
                        <span class="switch">
                        </span>
                        نمایش کالاهای موجود
                    </label>
                </div>
                <div class="count d-lg-flex d-none">
                    <i class="icon-box"></i>
                    <?php echo $the_query->found_posts ?>
                    محصول
                </div>
            </div>
        </div>

        <div class="product-archive">
            <div class="container p-0 d-flex flex-wrap">
                <div class="col-xl-3 col-lg-4 d-lg-block d-none">
                    <div class="sidebar-public gray-theme">
                        <form action="">
                            <div class="form-group">
                                <input class="search" id="keyworddec" onkeyup="getchecked()" type="text"
                                       placeholder="جستجو را شروع کنید . . .">
                                <button class="btn btn-search" onclick="function (e) {
                                  e.preventDefault()
                                }">
                                    <i class="icon-search"></i>
                                </button>
                            </div>

                            <div class="box">
                                <div class="title">
                                    <i class="icon-menu"></i>
                                    دسته بندی محصولات
                                </div>
                                <div class="body">
                                    <?php $terms = get_terms(array(
                                        'taxonomy' => 'product_cat',

                                    ));

                                    foreach ($terms as $term) { ?>
                                        <div class="form-check">
                                            <input type="checkbox" class="catset" id="<?php echo $term->term_id ?>"
                                                   onchange="getchecked()" name="cat"
                                                   value="<?php echo $term->term_id ?>">
                                            <label class="label-check" for="<?php echo $term->term_id ?>">
                                             <span class="icon">
                                                     <i class="icon-tick"></i>
                                              </span>
                                                <?php echo $term->name ?>
                                            </label>
                                        </div>
                                        <?php
                                    }
                                    ?>


                                </div>
                            </div>

                            <div class="box">
                                <div class="title">
                                    <i class="icon-menu"></i>

                                    کالکشن
                                </div>
                                <div class="body">
                                    <?php $terms = get_terms(array(
                                        'taxonomy' => 'colection',

                                    ));


                                    foreach ($terms as $term) { ?>
                                        <div class="form-check">
                                            <input type="checkbox" class="colectset" id="<?php echo $term->term_id ?>"
                                                   onchange="getchecked()" name="cat"
                                                   value="<?php echo $term->term_id ?>">
                                            <label class="label-check" for="<?php echo $term->term_id ?>">
                                             <span class="icon">
                                                     <i class="icon-tick"></i>
                                              </span>
                                                <?php echo $term->name ?>
                                            </label>
                                        </div>
                                        <?php

                                    }
                                    ?>


                                </div>
                            </div>
                            <div class="box">
                                 <span class="title">
                                    بر اساس وزن طلا
                                 </span>
                                <div class="body">
                                    <div class="form-check">
                                        <input type="checkbox" class="gramset" onclick="getchecked()" id="c-1"
                                               name="c" value="c-1">
                                        <label class="label-check" for="c-1">
                                                  <span class="icon">
                                            <i class="icon-tick"></i>
                                         </span>
                                            1 گرم تا 2 گرم

                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox"
                                               id="c-2" class="gramset" onclick="getchecked()" name="c"
                                               value="c-2">
                                        <label class="label-check" for="c-2">

                                    <span class="icon">
                                        <i class="icon-tick"></i>
                                    </span>
                                            2 گرم تا 4 گرم
                                        </label>

                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox"
                                               id="c-3" class="gramset" onclick="getchecked()" name="c"
                                               value="c-3">
                                        <label class="label-check" for="c-3">

                                    <span class="icon">
                                        <i class="icon-tick"></i>
                                    </span>
                                            4 گرم تا 6 گرم
                                        </label>

                                    </div>

                                    <input type="checkbox" id="c-4" onclick="getchecked()"
                                           name="c" class="gramset" value="c-4">
                                    <label class="label-check" for="c-4">
                                                       <span class="icon">
                                        <i class="icon-tick"></i>
                                    </span>
                                        6 گرم به بالا
                                    </label>

                                </div>
                            </div>

                            <div class="box drop-down-theme">
    <span class="title drop-click">
                                بر اساس عیار طلا

                                <i class="icon-down-chevron drop-icon"></i>
                                <i class="icon-up-chevron drop-icon" style="display: none"></i>
                            </span>
                                <?php $terms = get_terms(array(
                                    'taxonomy' => 'ayar',
                                ));
                                foreach ($terms as $term) { ?>

                                    <div class="body" style="display: none">

                                        <div class="form-check">
                                            <input type="checkbox"
                                                   id="<?php echo $term->term_id; ?>" class="ayarset" name="m"
                                                   onchange="getchecked()" value="<?php echo $term->term_id; ?>">
                                            <label class="label-check" for="<?php echo $term->term_id; ?>">
                                                <span class="icon">
                                                    <i class="icon-tick"></i>
                                                </span>
                                                <?php echo $term->name; ?>

                                            </label>
                                        </div>

                                    </div>
                                <?php } ?>
                            </div>


                        </form>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-8">
                    <div class="w-100 d-lg-none d-flex align-items-center justify-content-between">
                        <button class="btn btn-filter">
                            <i class="icon-search"></i>
                            جستجوی پیشرفته
                        </button>
                        <?php ?>


                        <div class="sort">

                        </div>
                    </div>
                    <ul class="nav box-sub-filter">
                        <?php if (isset($_GET['catid'])) :
                            $arr_params = array('catid');

                            $term = get_term($_GET['catid'], 'product_cat');
                            ?>
                            <li class="nav-item">
                                <div class="remove">
                                    <a style="color: #666666;"
                                       href="<?php echo esc_url(remove_query_arg($arr_params)); ?>">
                                        <i class="icon-close"></i>

                                </div>
                                <?php echo $term->name ?>
                                </a>
                            </li>

                        <?php endif; ?>
                        <?php if (isset($_GET['sor'])) :
                            $arr_params = array('sor');

                            ?>
                            <a style="color: #666666;"
                               href="<?php echo esc_url(remove_query_arg($arr_params)); ?>">
                                <li class="nav-item">
                                    <div class="remove">

                                        <i class="icon-close"></i>

                                    </div>
                                    <?php echo $_GET['sor'] == "DESC" ? "گرانترین" : "ارزانترین" ?>

                                </li>
                            </a>
                        <?php endif; ?>
                    </ul>
                    <div class="products archive-theme m-0">
                        <div class="row prl-5px" id="ajax-inner">


                            <?php if ($the_query->have_posts()) : ?>

                                <?php while ($the_query->have_posts()) : $the_query->the_post();

                                    $postthumbid = get_post_thumbnail_id();
                                    $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
                                    $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
                                    $newseles = get_post_meta(get_the_ID(), '_sale_price', true)
                                    ?>
                                    <div class="col-xl-4 col-md-6 prl-10px">
                                        <div class="item">
                                            <?php
                                            if (get_post_meta(get_the_ID(), '_stock_status', true) == 'outofstock' || empty(get_post_meta(get_the_ID(), '_regular_price', true))) {

                                            } else {
                                                ?>
                                                <button class="add-cart"
                                                        onclick="ajaxaddtocart(<?php echo get_the_ID() ?>,this)">
                                                    <span class="spinner"></span>
                                                    <i class="icon-shopping-cart1"></i>
                                                </button>
                                            <?php } ?>
                                            <?php if (!empty($newseles)) : ?>
                                                <span class="label">
                                                 فـــروش ویـــژه
                                            </span>
                                            <?php endif; ?>
                                            <a href="<?php echo get_the_permalink() ?>">
                                                <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                                            </a>
                                            <a href="<?php echo get_the_permalink() ?>" class="title">
                                                <?php echo get_the_title() ?>
                                            </a>
                                            <span class="subtitle kalameh">


                                                <?php
                                                if (get_post_meta(get_the_ID(), '_stock_status', true) == 'outofstock') {
                                                    echo "ناموجود";
                                                } else {

                                                    if (!empty($newseles)) {

                                                        echo number_format($newseles, 0, ',', ',');
                                                        echo ' ' . get_woocommerce_currency_symbol();
                                                    } elseif (!empty(get_post_meta(get_the_ID(), '_regular_price', true))) {
                                                       
                                                        echo number_format(get_post_meta(get_the_ID(), '_regular_price', true), 0, ',', ',');
                                                        echo ' ' . get_woocommerce_currency_symbol();
                                                    } else {
                                                        echo "ناموجود";
                                                    }

                                                }

                                                ?>

                                            </span>
                                        </div>
                                    </div>


                                <?php endwhile; ?>

                                <?php wp_reset_postdata(); ?>

                            <?php else : ?>

                            <?php endif; ?>
                        </div>
                    </div>
                    <?php
                    $all_post = $the_query->found_posts;
                    $pagging = $all_post / 9;
                    $peges = ceil($pagging);
                    ?>

                    <ul class="nav nav-pagination">
                        <?php for ($i = 1; $i <= $peges; $i++) {
                            ?>
                            <li class="nav-item <?php
                            if ($i == 1) {
                                echo "active  frist";
                            }
                            ?>
">
                                <a style="cursor: pointer" class="nav-link" data-page="<?php echo $i ?>"
                                   onclick="pageset(this)">
                                    <?php echo $i ?>
                                </a>
                            </li>
                            <?php
                        } ?>

                    </ul>
                </div>
            </div>
        </div>

    </main>

<?php get_footer('shop') ?>