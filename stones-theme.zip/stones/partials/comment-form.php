<!--<div class="form-elements only-section" id="target4">
    <div class="container">
            <span class="title kalameh">
                <img src="assets/img/shape-1.png" alt="">
                فــرم ارســال نــظر کاربــران
            </span>
        --><?php
/*        $commenter = wp_get_current_commenter();
        $req = get_option('require_name_email');
        $aria_req = ($req ? " aria-required='true'" : '');
        $fields = array(
            'author' => ' <div class="row align-items-center">
                <div class="col-xl-6 p-0 d-flex flex-wrap">
                    <div class="col-md-12 prl-10px">
                        <div class="form-group">
                            <label for="name" class="label">
                               نام و نام خانوادگی
                            </label>
                             <input id="author" name="author" placeholder="نام و نام خانوادگی" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30"' . $aria_req . ' />
                            <i class="icon-user absolute-icon"></i>
                        </div>
                    </div>',
            'email' => '<div class="col-xl-12 col-md-4 prl-10px">
                                    <div class="form-group">
                                        <input id="email" name="email" placeholder="ایمیل خود را وارد کنید" type="text" value="' . esc_attr($commenter['comment_author_email']) . '" size="30"' . $aria_req . ' />
                                    </div>
                                </div>',
        );
        $comments_args = array(
            'comment_field' => '<div class="row d-flex flex-wrap prl-5px">
                   <div class="col-xl-12 prl-10px">
                       <div class="form-group">
                       <textarea id="comment"  name="comment" cols="45" rows="8" maxlength="65525" placeholder="نظر یا دیدگاه خود را همین جا بنویسید . . ." required="required"></textarea>
                       </div>
                   </div>',
            'fields' => $fields,
            'label_submit' => 'نظر را ارسال کنید',
            'submit_button' => '<div class="col-xl-12 col-md-4 prl-10px"><input name="%1$s" type="submit" id="%2$s" class="%3$s btn btn-submit" value=" نظر را ارسال کنید" />  </div>
                   </div>
               </div>',
            'title_reply' => '',
            'comment_notes_before' => '',
            'comment_notes_after' => '',

        );
//        comment_form($comments_args);*/
        comment_form();
        ?>

         <!--   <div class="row align-items-center">
                <div class="col-xl-6 p-0 d-flex flex-wrap">
                    <div class="col-md-6 prl-10px">
                        <div class="form-group">
                            <label for="name" class="label">
                                نام
                            </label>
                            <input type="text" id="name" placeholder="سید فرهاد">
                            <i class="icon-user absolute-icon"></i>
                        </div>
                    </div>
                    <div class="col-md-6 prl-10px">
                        <div class="form-group">
                            <label for="family" class="label">
                                نام خانوادگی
                            </label>
                            <input type="text" id="family" placeholder="موسوی راد">
                            <i class="icon-user absolute-icon"></i>
                        </div>
                    </div>


                    <div class="col-md-6 prl-10px">
                        <div class="form-group">
                            <label for="phone" class="label">
                                شماره همراه
                            </label>
                            <input type="text" id="phone" placeholder="09120583898">
                            <i class="icon-phone absolute-icon"></i>
                        </div>
                    </div>

                    <div class="col-md-6 prl-10px">
                        <div class="form-group">
                            <label for="phone" class="label">
                                پیشنهاد مطالعه این مقاله
                            </label>
                            <select class="js-example-basic-single" name="state">
                                <option>
                                    خواندن این مقاله را پیشنهاد میکنم
                                </option>
                                <option>
                                    خواندن این مقاله را پیشنهاد میکنم
                                </option>
                                <option>
                                    خواندن این مقاله را پیشنهاد میکنم
                                </option>
                            </select>
                            <i class="icon-down absolute-icon"></i>
                        </div>

                    </div>
                </div>
                <div class="col-xl-6 prl-10px">
                    <div class="form-group">
                        <label for="text" class="label">
                            نظر خود را یادداشت کنید
                        </label>
                        <textarea id="text"
                                  placeholder="در این بخش میتوانید نظر یا پیشنهاد خود را مطرح کنید . . ."></textarea>
                    </div>

                </div>
                <div class="col-sm-auto col-12 prl-10px">
                    <div class="rate">
                        امتیاز شما به مقاله
                        <div class="main-rate rateYo"></div>
                    </div>
                </div>
                <div class="col-sm-auto mr-auto prl-10px">
                    <button class="btn btn-submit">
                        نظر خود را ارسال کنید
                        <i class="icon-left-arrow"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

-->


