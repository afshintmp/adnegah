<div id="loader-search" class="pageload-overlay search-popup"
     data-opening="M 0,0 c 0,0 63.5,-16.5 80,0 16.5,16.5 0,60 0,60 L 0,60 Z">
    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 80 60" preserveAspectRatio="none">
        <path d="M 0,0 c 0,0 -16.5,43.5 0,60 16.5,16.5 80,0 80,0 L 0,60 Z"/>
    </svg>

    <div class="detail-search">
        <form action="" class="container">
            <input type="text" placeholder="هر چه می خواهید جستجو کنید ...">
            <div class="btn btn-close" id="close-search">
                <i class="icon-close"></i>
            </div>
        </form>
    </div>

</div>

<?php get_template_part('partials/respansive', 'menu') ?>
<header class="header header-single">
    <div class="top-bar">
        <div class="container d-flex align-items-center flex-wrap">
            <a href="<?php echo get_home_url() ?>" class="brand">
                <img src="<?php echo get_template_directory_uri() . '/assets/img/logo-gold.png ' ?>" alt="استونز گالری">
            </a>
            <form action="" class="d-none d-lg-block">
                <div class="form-group">
                    <input type="text" onkeyup="ajaxsearch(this)" onfocusout="jQuery('.search-box').slideUp()"
                           placeholder="در میان بیش از 4000 محصول جستجو را شروع کنید . . .">
                </div>
                <button class="btn btn-search">
                    <i class="icon-search"></i>
                </button>
                <div class="search-box" style="display: none" onmouseleave="jQuery('.search-box').slideUp()">
                    <ul id="search-result">

                    </ul>
                </div>
            </form>
            <ul class="nav">
                <li class="nav-item">
                    <!--START-CHANGE-->
                    <a href="<?php echo get_home_url() . '/cart' ?>" class="nav-link">
                        <i class="icon-shopping-cart"></i>

                        <span class="number" id="cart-counter">
                            <?php echo WC()->cart->get_cart_contents_count(); ?>

                        </span>
                    </a>
                    <!--END-CHANGE-->
                </li>
                <li class="nav-item">
                    <a href="<?php echo get_home_url() . '/my-account' ?>" class="nav-link">
                        <i class="icon-users"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <div class="nav-link btn-menu">
                        <i class="icon-menu"></i>
                    </div>
                </li>
            </ul>
            <form action="" class="d-block d-lg-none">
                <div class="form-group">
                    <input type="text" placeholder=" جستجو را شروع کنید . . ." onkeyup="ajaxsearchm(this)"
                           onfocusout="jQuery('.search-box').slideUp()">
                </div>
                <button class="btn btn-search">
                    <i class="icon-search"></i>
                </button>
                <div class="search-boxm" style="display: none" onmouseleave="jQuery('.search-box').slideUp()">
                    <ul id="search-resultm">

                    </ul>
                </div>
            </form>
        </div>
    </div>
    <div class="bottom-bar d-none d-lg-block">
        <div class="container">
            <?php
            wp_nav_menu(array(
                'container' => 'ul',
                'theme_location' => 'top_bar',
                'menu_class' => 'nav top-bar-menu',

            ));
            ?>
        </div>
    </div>
</header>
