<!-- Modal -->
<div class="modal modal-bin fade" id="exampleModalCenter1" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <span class="text">
آیا میخواهید از سبد خرید حذف شود ؟
</span>
            <ul class="nav">
                <li class="nav-item bin-theme">
                    <span class="nav-link">
بله , حذف شود
</span>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link" data-dismiss="modal" aria-label="Close">
                        خیر , منصرف شدم
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>


<div id="loader-search" class="pageload-overlay search-popup"
     data-opening="M 0,0 c 0,0 63.5,-16.5 80,0 16.5,16.5 0,60 0,60 L 0,60 Z">
    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 80 60" preserveAspectRatio="none">
        <path d="M 0,0 c 0,0 -16.5,43.5 0,60 16.5,16.5 80,0 80,0 L 0,60 Z"/>
    </svg>
    <!--START-CHANGE-->
    <!--ADD DIV.DETAIL-SEARCH-->
    <div class="detail-search">
        <form action="" class="container">
            <input type="text" placeholder="هر چه می خواهید جستجو کنید ...">
            <div class="btn btn-close" id="close-search">
                <i class="icon-close"></i>
            </div>
        </form>
    </div>
    <!--END-CHANGE-->
</div>



<?php get_template_part('partials/respansive', 'menu') ?>

<!--START-MENU-RESPONSIVE-->
<section class="menu-profile">
    <div class="container position-relative">
        <a href="<?php echo get_home_url() ?>" class="brand">
            <img src="<?php echo get_template_directory_uri() . '/assets/img/logo-white.png' ?>" alt="استونز گالری">
        </a>
        <button class="btn btn-close mr-auto">
            <i class="icon-close"></i>
        </button>
        <div class="profile-section m-0 p-0">
<?php
            do_action('woocommerce_before_account_navigation');
            ?>

            <ul class="nav nav-side">
                <?php foreach (wc_get_account_menu_items() as $endpoint => $label) : ?>
                    <li class="nav-item">
                        <a href="<?php echo esc_url(wc_get_account_endpoint_url($endpoint)); ?>" class="nav-link">
                            <span class="icon">
                                <i class="icon-house"></i>
                            </span>
                            <?php echo esc_html($label); ?>
                        </a>

                    </li>
                <?php endforeach; ?>


            </ul>


            <?php do_action('woocommerce_after_account_navigation'); ?>

           <!-- <ul class="nav nav-side">
                <li class="nav-item">
                    <a href="" class="nav-link">
                            <span class="icon">
                                <i class="icon-house"></i>
                            </span>
                        داشبورد
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link sub-menu-toggle">
                            <span class="icon">
                                <i class="icon-app-store"></i>
                            </span>
                        سفارشات من
                    </a>
                    <div class="sub-menu">
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link sub-menu-toggle">
                            <span class="icon">
                                <i class="icon-invoice"></i>
                            </span>
                        امور مالی
                    </a>
                    <div class="sub-menu">
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                    </div>

                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                            <span class="icon">
                                <i class="icon-daily-health-app"></i>
                            </span>
                        علاقه مندی ها
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link sub-menu-toggle">
                            <span class="icon">
                                <i class="icon-settings1"></i>
                            </span>
                        ویرایش اطلاعات
                    </a>
                    <div class="sub-menu">
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                        <a href="">
                            تست
                        </a>
                    </div>

                </li>
                <li class="nav-item logout">
                    <a href="" class="nav-link">
                            <span class="icon">
                                <i class="icon-logout"></i>
                            </span>
                        خارج شوید
                    </a>
                </li>
            </ul>-->
        </div>
    </div>
</section>
<!--END-MENU-RESPONSIVE-->


<!--START-HEADER-->
<header class="header header-single header-profile">
    <div class="top-bar">
        <div class="container d-flex align-items-center flex-wrap">
            <a href="<?php echo get_home_url() ?>" class="brand">
                <img src="<?php echo get_template_directory_uri() . '/assets/img/logo-white.png ' ?>" alt="استونز گالری">
            </a>
            <form action="" class="d-none d-lg-block">
                <div class="form-group">
                    <input type="text" onkeyup="ajaxsearch(this)" onfocusout="jQuery('.search-box').slideUp()" placeholder="در میان بیش از 4000 محصول جستجو را شروع کنید . . .">
                </div>
                <button class="btn btn-search">
                    <i class="icon-search"></i>
                </button>
                <div class="search-box" style="display: none" onmouseleave="jQuery('.search-box').slideUp()">
                    <ul id="search-result">

                    </ul>
                </div>
            </form>
            <ul class="nav">
                <li class="nav-item">
                    <!--START-CHANGE-->
                    <a href="<?php echo get_home_url() .'/cart' ?>" class="nav-link">
                        <i class="icon-shopping-cart"></i>

                        <span class="number" id="cart-counter">
                            <?php echo WC()->cart->get_cart_contents_count(); ?>

                        </span>
                    </a>
                    <!--END-CHANGE-->
                </li>
                <li class="nav-item">
                    <a href="<?php echo get_home_url() .'/my-account' ?>" class="nav-link">
                        <i class="icon-users"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <div class="nav-link btn-menu">
                        <i class="icon-menu"></i>
                    </div>
                </li>
            </ul>
            <form action="" class="d-block d-lg-none">
                <div class="form-group">
                    <input type="text" placeholder=" جستجو را شروع کنید . . ." onkeyup="ajaxsearchm(this)" onfocusout="jQuery('.search-box').slideUp()">
                </div>
                <button class="btn btn-search">
                    <i class="icon-search"></i>
                </button>
                <div class="search-boxm" style="display: none" onmouseleave="jQuery('.search-box').slideUp()">
                    <ul id="search-resultm">

                    </ul>
                </div>
            </form>
        </div>
    </div>
</header>
<!--END-HEADER-->
