

<!--START-CHANGE-->
<!--START-MENU-RESPONSIVE-CAT-->
<section class="menu-responsive-cat">
    <div class="main-menu">
        <div class="top-bar">
            <a href="" class="brand">
                <img src="assets/img/logo-gold.png" alt="">
            </a>
            <button class="btn btn-close">
                <i class="icon-close"></i>
            </button>
        </div>
        <div class="line"></div>
        <ul class="nav">
            <li class="nav-item drop-down gold-theme">
                <a href="<?php ?>" class="nav-link">
                    دسته بندی ها
                </a>
        </ul>

        <?php
        wp_nav_menu(array(
            'container' => 'ul',
            'theme_location' => 'mega_menu_two',
            'menu_class' => 'nav meganav',

        ));


        ?>
    </div>

</section>
<!--END-MENU-RESPONSIVE-CAT-->
<!--END-CHANGE-->

<!--START-MENU-RESPONSIVE-->
<!--START-CHANGE-->
<section class="menu-responsive">
    <div class="main-menu">
        <div class="top-bar">
            <a href="<?php echo get_home_url()?>" class="brand">
                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-gold.png'?>" alt="استونز گالری">
            </a>
            <button class="btn btn-close">
                <i class="icon-close"></i>
            </button>
        </div>
        <div class="line"></div>
       <?php
       wp_nav_menu(array(
           'container' => 'ul',
           'theme_location' => 'primary_menu',
           'menu_class' => 'nav',

       ));


       ?>
   
        <div class="line"></div>
        <ul class="nav">
            <li class="nav-item drop-down gold-theme">
                <a href="<?php ?>" class="nav-link">
                    دسته بندی ها
                </a>
        </ul>

        <?php
        wp_nav_menu(array(
            'container' => 'ul',
            'theme_location' => 'mega_menu',
            'menu_class' => 'nav meganav',

        ));


        ?>



    </div>

</section>
<!--END-CHANGE-->
<!--END-MENU-RESPONSIVE-->