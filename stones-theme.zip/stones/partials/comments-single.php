<?php

$args = array(
    'status' => 'approve',
    'post_id' => $post->ID, // use post_id, not post_ID
);
$comments = get_comments($args);

foreach ($comments as $comment) :
    echo '<pre>';
//    var_dump($comment);
    echo '</pre>';
    ?>

    <div class="item">
        <div class="top-bar">
            <div class="d-flex align-items-center">
                <img src="<?php echo get_template_directory_uri() . '/assets/img/empty.png' ?>" alt="">
                <span>
                            <span class="name">
                             <?php echo $comment->comment_author ?>
                            </span>
                            <span class="date">
                               <?php echo get_comment_date('d  m  Y'); ?>
                                    /    ساعت
                                <?php echo get_comment_date('H:i'); ?>

                            </span>
                        </span>
            </div>
<!--            --><?php //var_dump( $comment) ?>
            <?php var_dump(get_comment_meta( $comment->comment_ID , 'city', true ));  ?>
            <div class="d-flex align-items-center mr-auto">
                <button class="btn btn-like">
                    <i class="icon-like"></i>
                    <span class="d-none d-xl-block">
                                    خواندن این مقاله را پیشنهاد میکنم
                                </span>
                    <span class="d-block d-xl-none">
                                    پیشنهاد میکنم
                                </span>
                </button>
                <div class="rate">
                    4.0
                    <i class="icon-star"></i>
                </div>
                <button class="btn btn-reply">
                    پاسخ دادن
                </button>
            </div>

        </div>
        <p class="text">
            <?php echo $comment->comment_content ?>
        </p>
    </div>
<?php
endforeach;