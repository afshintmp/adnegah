<!--START-HEADER-->
<header class="header header-single">
    <div class="top-bar">
        <div class="container d-flex align-items-center flex-wrap">
            <a href="" class="brand">
                <img src="assets/img/logo-gold.png" alt="">
            </a>
            <form action="" class="d-none d-lg-block">
                <div class="form-group">
                    <input type="text" placeholder="در میان بیش از 4000 محصول جستجو را شروع کنید . . .">
                </div>
                <button class="btn btn-search">
                    <i class="icon-search"></i>
                </button>
            </form>
            <ul class="nav">
                <li class="nav-item">
                    <div class="nav-link">
                        <i class="icon-shopping-cart"></i>
                    </div>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link">
                        <i class="icon-users"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <div class="nav-link btn-menu">
                        <i class="icon-menu"></i>
                    </div>
                </li>
            </ul>
            <form action="" class="d-block d-lg-none">
                <div class="form-group">
                    <input type="text" placeholder=" جستجو را شروع کنید . . .">
                </div>
                <button class="btn btn-search">
                    <i class="icon-search"></i>
                </button>
            </form>
        </div>
    </div>
    <div class="bottom-bar d-none d-lg-block">
        <div class="container">
            <?php
            wp_nav_menu( array(
                'container' => 'ul',
                'theme_location' => 'top_bar',
                'menu_class' => 'nav top-bar',


            ) );
            ?>
        </div>
    </div>
</header>
<!--END-HEADER-->