<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}

?>
<style>


    .woocommerce-NoticeGroup.woocommerce-NoticeGroup-checkout {
        width: 100%;
    }

</style>
<!--
<style>
    .form-row label{
        margin-bottom: 0;
        color: #999;
    }
    span.woocommerce-input-wrapper {
        width: 100%;
    }
    span.woocommerce-input-wrapper > input {
        padding: 5px 15px;
        border: 1px solid #eee;
        border-radius: 8px;
    }
    .select2-container--default .select2-selection--single {
        background-color: #fff;
        border: 1px solid #eee!important;
        border-radius: 4px;
        padding: 5px 15px!important;
        height: unset!important;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 26px;
        position: absolute;
        top: 6px!important;
        right: 7px!important;
        width: 20px;
    }
    textarea#order_comments{
        border: 1px solid #eee;
        border-radius: 8px;
        padding: 10px;
        resize: none;
        height: 150px;
    }
    .woocommerce-additional-fields{
        margin-top: 25px;
    }
    button#place_order{
        width: 100% !important;
        padding: 25px 10px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 18px !important;
        color: #ffffff !important;
        font-weight: 600 !important;
        background-color: #00a45b;
        border-radius: 10px !important;
        transition: all 0.3s !important;

    }
    .woocommerce-NoticeGroup.woocommerce-NoticeGroup-checkout {
        width: 100%;
    }
</style>
--><!--START-SEND-DETAIL-->
<div class="send-detail">
    <div class="container p-0 d-flex flex-wrap">
        <ul class="nav nav-shopping-steps">
            <li class="nav-item active col-4">
                    <span class="nav-link">
                        <i class="icon-shopping-cart1"></i>
                        <span class="d-none d-lg-block">
                            مرحله نخست
                        </span>
                        &nbsp;
                        سبد خرید
                    </span>
            </li>
            <li class="nav-item active col-4">
                    <span class="nav-link">
                        <i class="icon-delivery"></i>
                        <span class="d-none d-lg-block">
                            مرحله دوم
                        </span>

                        &nbsp; جزئیات ارسال
                    </span>
            </li>
            <li class="nav-item col-4">
                    <span class="nav-link">
                        <i class="icon-wallet"></i>
                        <span class="d-none d-lg-block">
                            مرحله سوم
                        </span>
                        &nbsp;   تسویه حساب
                    </span>
            </li>
        </ul>

        <!--END-SEND-DETAIL-->
        <form name="checkout" method="post" class="checkout woocommerce-checkout row"
              action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data">
            <div class="col-lg-8">
                <?php if ($checkout->get_checkout_fields()) : ?>

                    <?php do_action('woocommerce_checkout_before_customer_details'); ?>

                    <div class="col2-set" id="customer_details">
                        <div class="">
                            <?php do_action('woocommerce_checkout_billing'); ?>
                        </div>

                        <div class="">
                            <?php do_action('woocommerce_checkout_shipping'); ?>
                        </div>
                    </div>

                    <?php do_action('woocommerce_checkout_after_customer_details'); ?>

                <?php endif; ?>
            </div>
            <div class="col-lg-4">
                <?php do_action('woocommerce_checkout_before_order_review_heading'); ?>



                <?php do_action('woocommerce_checkout_before_order_review'); ?>

                <div id="order_review" class="woocommerce-checkout-review-order">
                    <?php do_action('woocommerce_checkout_order_review'); ?>
                </div>

                <?php do_action('woocommerce_checkout_after_order_review'); ?>
            </div>
        </form>


    </div>
</div>

<?php do_action('woocommerce_after_checkout_form', $checkout); ?>
