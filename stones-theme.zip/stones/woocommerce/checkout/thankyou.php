<?php
/**
 * Thankyou page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/thankyou.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.7.0
 */

defined( 'ABSPATH' ) || exit;
?>
<style>
    .bread-crumb{
        background: #00a45b
    }
</style>

	<?php
	if ( $order ) :

		do_action( 'woocommerce_before_thankyou', $order->get_id() );
		?>



            <!--START-PAYMENT-STATUS-->
            <div class="payment-status">
                <div class="container">
                    <ul class="nav row d-lg-flex d-none">
                        <li class="nav-item col-lg-4">
                    <span class="nav-link">
                        <i class="icon-shopping-cart1"></i>
                        مرحله نخست   &nbsp;  سبد خرید
                    </span>
                        </li>
                        <li class="nav-item col-lg-4">
                    <span class="nav-link">
                        <i class="icon-delivery"></i>
                        مرحله دوم     &nbsp; جزئیات ارسال
                    </span>
                        </li>
                        <li class="nav-item col-lg-4">
                    <span class="nav-link">
                        <i class="icon-wallet"></i>
                        مرحله سوم       &nbsp;   تسویه حساب
                    </span>
                        </li>
                    </ul>

                    <img src="<?php echo get_template_directory_uri() .'/assets/img/p-ok.png'?>" alt="">
                    <span class="title">
                سفارش شما با موفقیت ثبت شد
            </span>
                    <span class="subtitle">
                شماره پیگیری سفارش
                                <?php echo $order->get_order_number();  ?>
                        #

            </span>
                    <?php if (is_user_logged_in()) : ?>
                    <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id')) . '/order'; ?>" class="btn btn-submit">


                    </a>
                    <?php endif; ?>

                </div>
            </div>
            <!--END-PAYMENT-STATUS-->



	<?php else : ?>

		<p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received"><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', esc_html__( 'Thank you. Your order has been received.', 'woocommerce' ), null ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>

	<?php endif; ?>


