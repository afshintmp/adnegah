<?php
/**
 * My Account page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/my-account.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * My Account navigation.
 *
 * @since 2.6.0
 */
?>


<!--START-MAIN-->
<main>
    <!--START-PROFILE-->
    <div class="profile-section">
        <div class="container p-0 d-flex flex-wrap">
            <div class="col-xl-3 d-xl-block d-none">
                <?php do_action( 'woocommerce_account_navigation' ); ?>
            </div>
            <div class="col-xl-9">
                <div class="bar-mobile d-flex d-xl-none">
                    <div class="user">
                        <img src="<?php echo get_template_directory_uri() .'/assets/img/wmw.jpg' ?>" alt="">
                        علیرضا درخشان
                    </div>
                    <button class="btn btn-menu-profile">
                        <i class="icon-menu"></i>
                        منو کاربری
                    </button>
                </div>
                <div class="header-item   d-none d-xl-flex">
                    <div class="title">
                        <i class="icon-house"></i>
                        <span>
                            <span class="kalameh">
                                پــروفایل کاربــری شــما
                            </span>
                            خرید حرفه ای داشته باش
                        </span>
                    </div>
                    <?php
                    $user_info = get_userdata(get_current_user_id());
                    $user_name = $user_info->display_name;
                    ?>
                    <div class="login-head dropdown">
                        <div class="dropdown-toggle">

                            <span>
                        <b>
                            <?php echo $user_name ?>



                        </b>
خوش آمدید
                    </span>
                            <img src="<?php echo get_template_directory_uri() .'/assets/img/wmw.jpg' ?>" alt="">
                        </div>

                    </div>
                </div>

                <?php do_action( 'woocommerce_account_content' ); ?>

            </div>
        </div>
    </div>
    <!--END-PROFILE-->

</main>
