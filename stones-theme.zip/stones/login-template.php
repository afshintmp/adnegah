<?php
/* Template Name: Login Template */

if (is_user_logged_in()) {
    wp_redirect(get_home_url() . '/my-account');
} else {
}
if (isset($_POST['mylogin'])) {
    if (empty($_POST['myemail'])) {
        $error = true;
        $mass[] = "ایمیل خود را چک کنید";
    } else {
        $user = get_user_by('email', $_POST['myemail']);
        if (!$user) {
            $error = true;
            $mass[] = "ایمیل نامعتبر";

        } else {
            $username = sanitize_text_field($_POST['myemail']);
            if (!empty($_POST['mypass'])) {
                $creds = array(
                    'user_login' => $username,
                    'user_password' => $_POST['mypass'],
                    'remember' => true
                );
                $user = wp_signon($creds, false);
                if (is_wp_error($user)) {
                    $error = true;
                    $mass[] = "نامعتبر";
                } else {
                    wp_redirect(get_home_url() . '/my-account');
                }
            } else {
                $error = true;
                $mass[] = "ورودی پسورد را بررسی کنید";
            }
        }
    }


}

get_header('single');
global $wp;
$postthumbid = get_post_thumbnail_id();
$postthumburl = wp_get_attachment_image_url($postthumbid, 'single');
$image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

get_template_part('partials/stones', 'head') ?>

<main>

    <div class="bread-crumb">
        <div class="container d-flex justify-content-between align-items-center flex-wrap">
            <ul class="nav nav-bread">
                <li class="nav-item">
                    <a href="<?php echo get_home_url() ?>" class="nav-link">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo get_home_url() . '/login' ?>" class="nav-link">
                        ورود به حساب کاربری
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <style>
        p.my-alert {
            background: orange;
            color: #fff;
            padding: 11px;
            text-align: center;
        }
    </style>
    <div class="login-section">
        <div class="container p-0 d-flex flex-wrap">
            <div class="col-xl-6 col-lg-7">
                <div class="main">
                    <?php
                    if ($error == true) {
                        foreach ($mass as $mas) {
                            ?>
                            <p class="my-alert"><?php echo $mas ?></p>
                            <?php
                        }
                    }
                    ?>
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="" class="label">
                                پست الکترونیک
                            </label>
                            <div class="relative">
                                <input type="text" name="myemail" placeholder="email@gmail.com">
                                <i class="icon-email absolute-icon"></i>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="label">
                                کلمه عبور
                            </label>
                            <div class="relative">
                                <input type="password" name="mypass" value="" id="passinput">
                                <i class="icon-padlock absolute-icon"></i>
                                <div class="show" id="showpass">
                                    <i class="icon-visibility"></i>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex flex-wrap">
                            <div class="w-res-100">
                                <a href="<?php echo get_home_url() . '/forget' ?>" class="forget">
                                    <i class="icon-info"></i>
                                    فراموشی کلمه عبور
                                </a>
                                <span class="text">
                                    اگر حساب کاربری ندارید <a
                                            href="<?php echo get_home_url() . '/register' ?>">اینجا</a> را کلیک کنید
                                </span>
                            </div>
                            <style>
                                .login-section .btn-submit {
                                    background-color: #c3a775 !important;
                                }

                                .w-unset {
                                    width: unset !important;
                                }
                            </style>
                            <input type="submit" class="btn btn-submit w-unset" name="mylogin" value="وارد شوید">

                        </div>
                    </form>
                </div>
            </div>
            <div class="col-xl-6 col-lg-5 d-none d-lg-block">
                <div class="img">
                    <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                </div>
            </div>
        </div>
    </div>


</main>


<?php get_footer('profile') ?>


