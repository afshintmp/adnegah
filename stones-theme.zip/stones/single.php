<?php get_header('single');
global $post;
$post_id = get_the_ID();
$value = get_post_meta($post->ID, 'read_min', true);

get_template_part('partials/stones', 'head');
?>


<main>
    <!--START-BREAD-CRUMB-->
    <div class="bread-crumb">
        <div class="container d-flex justify-content-between align-items-center flex-wrap">
            <?php $terms = get_the_terms(get_the_ID(), 'category'); ?>

            <ul class="nav nav-bread">
                <li class="nav-item">
                    <a href="<?php echo get_home_url() ?>" class="nav-link">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <?php foreach ($terms as $term): ?>
                    <li class="nav-item">
                        <a href="<?php echo get_home_url() . '/blog?catid=' . $term->term_id ?>" class="nav-link">
                            <?php echo $term->name ?>
                        </a>
                    </li>
                <?php endforeach; ?>


                <li class="nav-item">
                    <a href="<?php echo get_permalink() ?>" class="nav-link">
                        <?php echo get_the_title() ?>
                    </a>
                </li>
            </ul>
            <span class="count mr-auto d-lg-block d-none">
                منتشر شده در تاریخ
                <?php echo get_the_date() ?>
            </span>

        </div>
    </div>
    <!--END-BREAD-CRUMB-->

    <!--START-BLOG-SINGLE-->
    <div class="blog-single">
        <div class="container p-0 d-flex flex-wrap">
            <div class="col-xl-3 col-lg-4 d-none d-lg-block">
                <div class="sidebar">
                    <form action="">
                        <div class="form-group">
                            <input class="search" type="text" placeholder="جستجو کنید . . .">
                            <button class="btn btn-search">
                                <i class="icon-search"></i>
                            </button>
                        </div>
                    </form>

                    <?php
                    $query_args = array(
                        'posts_per_page' => 8,
                        'no_found_rows' => 1,
                        'post_status' => 'publish',
                        'post_type' => 'product',
                        'meta_query' => WC()->query->get_meta_query(),
                        'post__in' => array_merge(array(0), wc_get_product_ids_on_sale())
                    );
                    $query = new WP_Query($query_args);

                    ?>
                    <?php if ($query->have_posts()) : ?>
                        <div class="box">
                        <span class="title-box">
                            فـــــروش ویـــــژه
                        </span>

                            <div class="products m-0 p-0">
                                <div class="swiper-container swiper-products-4">
                                    <div class="swiper-wrapper">
                                        <?php while ($query->have_posts()) : $query->the_post();

                                            $postthumbid = get_post_thumbnail_id();
                                            $postthumburl = wp_get_attachment_image_url($postthumbid, 'single');
                                            $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
                                            ?>
                                            <a href="<?php echo get_the_permalink() ?>" class="item swiper-slide">
                                                <article>
                                                    <img src="<?php echo $postthumburl ?>"
                                                         alt="<?php echo $image_alt ?>">
                                                    <span class="title">
                                                     <?php echo get_the_title() ?>

                            </span>
                                                    <span class="subtitle">

                                                      <?php
                                                      $english_format_number = number_format(get_post_meta(get_the_ID(), '_price', true), 0, '.', ',');

                                                      echo $english_format_number ?>
                                                        <?php echo get_woocommerce_currency_symbol() ?>
                            </span>
                                                </article>
                                            </a>
                                        <?php endwhile; ?>
                                    </div>
                                    <div class="swiper-pagination swiper-pagination-products-4"></div>
                                </div>
                            </div>
                        </div>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                    <?php endif; ?>

                    <div class="box">
                        <span class="title-box">
                            اخبار و مقالات مرتبط
                        </span>
                        <div class="products m-0 p-0">
                            <div class="swiper-container swiper-article-1">
                                <div class="swiper-wrapper">

                                    <?php $ralated_term = get_the_terms($post->ID, 'category') ?>
                                    <?php
                                    $termrelated = array();
                                    foreach ($ralated_term as $term) {
                                        $termrelated[] = $term->term_id;
                                    }

                                    $args = array(
                                        'post_per_page' => 5,
                                        'post_type' => 'post',
                                        'category__in' => $termrelated
                                    );

                                    $the_query = new WP_Query($args);


                                    if ($the_query->have_posts()) {

                                        while ($the_query->have_posts()) {

                                            $the_query->the_post();
                                            if (get_the_ID() !== $post_id) {
                                                $postthumbid = get_post_thumbnail_id();

                                                $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
                                                ?>
                                                <a href="<?php echo get_the_permalink() ?>"
                                                   class="item-article swiper-slide"
                                                   style="background-image: url(<?php echo $postthumburl ?>)">
                        <span>
                            <b>
                            <?php echo get_the_title() ?>
                            </b>
                          <?php echo get_the_date() ?>
                            /
                             <?php $terms = get_the_terms(get_the_ID(), 'category');

                             $i = 1; ?>

                            <?php foreach ($terms as $term) {

                                if ($i !== 1) {
                                    echo ' / ';
                                }

                                echo $term->name;
                                $i++;
                            } ?>
                        </span>
                                                </a>
                                                <?php
                                            }
                                        }

                                    } else {

                                    }

                                    wp_reset_postdata();

                                    ?>


                                </div>
                                <div class="swiper-pagination swiper-pagination-article-1"></div>
                            </div>
                        </div>


                    </div>
                    <ul class="nav nav-social">
                        <li class="nav-item">
                            <a href="" class="nav-link">
                                <i class="icon-instagram"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo 'https://www.facebook.com/sharer/sharer.php?u=' . get_permalink() ?>"
                               class="nav-link">
                                <i class="icon-facebook"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link">
                                <i class="icon-telegram"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link">
                                <i class="icon-twitter"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link">
                                <i class="icon-whatsapp"></i>
                            </a>
                        </li>
                    </ul>
                    <div class="box">
                        <span class="title-box">
                            نویسنده این مقاله
                        </span>
                        <div class="writer">
                            <img src="<?php echo get_template_directory_uri() . '/assets/img/empty.png' ?>" alt="">
                            <span>
                                <b>
                                   <?php echo get_the_author(); ?>
                                </b>
                                مشاهده نوشته ها
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-9 col-lg-8">
                <div class="main-blog">
                    <?php
                    $postthumbid = get_post_thumbnail_id();

                    $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
                    ?>
                    <div class="image"
                         style="background-image: url(<?php echo $postthumburl ?>);background-size: cover;background-repeat: no-repeat">
                        <article>
                            <div class="d-flex align-items-center">
                                <?php if (!empty($value)): ?>
                                    <span class="time">
                                        زمان مطالعه
                                        <?php echo $value ?>
                                        دقیقه
                                    </span>
                                <?php endif; ?>
                                <ul class="nav">

                                    <li class="nav-item">
                                        <i class="icon-chat"></i>
                                        <?php echo get_comments_number() ?>
                                        نظر
                                    </li>
                                </ul>
                            </div>
                            <h1 class="title">
                                  <?php echo get_the_title() ?>
                                </h1>
                            <?php $terms = get_the_terms($post->ID, 'category');

                            $i = 1; ?>
                            <span class="subtitle">
                                <?php foreach ($terms as $term) {
                                    if ($i !== 1) {
                                        echo ' / ';
                                    }
                                    echo $term->name;
                                    $i++;
                                } ?>

                                </span>
                        </article>
                    </div>
                    <p class="text bold-theme">
                        <?php echo get_the_excerpt() ?>
                    </p>
                </div>
                <p class="text">
                    <?php  the_content(); ?>
                </p>
                <ul class="nav nav-social d-flex d-lg-none">
                    <li class="nav-item">
                        <a href="" class="nav-link">
                            <i class="icon-instagram"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link">
                            <i class="icon-facebook"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link">
                            <i class="icon-telegram"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link">
                            <i class="icon-twitter"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link">
                            <i class="icon-whatsapp"></i>
                        </a>
                    </li>
                </ul>
                <div class="related">
                    <span class="title">
                        موضوعات مرتبط با این مقاله
                    </span>
                    <ul class="nav">
                        <?php
                        $posttags = get_the_tags();
                        if ($posttags) {
                            foreach ($posttags as $tag) {
                                ?>
                                <li class="nav-item">
                                    <a href="<?php echo get_home_url() .'/blog?tagid='. $tag->term_id ?>" class="nav-link">
                                        <?php echo $tag->name ?>
                                    </a>
                                </li>
                                <?php
                            }
                        }
                        ?>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--END-BLOG-SINGLE-->


    <!--START-FORM-ELEMENTS-->
    <div class="form-elements only-section" id="target4">
        <div class="container">
            <span class="title kalameh">
                <img src="<?php echo get_template_directory_uri() . '/assets/img/shape-1.png' ?>" alt="shape">
                فــرم ارســال نــظر کاربــران
            </span>
            <?php
            $commenter = wp_get_current_commenter();
            $req = get_option('require_name_email');
            $aria_req = ($req ? " aria-required='true'" : '');
            $fields = array(
                'author' => '  <div class="row align-items-center">
     <div class="col-xl-6 p-0 d-flex flex-wrap">
                                    <div class="col-md-12 prl-10px">
                                        <div class="form-group">
                                            <label for="name" class="label">
                                                نام و نام خانوادگی
                                            </label>
                                            <input type="text" name="author" id="name" placeholder="سید فرهاد" value="' . esc_attr($commenter['comment_author']) . '">
                                            <i class="icon-user absolute-icon"></i>
                                        </div>
                                    </div>',
                'email' => ' <div class="col-md-12 prl-10px">
                                 <div class="form-group">
                                     <label for="phone" class="label">
                                         ایمیل
                                     </label>
                                     <input type="text"  name="email" id="email" placeholder="info @ Stones - Gallery.ir" value="' . esc_attr($commenter['comment_author_email']) . '">
                                     <i class="icon-phone absolute-icon"></i>
                                 </div>
                             </div>
                             </div>
                   ',
            );
            $comments_args = array(

                'fields' => $fields,
                'comment_field' => ' <div class="col-xl-6 prl-10px">
                        <div class="form-group">
                            <label for="text" class="label">
                                نظر خود را یادداشت کنید
                            </label>
                            <textarea id="text" name="comment" style="resize: none"
                                      placeholder="در این بخش میتوانید نظر یا پیشنهاد خود را مطرح کنید . . ."></textarea>
                        </div>

                    </div>',
                'label_submit' => ' نظر خود را ارسال کنید',
                'submit_button' => ' <div class="col-sm-auto mr-auto prl-10px">
 <input name="%1$s" type="submit" id="%2$s" class="%3$s btn btn-submit" value="نظر خود را ارسال کنید" />  </div>
                  ',
                'title_reply' => '',
                'comment_notes_before' => '',
                'comment_notes_after' => '',


            );
            comment_form($comments_args);
            ?>

        </div>
    </div>

    <div class="comment-section">
        <div class="container">
            <span class="title kalameh">
                <img src="assets/img/shape-1.png" alt="">
                نــظرات کاربــران دربــاره مقالــه
            </span>
            <?php
            $comment_args = array(
                'orderby' => 'comment_date_gmt',
                'order' => 'DESC',
                'status' => 'approve',
                'post_id' => $post->ID,
                'no_found_rows' => false,
                'update_comment_meta_cache' => false, // We lazy-load comment meta for performance.
            );
            $comment_query = new WP_Comment_Query($comment_args);
            $_comments = $comment_query->comments;


            $comments_flat = array();
            foreach ($_comments as $_comment) {
                $comments_flat[] = $_comment;
                $comment_children = $_comment->get_children(
                    array(
                        'format' => 'flat',
                        'status' => $comment_args['status'],
                        'orderby' => $comment_args['orderby'],
                    )
                );

                foreach ($comment_children as $comment_child) {
                    $comments_flat[] = $comment_child;
                }
            }


            foreach ($comments_flat as $comment) {
                if ($comment->comment_parent == 0) {
                    ?>

                    <div class="w-100">
                        <div class="item">
                            <div class="top-bar">
                                <div class="d-flex align-items-center">
                                    <img src="<?php echo get_template_directory_uri() . '/assets/img/empty.png' ?>"
                                         alt="">
                                    <span>
                            <span class="name">
                                <?php echo $comment->comment_author ?>
                            </span>
                            <span class="date">
                                <?php echo $comment->comment_date ?>
                            </span>
                        </span>
                                </div>
                                <div class="d-flex align-items-center mr-auto">

                                    <a class="btn btn-reply"
                                       href="<?php echo '?replytocom=' . $comment->comment_ID . '#respond' ?>">
                                        پاسخ دادن
                                    </a>
                                </div>

                            </div>
                            <p class="text">
                                <?php echo $comment->comment_content ?>
                            </p>
                        </div>
                        <?php foreach ($comment->get_children() as $child_cm) {
                            $aouther_id = $child_cm->user_id;

                            if ($aouther_id !== null && $aouther_id !== 0) {
                                $user_meta = get_userdata($aouther_id);
                                if ($user_meta) {
                                    $user_roles = $user_meta->roles;
                                }
                            }
                            if ($aouther_id && in_array('administrator', $user_roles, true)) {
                                ?>

                                <div class="item reply-theme gold-theme">
                                    <div class="top-bar">
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo get_template_directory_uri() . '/assets/img/empty.png' ?>"
                                                 alt="">
                                            <span>
                               <span class="name">
                                   کارشناس فروش
                               </span>
                               <span class="date">
                                   <?php echo $comment->comment_date ?>
                               </span>
                           </span>
                                        </div>
                                        <div class="d-flex align-items-center mr-auto">
                                            <a class="btn btn-reply"
                                               href="<?php echo '?replytocom=' . $comment->comment_ID . '#respond' ?>">
                                                پاسخ دادن
                                            </a>
                                        </div>
                                    </div>
                                    <p class="text">
                                        <?php echo $comment->comment_content ?>
                                    </p>
                                </div>
                                <?php
                            } else {
                                ?>
                                <div class="item reply-theme mb-3">
                                    <div class="top-bar">
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo get_template_directory_uri() . '/assets/img/empty.png' ?>"
                                                 alt="">
                                            <span>
                               <span class="name">
                                   <?php echo $comment->comment_author ?>
                               </span>
                               <span class="date">
                                   <?php echo $comment->comment_date ?>
                               </span>
                           </span>
                                        </div>
                                        <div class="d-flex align-items-center mr-auto">

                                            <a class="btn btn-reply"
                                               href="<?php echo '?replytocom=' . $comment->comment_ID . '#respond' ?>">
                                                پاسخ دادن
                                            </a>
                                        </div>

                                    </div>
                                    <p class="text">
                                        <?php echo $comment->comment_content ?>
                                    </p>
                                </div>
                                <?php
                            }
                        } ?>
                    </div>
                <?php } ?>

            <?php } ?>
            <!-- <div class="w-100">
                 <div class="item">
                     <div class="top-bar">
                         <div class="d-flex align-items-center">
                             <img src="assets/img/empty.png" alt="">
                             <span>
                                <span class="name">
                                    فرهاد موسوی راد
                                </span>
                                <span class="date">
                                    24 اسفند ماه 1399    /    ساعت 15:48 ظهر
                                </span>
                            </span>
                         </div>
                         <div class="d-flex align-items-center mr-auto">
                             <button class="btn btn-like">
                                 <i class="icon-like"></i>
                                 <span class="d-none d-xl-block">
                                        خواندن این مقاله را پیشنهاد میکنم
                                    </span>
                                 <span class="d-block d-xl-none">
                                        پیشنهاد میکنم
                                    </span>
                             </button>
                             <div class="rate">
                                 4.0
                                 <i class="icon-star"></i>
                             </div>
                             <button class="btn btn-reply">
                                 پاسخ دادن
                             </button>
                         </div>

                     </div>
                     <p class="text">
                         لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.
                         چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی
                         تکنولوژی
                         مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه
                         درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت
                         بیشتری
                         را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در
                         این
                         صورت می توان امید داشت که تمام و دشواری موجود است .
                     </p>
                 </div>

                 <div class="item reply-theme">
                     <div class="top-bar">
                         <div class="d-flex align-items-center">
                             <img src="assets/img/empty.png" alt="">
                             <span>
                                <span class="name">
                                    فاطمه فرهادی پور
                                </span>
                                <span class="date">
                                    24 اسفند ماه 1399    /    ساعت 15:48 ظهر
                                </span>
                            </span>
                         </div>
                         <div class="d-flex align-items-center mr-auto">
                             <button class="btn btn-like">
                                 <i class="icon-like"></i>
                                 <span class="d-none d-xl-block">
                                        خواندن این مقاله را پیشنهاد میکنم
                                    </span>
                                 <span class="d-block d-xl-none">
                                        پیشنهاد میکنم
                                    </span>
                             </button>
                             <div class="rate">
                                 4.0
                                 <i class="icon-star"></i>
                             </div>
                             <button class="btn btn-reply">
                                 پاسخ دادن
                             </button>
                         </div>

                     </div>
                     <p class="text">
                         لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.
                         چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی
                         تکنولوژی
                         مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه
                         درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت
                         بیشتری
                         را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در
                         این
                         صورت می توان امید داشت که تمام و دشواری موجود است .
                     </p>
                 </div>
                 <div class="item reply-theme gold-theme">
                     <div class="top-bar">
                         <div class="d-flex align-items-center">
                             <img src="assets/img/empty.png" alt="">
                             <span>
                                <span class="name">
                                    کارشناس فروش
                                </span>
                                <span class="date">
                                    24 اسفند ماه 1399    /    ساعت 15:48 ظهر
                                </span>
                            </span>
                         </div>
                         <div class="d-flex align-items-center mr-auto">
                             <button class="btn btn-reply">
                                 پاسخ دادن
                             </button>
                         </div>
                     </div>
                     <p class="text">
                         لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.
                         چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی
                         تکنولوژی
                         مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه
                         درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت
                         بیشتری
                         را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در
                         این
                         صورت می توان امید داشت که تمام و دشواری موجود است .
                     </p>
                 </div>
             </div>-->


        </div>
    </div>
</main>


<?php get_footer(); ?>

