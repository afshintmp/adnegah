<?php
global $options ;
$p_num = get_option('p-num',false);
$f_eml = get_option('f_eml',false);
$face_book = get_option('face_book',false);
$insta = get_option('insta',false);
$twiter = get_option('twiter',false);
$enmad_1 = get_option('enmad_1',false);
$enmad_2 = get_option('enmad_2',false);
?>
<footer class="footer">
    <div class="top-bar">
        <div class="container p-0 d-flex align-items-center justify-content-between flex-wrap">
            <div class="col-lg-auto ">
                <a href="<?php echo get_home_url()?>" class="brand">
                    <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-gray.png' ?>" alt="استونز گالری">
                </a>
            </div>
            <div class="col-lg-auto col-sm-6">
                <div class="info">
                    <i class="icon-headphone"></i>
                    <span>
                            پشتیبانی فروش
                            <b style="">
                                <?php echo $p_num ?>
                            </b>
                    </span>
                </div>
            </div>
            <div class="col-lg-auto col-sm-6">
                <div class="info">
                    <i class="icon-email"></i>
                    <span>
                            پست الکترونیک
                            <b class="email">
                                 <?php echo $f_eml ?>
                            </b>
                        </span>
                </div>
            </div>
            <div class="col-lg-auto  d-flex ">
                <a href="" class="namad">
                    <img src="<?php echo $enmad_1 ?>" alt="نماد اعتماد">
                </a>
                <a href="" class="namad">
                    <img src="<?php echo $enmad_2 ?>" alt="نماد اعتماد">
                </a>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="lines">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
    </div>
    <div class="bottom-bar">
        <div class="container d-flex flex-wrap align-items-center">
                <span class="copyright">
                    تمامی حقوق این سایت متعلق به گالری سنگ تهرانی می باشد .
                    <br>
                      طراحی وب سایت توسط
           <a href="https://adnegah.net">ادنگاه</a>


                </span>
            <?php
            wp_nav_menu( array(
                'container' => 'ul',
                'theme_location' => 'footer_menu',
                'menu_class' => 'nav nav-menu',

            ) );
            ?>

            <ul class="nav nav-social">
                <li class="nav-item">
                    <a href="<?php echo $face_book ?>" class="nav-link">
                        <i class="icon-facebook"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo $twiter ?>" class="nav-link">
                        <i class="icon-twitter"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo $insta ?>" class="nav-link">
                        <i class="icon-instagram"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</footer>
<!--END-FOOTER-->



<?php wp_footer(); ?>

<script src="<?php echo get_template_directory_uri() .'/assets/js/jquery-3.3.1.min.js' ?>"></script>
<script src="<?php echo get_template_directory_uri() .'/assets/js/Bootstrap/bootstrap.bundle.min.js' ?>"></script>
<script src="<?php echo get_template_directory_uri() .'/assets/js/swiper/swiper.min.js' ?>"></script>
<script src="<?php echo get_template_directory_uri() .'/assets/js/Select2/select2.min.js' ?>"></script>
<script src="<?php echo get_template_directory_uri() .'/assets/js/svgloader/snap.svg-min.js' ?>"></script>
<script src="<?php echo get_template_directory_uri() .'/assets/js/svgloader/classie.js' ?>"></script>
<script src="<?php echo get_template_directory_uri() .'/assets/js/svgloader/svgLoader.js' ?>"></script>
<script src="<?php echo get_template_directory_uri() .'/assets/js/custom.js' ?>"></script>

<script>

    $(".tab-cat").click(function(){
        // get the data-filter value of the button
        var filterValue = $(this).attr('data-filter');

        $('.category-container').hide()


        $('.filter-cat').not('.'+filterValue).hide();
        $('.filter-cat').filter('.'+filterValue).show();

    });
    $(".mega-menu .return").click(function(){
        $('.sub-container').hide()
        $('.category-container').show()
    });

    $('.drop-down-l-1').click(function () {
        $(this).toggleClass('active')
        $(this).parent().find('.nav-l-1').slideToggle()
    })
    $('.drop-down-l-2').click(function () {
        $(this).toggleClass('active')
        $(this).parent().find('.nav-l-2').slideToggle()
    })

</script>

<script>
    var $ = jQuery
    jQuery(document).ready(function(){
        resizeContent();

        $(window).resize(function() {
            resizeContent();
        });
    });

    function resizeContent() {
        $height = $(window).height();
        $('.full-height').css('height',$height);
    }

</script>
<script>
    var $ = jQuery
    $('.drop-click').click(function () {
        $(this).toggleClass('show')
        $(this).find('i').toggle()
        $(this).parent().find('.body').slideToggle()
    })
</script>
<script>
    jQuery('.meganav > li > a').on('click',function (e){
        e.preventDefault()
        jQuery(this).parent().find('ul').slideToggle()
    })
</script>
<!--START-CHANGE-->
<script>
    $(document).ready(function (){
        $('.header .bottom-bar .nav li:first-child .nav-link').removeAttr("href").css('cursor','pointer');
    })
    $('.header .bottom-bar .nav li:first-child .nav-link').click(function (){
        $('.menu-responsive-cat').fadeIn();
        $('.menu-responsive-cat').addClass('show')
    })
    $('.menu-responsive-cat .btn-close').click(function () {
        $('.menu-responsive-cat').fadeOut();
        $('.menu-responsive-cat').removeClass('show')
    })
</script>
<!--END-CHANGE-->
</body>
</html>