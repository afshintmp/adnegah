<?php
/* Template Name: Warraper Template */
get_header('single'); ?>

<?php get_template_part('partials/stones', 'head') ?>

<main>
    <!--START-BREAD-CRUMB-->
    <div class="bread-crumb">
        <div class="container d-flex justify-content-between align-items-center flex-wrap">
            <ul class="nav nav-bread">
                <li class="nav-item">
                    <a href="<?php echo get_home_url() ?>" class="nav-link">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo get_permalink() ?>" class="nav-link">
                        <?php echo get_the_title() ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php the_content(); ?>
    </div>
</main>


<?php get_footer() ?>

