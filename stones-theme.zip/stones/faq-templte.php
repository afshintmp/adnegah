<?php

/* Template Name: FAQ Template */
get_header('single');
global $wp;
$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>


<?php get_template_part('partials/stones', 'head') ?>


    <!--START-MAIN-->
    <main>
        <!--START-BREAD-CRUMB-->
        <div class="bread-crumb">
            <div class="container d-flex justify-content-between align-items-center flex-wrap">
                <ul class="nav nav-bread">
                    <li class="nav-item">
                        <a href="<?php echo get_home_url() ?>" class="nav-link">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <h1  class="nav-link">
                            پرسش های متداول کاربران
                        </h1>
                    </li>
                </ul>
            </div>
        </div>
        <!--END-BREAD-CRUMB-->

        <!--START-FAQ-->
        <div class="faq">
            <div class="container p-0 d-flex flex-wrap">
                <?php
                $terms = get_terms(array(
                    'taxonomy' => 'cat',
                    'hide_empty' => false,
                ));
                $i = 1;
                ?>
                <ul class="nav nav-tab prl-5px">
                    <?php foreach ($terms as $term) {
                        $value = get_term_meta($term->term_id, 'misha-text', true);
                        if (isset($_GET['temid'])) {
                            ?>
                            <li class="nav-item <?php echo $_GET['temid'] == $term->term_id ? 'active' : '' ?> tab-item col-lg-3 col-6 prl-10px">
                            <?php
                        } else {
                            ?>

                            <li class="nav-item <?php echo $i == 1 ? 'active' : '' ?> tab-item col-lg-3 col-6 prl-10px">
                        <?php } ?>
                        <a href="<?php echo add_query_arg('temid', $term->term_id, $url); ?>">
                            <div class="main-item">

                                <i class="<?php echo $value ?>"></i>
                                <span>
                            <b><?php echo $term->name ?></b>
                            <?php echo $term->count ?>
                             پرسش و پاسخ
                        </span>

                            </div>
                        </a>
                        </li>
                        <?php
                        $i++;
                    } ?>
                </ul>


                <div class="row w-100 m-0 flex-column-reverse flex-lg-row">
                    <div class="col-xl-3 col-lg-4">
                        <div class="box-comment">
                             <span class="title kalameh">
                                پــرسش جدیــد
                            </span>
                            <?php echo do_shortcode('[contact-form-7 id="90"]') ?>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-8">
                        <form class="search" id="searchmy" action="<?php echo $url ?>" method="get">
                            <div class="form-group">
                                <input name="keysearch" class="change-text" type="text"
                                       placeholder="سوال مورد نظر خود را درباره مرجوع مرسوله جستجو کنید . . .">
                            </div>
                            <button form="searchmy" class="btn btn-search">
                                <i class="icon-search"></i>
                            </button>
                        </form>

                        <ul class="accordion-menu">

                            <?php
                            $args = array(
                                'post_type' => 'faq',

                            );
                            if (isset($_GET['temid'])) {
                                $args['tax_query'] = array(
                                    array(
                                        'taxonomy' => 'cat',
                                        'field' => 'term_id',
                                        'terms' => $_GET['temid'],
                                    ),
                                );
                            } else {
                                $args['tax_query'] = array(
                                    array(
                                        'taxonomy' => 'cat',
                                        'field' => 'term_id',
                                        'terms' => '23',
                                    ),
                                );
                            }
                            if (isset($_GET['keysearch'])) {
                                $args['s'] = $_GET['keysearch'];
                            }

                            $the_query = new WP_Query($args);


                            if ($the_query->have_posts()) {

                                while ($the_query->have_posts()) {
                                    $the_query->the_post();
                                    ?>
                                    <li class="item-accordion">
                                        <h2  class="dropdownlink" onclick="return false">
                                            <?php echo get_the_title() ?>
                                            <i class="icon-plus1 plus"></i>
                                            <i class="icon-minus minus"></i>
                                        </h2>
                                        <div class="submenu">
                                            <p class="text">
                                                <?php the_content(); ?>
                                            </p>
                                        </div>
                                    </li>
                                    <?php
                                }

                            } else {

                            }

                            wp_reset_postdata();
                            ?>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
        <!--END-FAQ-->
    </main>
    <!--END-MAIN-->


<?php get_footer() ?>