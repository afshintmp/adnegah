<?php
/* Template Name: Index Template */

get_header();
global $option;
$baner_1 = get_option('baner-1', false);
$baner_2 = get_option('baner-2', false);
$baner_3 = get_option('baner-3', false);
$baner_4 = get_option('baner-4', false);
$baner_5 = get_option('baner-5', false);
$pic_1 = get_option('pic-1', false);
$pic_2 = get_option('pic-2', false);
$pic_3 = get_option('pic-3', false);
$pic_4 = get_option('pic-4', false);
$pic_5 = get_option('pic-5', false);
$tt_1 = get_option('tt-1', false);
$tt_2 = get_option('tt-2', false);
$tt_3 = get_option('tt-3', false);
$tt_4 = get_option('tt-4', false);
$tt_5 = get_option('tt-5', false);
$st_1 = get_option('st-1', false);
$st_2 = get_option('st-2', false);
$st_3 = get_option('st-3', false);
$st_4 = get_option('st-4', false);
$st_5 = get_option('st-5', false);
$alt_1_1 = get_option('alt-1-1', false);
$alt_1_2 = get_option('alt-1-2', false);

$alt_2_1 = get_option('alt-2-1', false);
$alt_2_2 = get_option('alt-2-2', false);

$alt_3_1 = get_option('alt-3-1', false);
$alt_3_2 = get_option('alt-3-2', false);

$alt_4_1 = get_option('alt-4-1', false);
$alt_4_2 = get_option('alt-4-2', false);

$alt_5_1 = get_option('alt-5-1', false);
$alt_5_2 = get_option('alt-5-2', false);


$l_1 = get_option('l-1', false);
$l_2 = get_option('l-2', false);
$l_3 = get_option('l-3', false);
$l_4 = get_option('l-4', false);
$l_5 = get_option('l-5', false);
?>

<div id="loader-search" class="pageload-overlay search-popup"
     data-opening="M 0,0 c 0,0 63.5,-16.5 80,0 16.5,16.5 0,60 0,60 L 0,60 Z">
    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 80 60" preserveAspectRatio="none">
        <path d="M 0,0 c 0,0 -16.5,43.5 0,60 16.5,16.5 80,0 80,0 L 0,60 Z"/>
    </svg>

    <div class="detail-search">
        <form action="" class="container">
            <input type="text" placeholder="هر چه می خواهید جستجو کنید ...">
            <div class="btn btn-close" id="close-search">
                <i class="icon-close"></i>
            </div>
        </form>
    </div>

</div>


<?php get_template_part('partials/respansive', 'menu') ?>


<header class="header">
    <div class="top-bar">
        <div class="container d-flex justify-content-between align-items-center">
            <a href="<?php echo get_home_url() ?>" class="brand">
                <img src="<?php echo get_template_directory_uri() . '/assets/img/logo-white.png' ?> "
                     alt="stones-gallery">
            </a>
            <ul class="nav">
                <li class="nav-item">
                    <!--START-CHANGE-->
                    <a href="<?php echo get_home_url() .'/cart' ?>" class="nav-link">
                        <i class="icon-shopping-cart"></i>

                        <span class="number" id="cart-counter">
                            <?php echo WC()->cart->get_cart_contents_count(); ?>

                        </span>
                    </a>
                    <!--END-CHANGE-->
                </li>
                <li class="nav-item">
                    <a href="<?php echo get_home_url().'/my-account' ?>" class="nav-link">
                        <i class="icon-users"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <div class="nav-link btn-menu">
                        <i class="icon-menu"></i>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="swiper-container swiper-header">
        <div class="swiper-wrapper">
            <?php if (!empty($baner_1)) : ?>
                <div class="swiper-slide item">
                    <div class="col-md-6 p-0">
                        <div class="bg full-height has-after">
                            <img class="main-img"
                                 src="<?php echo $baner_1 ?>" alt="<?php echo $alt_1_1 ?>">
                        </div>
                    </div>
                    <div class="col-md-6 p-0 d-md-block d-none">
                        <div class="bg full-height">
                            <!--START-CHANGE-->
                            <a href="<?php echo $l_1 ?>">
                                <img class="side-img" src="<?php echo $pic_1 ?>" alt="<?php echo $alt_1_2 ?>">
                            </a>
                            <!--END-CHANGE-->

                        </div>
                    </div>
                    <div class="absolute-bar container p-0 d-flex align-items-end flex-wrap">
                        <div class="col-xl-6">
                            <article>
                                <h2 class="title kalameh">

                                    <!--START-CHANGE-->
                                    <a href="<?php echo $l_1 ?>">
                                        <?php echo $tt_1 ?>
                                    </a>
                                    <!--END-CHANGE-->
                                </h2>
                                <span class="subtitle">
                                      <a href="<?php echo $l_1 ?>">
                                       <?php echo $st_1 ?>
                                      </a>
                                </span>
                            </article>
                        </div>
                        <div class="col-xl-6">
                            <div class="pagination swiper-pagination-header"></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (!empty($baner_2)) : ?>
                <div class="swiper-slide item">
                    <div class="col-md-6 p-0">
                        <div class="bg full-height has-after">
                            <a href="<?php echo $l_2 ?>">
                                <img class="main-img"
                                     src="<?php echo $baner_2 ?>" alt="<?php echo $alt_2_1 ?>">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 p-0 d-md-block d-none">
                        <div class="bg full-height">
                            <a href="<?php echo $l_2 ?>">
                                <img class="side-img"
                                     src="<?php echo $pic_2 ?>" alt="<?php echo $alt_2_2 ?>">
                            </a>
                        </div>
                    </div>
                    <div class="absolute-bar container p-0 d-flex align-items-end flex-wrap">
                        <div class="col-xl-6">
                            <article>
                                <h2 class="title kalameh">
                                    <a href="<?php echo $l_2 ?>">
                                        <?php echo $tt_2 ?>
                                    </a>
                                </h2>
                                <span class="subtitle">
                                      <a href="<?php echo $l_2 ?>">
                                       <?php echo $st_2 ?>
                                      </a>
                                </span>
                            </article>
                        </div>
                        <div class="col-xl-6">
                            <div class="pagination swiper-pagination-header"></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (!empty($baner_3)) : ?>
                <div class="swiper-slide item">
                    <div class="col-md-6 p-0">
                        <div class="bg full-height has-after">
                            <a href="<?php echo $l_3 ?>">
                                <img class="main-img"
                                     src="<?php echo $baner_3 ?>" alt="<?php echo $alt_3_1 ?>">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 p-0 d-md-block d-none">
                        <div class="bg full-height">
                            <a href="<?php echo $l_3 ?>">
                                <img class="side-img"
                                     src="<?php echo $pic_3 ?>" alt="<?php echo $alt_3_2 ?>">
                            </a>
                        </div>
                    </div>
                    <div class="absolute-bar container p-0 d-flex align-items-end flex-wrap">
                        <div class="col-xl-6">
                            <article>
                                <h2 class="title kalameh">
                                    <a href="<?php echo $l_3 ?>">
                                        <?php echo $tt_3 ?>
                                    </a>

                                </h2>
                                <span class="subtitle">
                                        <a href="<?php echo $l_3 ?>">
                                       <?php echo $st_3 ?>
                                        </a>
                                </span>
                            </article>
                        </div>
                        <div class="col-xl-6">
                            <div class="pagination swiper-pagination-header"></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (!empty($baner_4)) : ?>
                <div class="swiper-slide item">
                    <div class="col-md-6 p-0">
                        <div class="bg full-height has-after">
                            <a href="<?php echo $l_4 ?>">
                                <img class="main-img"
                                     src="<?php echo $baner_4 ?>" alt="<?php echo $alt_4_1 ?>">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 p-0 d-md-block d-none">
                        <div class="bg full-height">
                            <a href="<?php echo $l_4 ?>">
                                <img class="side-img"
                                     src="<?php echo $pic_4 ?>" alt="<?php echo $alt_4_2 ?>">
                            </a>
                        </div>
                    </div>
                    <div class="absolute-bar container p-0 d-flex align-items-end flex-wrap">
                        <div class="col-xl-6">
                            <article>
                                <h2 class="title kalameh">
                                    <a href="<?php echo $l_4 ?>">
                                        <?php echo $tt_4 ?>
                                    </a>

                                </h2>
                                <span class="subtitle">
                                        <a href="<?php echo $l_4 ?>">
                                       <?php echo $st_4 ?>
                                        </a>
                                </span>
                            </article>
                        </div>
                        <div class="col-xl-6">
                            <div class="pagination swiper-pagination-header"></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (!empty($baner_5)) : ?>
                <div class="swiper-slide item">
                    <div class="col-md-6 p-0">
                        <div class="bg full-height has-after">
                            <a href="<?php echo $l_5 ?>">
                                <img class="main-img"
                                     src="<?php echo $baner_5 ?>" alt="<?php echo $alt_5_1 ?>">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 p-0 d-md-block d-none">
                        <div class="bg full-height">
                            <a href="<?php echo $l_5 ?>">
                                <img class="side-img"
                                     src="<?php echo $pic_5 ?>" alt="<?php echo $alt_5_2 ?>">
                            </a>
                        </div>
                    </div>
                    <div class="absolute-bar container p-0 d-flex align-items-end flex-wrap">
                        <div class="col-xl-6">
                            <article>
                                <h2 class="title kalameh">
                                    <a href="<?php echo $l_5 ?>">
                                        <?php echo $tt_5 ?>
                                    </a>

                                </h2>
                                <span class="subtitle">
                                        <a href="<?php echo $l_5 ?>">
                                       <?php echo $st_5 ?>
                                        </a>
                                </span>
                            </article>
                        </div>
                        <div class="col-xl-6">
                            <div class="pagination swiper-pagination-header"></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</header>


<main>
    <?php the_content(); ?>
</main>

<?php get_footer() ?>

