<?php get_header();
/* Template Name: Archive Template */
global $wp;
$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
    <!--START-FILTER-POPUP-->
    <div class="filter-popup">
        <div class="main-menu">
            <div class="sidebar-public gray-theme">
                <div class="btn btn-close">
                    بستن
                </div>
                <form action="" id="form1" method="get">
                    <div class="form-group">
                        <input class="search" name="keysearch" type="text" placeholder="جستجو کنید . . .">

                        <button form="form1" class="btn btn-search">
                            <i class="icon-search"></i>
                        </button>
                    </div>
                </form>
                <div class="box">
                    <div class="title">
                        <i class="icon-menu"></i>
                        دسته بندی
                    </div>
                    <div class="body">
                        <ul class="nav">
                            <?php $terms = get_terms(array(
                                'taxonomy' => 'category',

                            ));
                            foreach ($terms as $term) { ?>

                                <li class="nav-item">
                                    <a href="<?php echo add_query_arg('catid', $term->term_id, $url); ?>"
                                       class="nav-link">
                                        <i class="icon-left-chevron"></i>
                                        <?php echo $term->name ?>
                                    </a>
                                </li>
                                <?php
                            }
                            ?>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
        <div class="after"></div>
    </div>
    <!--END-FILTER-POPUP-->
<?php
get_template_part('partials/stones', 'head')
?>
    <main>
        <?php echo get_template_part('partials/bread', 'crumb') ?>

        <!--START-BLOG-ARCHIVE-->
        <div class="blog-section">
            <div class="container p-0 d-flex flex-wrap">
                <div class="col-xl-3 col-lg-4 d-lg-block d-none">
                    <div class="sidebar-public gray-theme">
                        <form action="" id="form1" method="get">
                            <div class="form-group">
                                <input class="search" name="keysearch" type="text" placeholder="جستجو کنید . . .">

                                <button form="form1" class="btn btn-search">
                                    <i class="icon-search"></i>
                                </button>
                            </div>
                        </form>
                        <div class="box">
                            <div class="title">
                                <i class="icon-menu"></i>
                                دسته بندی
                            </div>
                            <div class="body">
                                <ul class="nav">
                                    <?php $terms = get_terms(array(
                                        'taxonomy' => 'category',

                                    ));
                                    foreach ($terms as $term) { ?>

                                        <li class="nav-item">
                                            <a href="<?php echo add_query_arg('catid', $term->term_id, $url); ?>"
                                               class="nav-link">
                                                <i class="icon-left-chevron"></i>
                                                <?php echo $term->name ?>
                                            </a>
                                        </li>
                                        <?php
                                    }
                                    ?>


                                </ul>
                            </div>
                        </div>


                    </div>
                </div>
                <div class="col-xl-9 col-lg-8">
                    <div class="w-100 d-lg-none d-flex align-items-center justify-content-between">
                        <button class="btn btn-filter">
                            <i class="icon-search"></i>
                            جستجوی پیشرفته
                        </button>


                    </div>
                    <div class="blog-archive">
                        <?php
                        $args = array(
                            'posts_per_page' => 4,
                            'post_type' => 'post'
                        );
                        if (isset($_GET['tagid'])) {
                            $args['tag_id'] = $_GET['tagid'];
                        }
                        if (isset($_GET['catid'])) {

                            $args['category__in'] = $_GET['catid'];

                        }
                        if (isset($_GET['pg'])) {
                            $offset = ($_GET['pg'] - 1) * 4;
                            $args['offset'] = $offset;

                        }
                        if (isset($_GET['keysearch'])) {
                            $args['s'] = $_GET['keysearch'];

                        }


                        $the_query = new WP_Query($args);


                        if ($the_query->have_posts()) {

                            while ($the_query->have_posts()) {
                                $the_query->the_post();
                                $value = get_post_meta(get_the_ID(), 'read_min', true);
                                $postthumbid = get_post_thumbnail_id();

                                $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
                                ?>
                                <div class="item">
                                    <div class="image" style="background-image: url(<?php echo $postthumburl ?>)">

                                        <article>
                                            <div class="d-flex align-items-center">
                                                <?php if (!empty($value)) { ?>
                                                    <span class="time">
                                                        زمان مطالعه<?php echo ' ' . $value . ' ' ?> دقیقه
                                                    </span>
                                                <?php } ?>
                                                <ul class="nav">
                                                    <li class="nav-item">
                                                        <i class="icon-chat"></i>
                                                        <?php echo get_comments_number() ?>
                                                        نظر
                                                    </li>
                                                </ul>
                                            </div>
                                            <span class="title">
<a href="<?php echo get_the_permalink() ?>">
                                             <?php echo get_the_title() ?>
    </a>
                                           </span>
                                            <span class="subtitle">
                                                  <?php $terms = get_the_terms(get_the_ID(), 'category');

                                                  $i = 1; ?>

                                                <?php foreach ($terms as $term) {

                                                    if ($i !== 1) {
                                                        echo ' / ';
                                                    }
                                                    echo " دسته بندی ";
                                                    echo $term->name;
                                                    $i++;
                                                } ?>
                                             / منتشر شده در تاریخ
                                            <?php echo get_the_date() ?>

                                            </span>
                                            <a href="<?php echo get_permalink() ?>" class="more">
                                                مشاهده جزئیات بیشتر >>
                                            </a>
                                        </article>
                                    </div>
                                </div>
                                <?php
                            }

                        } else {
                            echo "no post";
                        }

                        wp_reset_postdata();
                        $all_post = $the_query->found_posts;
                        $pagging = $all_post / 4;
                        $peges = ceil($pagging);

                        ?>

                    </div>


                    <ul class="nav nav-pagination">
                        <?php for ($i = 1; $i <= $peges; $i++) {
                            ?>
                            <li class="nav-item <?php
                            if (isset($_GET['pg'])) {
                                if ($_GET['pg'] == $i) {
                                    echo "active";
                                }
                            } elseif ($i == 1) {
                                echo "active";
                            }
                            ?>
">
                                <a href="<?php echo add_query_arg('pg', $i, $url); ?>" class="nav-link">
                                    <?php echo $i ?>
                                </a>
                            </li>
                            <?php
                        } ?>

                    </ul>
                </div>
            </div>
        </div>
        <!--END-BLOG-ARCHIVE-->
    </main>

<?php get_footer() ?>