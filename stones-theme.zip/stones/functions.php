<?php
if (!function_exists('mytheme_register_nav_menu')) {

    function mytheme_register_nav_menu()
    {
        register_nav_menus(array(
            'primary_menu' => __('Primary Menu', 'text_domain'),
            'mega_menu' => __('mega Menu', 'text_domain'),
            'mega_menu_two' => __('mega Menu Two', 'text_domain'),
            'top_bar' => __('Top Bar Menu', 'text_domain'),
            'footer_menu' => __('Footer Menu', 'text_domain'),
        ));
    }

    add_action('after_setup_theme', 'mytheme_register_nav_menu', 0);
}
function so_37823371_menu_item_class($classes, $item, $args)
{

    $classes[] = 'nav-item';

    return $classes;
}

function wpse156165_menu_add_class($atts, $item, $args)
{
    $class = 'nav-link'; // or something based on $item
    $atts['class'] = $class;
    return $atts;
}

add_filter('nav_menu_css_class', 'so_37823371_menu_item_class', 10, 3);
add_filter('nav_menu_link_attributes', 'wpse156165_menu_add_class', 10, 3);
add_theme_support('post-thumbnails');
function wporg_add_custom_box()
{
    $screens = ['post'];
    foreach ($screens as $screen) {
        add_meta_box(
            'read_time',                 // Unique ID
            'زمان مطالعه',      // Box title
            'read_time_html',  // Content callback, must be of type callable
            $screen,
            'side'
        );
    }
}

function read_time_html($post)
{
    $value = get_post_meta($post->ID, 'read_min', true);
    ?>
    <label for="wporg_field">زمان مطالعه</label>
    <input type="number" name="read_min" class="form-control" value="<?php echo $value ?>">
    <?php
}

function wporg_save_postdata($post_id)
{
    if (array_key_exists('read_min', $_POST)) {
        update_post_meta(
            $post_id,
            'read_min',
            $_POST['read_min']
        );
    }
}

add_action('save_post', 'wporg_save_postdata');
add_action('add_meta_boxes', 'wporg_add_custom_box');
add_filter('comment_form_fields', 'mo_comment_fields_custom_order');
function mo_comment_fields_custom_order($fields)
{
    $comment_field = $fields['comment'];

    unset($fields['cookies']);

    unset($fields['comment']);
    $fields['comment'] = $comment_field;
    return $fields;
}

add_action('cat_add_form_fields', 'misha_add_term_fields');

function misha_add_term_fields($taxonomy)
{

    echo '<div class="form-field">
	<label for="misha-text">کلاس ایکن</label>
	<input type="text" name="misha-text" id="misha-text" />
	</div>';

}

add_action('cat_edit_form_fields', 'misha_edit_term_fields', 10, 2);

function misha_edit_term_fields($term, $taxonomy)
{

    $value = get_term_meta($term->term_id, 'misha-text', true);

    echo '<tr class="form-field">
	<th>
		<label for="misha-text">کلاس ایکن</label>
	</th>
	<td>
		<input name="misha-text" id="misha-text" type="text" value="' . esc_attr($value) . '" />
	</td>
	</tr>';

}

add_action('created_cat', 'misha_save_term_fields');
add_action('edited_cat', 'misha_save_term_fields');

function misha_save_term_fields($term_id)
{

    update_term_meta(
        $term_id,
        'misha-text',
        sanitize_text_field($_POST['misha-text'])
    );

}

add_filter('simple_register_taxonomy_settings', 'misha_fields');

function misha_fields($fields)
{

    $fields[] = array(
        'id' => 'mishatest',
        'taxonomy' => array('cat'),
        'fields' => array(
            array(
                'id' => 'misha-text',
                'label' => 'Text Field',
                'type' => 'text',
            ),
        )
    );

    return $fields;

}

function mytheme_add_woocommerce_support()
{
    add_theme_support('woocommerce');
}

add_action('after_setup_theme', 'mytheme_add_woocommerce_support');
add_filter('show_admin_bar', 'my_function_admin_bar');
function my_function_admin_bar($show_admin_bar)
{
    return (current_user_can('administrator')) ? $show_admin_bar : false;
}

require_once get_template_directory() . '/inc/posttype-texonomy.php';
require_once get_template_directory() . '/inc/product-texonomy.php';
require_once get_template_directory() . '/inc/product-postmeta.php';
require_once get_template_directory() . '/inc/ajax.php';
require_once get_template_directory() . '/inc/admin-menu.php';


add_filter('woocommerce_checkout_fields', 'quadlayers_remove_checkout_fields');

function quadlayers_remove_checkout_fields($fields)
{

    unset($fields['billing']['billing_company']);

    return $fields;

}

add_theme_support('title-tag');
add_filter('wp_title', 'wpdocs_hack_wp_title_for_home');

/**
 * Customize the title for the home page, if one is not set.
 *
 * @param string $title The original title.
 * @return string The title to use.
 */
function wpdocs_hack_wp_title_for_home($title)
{
    if (empty($title) && (is_home() || is_front_page())) {
        $title = 'صفحه ی نخست';
    }
    return $title;
}

function DV_deactive_jetpack()
{
    wp_dequeue_script('devicepx');
    wp_dequeue_script('woo-tracks');
}

add_action('admin_enqueue_scripts', 'DV_deactive_jetpack');

add_filter('woocommerce_default_address_fields', 'njengah_rename_state_province', 9999);

function njengah_rename_state_province($fields)
{

    $fields['state']['label'] = 'شهرستان';
    $fields['country']['label'] = 'کشور';


    return $fields;

}

add_filter('woocommerce_checkout_fields', 'quadlayers_remove_checkout_fields2');

function quadlayers_remove_checkout_fields2($fields)
{

    unset($fields['billing']['billing_address_2']);
    unset($fields['shipping']['shipping_address_2']);
    unset($fields['shipping']['shipping_company']);

    return $fields;

}

function ShowOneError($fields, $errors)
{

    // if their is any validation errors

    if (!empty($errors->get_error_codes())) {

        // remove all of Error msg

        foreach ($errors->get_error_codes() as $code) {

            $errors->remove($code);

        }

        // our custom Error msg

        $errors->add('validation', 'لطفا ورودی ها رو چک کنید');

    }

}

add_action('woocommerce_after_checkout_validation', 'ShowOneError', 999, 2);
function commentCount()
{
    global $wpdb, $current_user;
    get_currentuserinfo();
    $userId = $current_user->ID;

    $count = $wpdb->get_var('
             SELECT COUNT(comment_ID) 
             FROM ' . $wpdb->comments . ' 
             WHERE user_id = "' . $userId . '"');
    echo $count;
}

/*add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );*/


//global array to reposition the elements to display as you want (e.g. kept 'title' before 'first_name' )
$wdm_address_fields = array('country',

    'first_name',
    'last_name',

    'address_1',
    'city',
    'state',
    'postcode',
    'title',
    );

//global array only for extra fields
$wdm_ext_fields = array();


add_filter('woocommerce_default_address_fields', 'wdm_override_default_address_fields');

function wdm_override_default_address_fields($address_fields)
{

    $temp_fields = array();

    $address_fields['title'] = array(
        'label' => 'شماره همراه',
        'required' => true,
        'class' => array('form-row-wide'),
        'type' => 'text',

    );



    global $wdm_address_fields;

    foreach ($wdm_address_fields as $fky) {
        $temp_fields[$fky] = $address_fields[$fky];
    }

    $address_fields = $temp_fields;

    return $address_fields;
}


//add_filter('woocommerce_formatted_address_replacements', 'wdm_formatted_address_replacements', 99, 2);

function wdm_formatted_address_replacements($address, $args)
{

//    $address['{name}'] = $args['title'] . " " . $args['first_name'] . " " . $args['last_name']; //show title along with name
//    $address['{address_1}'] = $args['address_1'] . "\r\n" . $args['address_2']; //reposition to display as it should be
//    $address['{address_2}'] = $args['address_3'] . "\r\n" . $args['address_4']; //reposition to display as it should be
//
//    return $address;
}


add_filter('woocommerce_order_formatted_billing_address', 'wdm_update_formatted_billing_address', 99, 2);

function wdm_update_formatted_billing_address($address, $obj)
{

    global $wdm_address_fields;

    if (is_array($wdm_address_fields)) {

        foreach ($wdm_address_fields as $waf) {
            $address[$waf] = $obj->{'billing_' . $waf};
        }
    }

    return $address;
}

add_filter('woocommerce_order_formatted_shipping_address', 'wdm_update_formatted_shipping_address', 99, 2);

function wdm_update_formatted_shipping_address($address, $obj)
{

    global $wdm_address_fields;

    if (is_array($wdm_address_fields)) {

        foreach ($wdm_address_fields as $waf) {
            $address[$waf] = $obj->{'shipping_' . $waf};
        }
    }

    return $address;
}

add_filter('woocommerce_my_account_my_address_formatted_address', 'wdm_my_account_address_formatted_address', 99, 3);

function wdm_my_account_address_formatted_address($address, $customer_id, $name)
{

    global $wdm_address_fields;

    if (is_array($wdm_address_fields)) {

        foreach ($wdm_address_fields as $waf) {
            $address[$waf] = get_user_meta($customer_id, $name . '_' . $waf, true);
        }
    }

    return $address;
}

add_filter('woocommerce_admin_billing_fields', 'wdm_add_extra_customer_field');
add_filter('woocommerce_admin_shipping_fields', 'wdm_add_extra_customer_field');

function wdm_add_extra_customer_field($fields)
{

    //take back up of email and phone fields as they will be lost after repositioning
    $email = $fields['email'];
    $phone = $fields['phone'];

    $fields = wdm_override_default_address_fields($fields);

    //reassign email and phone fields
    $fields['email'] = $email;
    $fields['phone'] = $phone;

    global $wdm_ext_fields;

    if (is_array($wdm_ext_fields)) {

        foreach ($wdm_ext_fields as $wef) {
            $fields[$wef]['show'] = false; //hide the way they are display by default as we have now merged them within the address field
        }
    }

    return $fields;
}
