<?php

add_action('admin_menu', 'wpdocs_register_my_custom_submenu_page');

function wpdocs_register_my_custom_submenu_page()
{
    add_menu_page('My Custom Page', 'تنظیمات قالب', 'manage_options', 'my-top-level-slug');
    add_submenu_page('my-top-level-slug', 'تنظیمات اسلایدر صفحه نخست', 'تنظیمات اسلایدر صفحه نخست',
        'manage_options', 'my-top-level-slug', 'wpdocs_my_custom_submenu_page_callback');
    add_submenu_page('my-top-level-slug', 'تنظیمات فوتر', 'تنظیمات فوتر',
        'manage_options', 'my-secondary-slug', 'wpdocs_my_custom_submenu_page_callback_2');
}
require get_template_directory() .'/inc/call-back.php';
function wpdocs_my_custom_submenu_page_callback_3()
{

    global $option;


    if (isset($_POST['newsave'])) {
        update_option('baner-1', $_POST['baner-1']);
        update_option('baner-2', $_POST['baner-2']);
        update_option('baner-3', $_POST['baner-3']);
        update_option('baner-4', $_POST['baner-4']);
        update_option('baner-5', $_POST['baner-5']);
        update_option('pic-1', $_POST['pic-1']);
        update_option('pic-2', $_POST['pic-2']);
        update_option('pic-3', $_POST['pic-3']);
        update_option('pic-4', $_POST['pic-4']);
        update_option('pic-5', $_POST['pic-5']);
        update_option('tt-1', $_POST['tt-1']);
        update_option('tt-2', $_POST['tt-2']);
        update_option('tt-3', $_POST['tt-3']);
        update_option('tt-4', $_POST['tt-4']);
        update_option('tt-5', $_POST['tt-5']);
        update_option('st-1', $_POST['st-1']);
        update_option('st-2', $_POST['st-2']);
        update_option('st-3', $_POST['st-3']);
        update_option('st-4', $_POST['st-4']);
        update_option('st-5', $_POST['st-5']);
        update_option('alt-1-1', $_POST['alt-1-1']);
        update_option('alt-1-2', $_POST['alt-1-2']);

        update_option('alt-2-1', $_POST['alt-2-1']);
        update_option('alt-2-2', $_POST['alt-2-2']);


        update_option('alt-3-1', $_POST['alt-3-1']);
        update_option('alt-3-2', $_POST['alt-3-2']);


        update_option('alt-4-1', $_POST['alt-4-1']);
        update_option('alt-4-2', $_POST['alt-4-2']);


        update_option('alt-5-1', $_POST['alt-5-1']);
        update_option('alt-5-2', $_POST['alt-5-2']);


        update_option('l-1', $_POST['l-1']);
        update_option('l-2', $_POST['l-2']);
        update_option('l-3', $_POST['l-3']);
        update_option('l-4', $_POST['l-4']);
        update_option('l-5', $_POST['l-5']);
    }
    $baner_1 = get_option('baner-1', false);
    $baner_2 = get_option('baner-2', false);
    $baner_3 = get_option('baner-3', false);
    $baner_4 = get_option('baner-4', false);
    $baner_5 = get_option('baner-5', false);
    $pic_1 = get_option('pic-1', false);
    $pic_2 = get_option('pic-2', false);
    $pic_3 = get_option('pic-3', false);
    $pic_4 = get_option('pic-4', false);
    $pic_5 = get_option('pic-5', false);
    $tt_1 = get_option('tt-1', false);
    $tt_2 = get_option('tt-2', false);
    $tt_3 = get_option('tt-3', false);
    $tt_4 = get_option('tt-4', false);
    $tt_5 = get_option('tt-5', false);
    $st_1 = get_option('st-1', false);
    $st_2 = get_option('st-2', false);
    $st_3 = get_option('st-3', false);
    $st_4 = get_option('st-4', false);
    $st_5 = get_option('st-5', false);

    $alt_1_1 = get_option('alt-1-1', false);
    $alt_1_2 = get_option('alt-1-2', false);

    $alt_2_1 = get_option('alt-2-1', false);
    $alt_2_2 = get_option('alt-2-2', false);

    $alt_3_1 = get_option('alt-3-1', false);
    $alt_3_2 = get_option('alt-3-2', false);

    $alt_4_1 = get_option('alt-4-1', false);
    $alt_4_2 = get_option('alt-4-2', false);

    $alt_5_1 = get_option('alt-5-1', false);
    $alt_5_2 = get_option('alt-5-2', false);

    $l_1 = get_option('l-1', false);
    $l_2 = get_option('l-2', false);
    $l_3 = get_option('l-3', false);
    $l_4 = get_option('l-4', false);
    $l_5 = get_option('l-5', false);
    ?>
    <div style="margin-left: 20px;">
        <form action="" method="post">


            <h2 style="margin-bottom: 5px; margin-top: 35px;">اسلایدر اول</h2>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">

                <label for="">بنر محصول
                    :</label>
                <br>
                <input type="text" name="baner-1" style="width: 100%;"
                       value="<?php echo $baner_1 ?>">

            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%" name="alt-1-1" value="<?php echo $alt_1_1 ?>">
            </p>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول
                    :</label>
                <input type="text" name="pic-1" style="width: 100%;" value="<?php echo $pic_1 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" name="alt-1-2" value="<?php echo $alt_1_2 ?>">
            </p>
            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text" style="width: 100%;" name="l-1" value="<?php echo $l_1 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان
                    :</label>
                <input type="text" style="width: 100%;" name="tt-1" value="<?php echo $tt_1 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">
                    زیر عنوان
                    :</label>
                <input type="text" style="width: 100%;" name="st-1" value="<?php echo $st_1 ?>">

            </p>
            <hr>
            <h2 style="margin-bottom: 5px; margin-top: 15px;">اسلایدر دوم</h2>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">بنر محصول</label>
                <input type="text" style="width: 100%;" name="baner-2" value="<?php echo $baner_2 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-2-1" value="<?php echo $alt_2_1 ?>">
            </p>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول</label>
                <input type="text" style="width: 100%;" name="pic-2" value="<?php echo $pic_2 ?>">
            </p>

            <p style="width: calc(15% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-2-2" value="<?php echo $alt_2_2 ?>">
            </p>
            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text" style="width: 100%;" name="l-2" value="<?php echo $l_2 ?>">
            </p>

            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان</label>
                <input type="text" style="width: 100%;" name="tt-2" value="<?php echo $tt_2 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">زیر عنوان</label>
                <input type="text" style="width: 100%;" name="st-2" value="<?php echo $st_2 ?>">
            </p>


            <hr>
            <h2 style="margin-bottom: 5px; margin-top: 15px;">اسلایدر سوم</h2>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">بنر محصول</label>
                <input type="text" style="width: 100%;" name="baner-3" value="<?php echo $baner_3 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-3-1" value="<?php echo $alt_3_1 ?>">
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول</label>
                <input type="text" style="width: 100%;" name="pic-3" value="<?php echo $pic_3 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-3-2" value="<?php echo $alt_3_2 ?>">
            </p>
            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text" style="width: 100%;" name="l-3" value="<?php echo $l_3 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان</label>
                <input type="text" style="width: 100%;" name="tt-3" value="<?php echo $tt_3 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">زیر عنوان</label>
                <input type="text" style="width: 100%;" name="st-3" value="<?php echo $st_3 ?>">
            </p>
            <hr>
            <h2 style="margin-bottom: 5px; margin-top: 15px;">اسلایدر چهارم</h2>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">بنر محصول</label>
                <input type="text" style="width: 100%;" name="baner-4" value="<?php echo $baner_4 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input style="width: 100%;" type="text" name="alt-4-1" value="<?php echo $alt_4_1 ?>">
            </p>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول</label>
                <input type="text" style="width: 100%;" name="pic-4" value="<?php echo $pic_4 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input style="width: 100%;" type="text" name="alt-4-2" value="<?php echo $alt_4_2 ?>">
            </p>
            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text" style="width: 100%;" name="l-4" value="<?php echo $l_4 ?>">
            </p>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان</label>
                <input style="width: 100%;" type="text" name="tt-4" value="<?php echo $tt_4 ?>">
            </p>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">زیر عنوان</label>
                <input style="width: 100%;" type="text" name="st-4" value="<?php echo $st_4 ?>">
            </p>
            <hr>


            <h2 style="margin-bottom: 5px; margin-top: 15px;">اسلایدر پنجم</h2>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">بنر محصول</label>
                <input type="text" style="width: 100%;" name="baner-5" value="<?php echo $baner_5 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-5-1" value="<?php echo $alt_5_1 ?>"></p>
            <p style="width: calc(35% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول</label>
                <input type="text" style="width: 100%;" name="pic-5" value="<?php echo $pic_5 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-5-2" value="<?php echo $alt_5_2 ?>">
            </p>
            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text"  style="width: 100%;" name="l-5" value="<?php echo $l_5 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان</label>
                <input type="text" style="width: 100%;" name="tt-5" value="<?php echo $tt_5 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">زیر عنوان</label>
                <input type="text" style="width: 100%;" name="st-5" value="<?php echo $st_5 ?>">
            </p>

            <hr>
            <input type="submit" class="w-100" value="ذخیره" name="newsave">
        </form>
    </div>

    <?php
}

function wpdocs_my_custom_submenu_page_callback_2()
{
    global $option;
    if (isset($_POST['newsave'])) {
        update_option('p-num', $_POST['p-num']);
        update_option('f_eml', $_POST['f_eml']);
        update_option('face_book', $_POST['face_book']);
        update_option('insta', $_POST['insta']);
        update_option('twiter', $_POST['twiter']);
        update_option('enmad_1', $_POST['enmad_1']);
        update_option('enmad_2', $_POST['enmad_2']);

    }
    $p_num = get_option('p-num', false);
    $f_eml = get_option('f_eml', false);
    $face_book = get_option('face_book', false);
    $insta = get_option('insta', false);
    $twiter = get_option('twiter', false);
    $enmad_1 = get_option('enmad_1', false);
    $enmad_2 = get_option('enmad_2', false);

    ?>
    <form action="" method="post" style="margin-top: 20px">

        <label for="">شماره پشتیبانی :</label>
        <input type="text" name="p-num" value="<?php echo $p_num ?>">
        <br>
        <br>

        <label for="">ایمیل :</label>
        <input type="text" name="f_eml" value="<?php echo $f_eml ?>">
        <br>
        <br>

        <label for="">لینک فیسبوک :</label>
        <input type="text" name="face_book" value="<?php echo $face_book ?>">
        <br>
        <br>

        <label for="">لینک اینستا :</label>
        <input type="text" name="insta" value="<?php echo $insta ?>">
        <br>
        <br>

        <label for="">لینک تویتر :</label>
        <input type="text" name="twiter" value="<?php echo $twiter ?>">
        <br>
        <br>
        <label for="">لینک نماد اعتماد :</label>
        <input type="text" name="enmad_1" value="<?php echo $enmad_1 ?>">
        <br>
        <br>
        <label for="">لینک نماد اعتماد :</label>
        <input type="text" name="enmad_2" value="<?php echo $enmad_2 ?>">
        <br>
        <br>
        <input type="submit" class="w-100" value="ذخیره" name="newsave">
    </form>
    <?php
}

add_action('admin_menu', 'wpdocs_unsub_add_pages');


function wpdocs_unsub_add_pages()
{
    add_menu_page(
        'price setting',
        'تظیمات قیمت',
        'manage_options',
        'price_setting',
        'price_setting',
        ''
    );
}

function price_setting()
{
    global $option;
    if (isset($_POST['updte'])) {
        update_option('dolar', $_POST['dolar']);
        update_option('gram', $_POST['gram']);
        $args = array('post_type' => 'product');
        $the_query = new WP_Query($args);
        if ($the_query->have_posts()) {

            while ($the_query->have_posts()) {
                $the_query->the_post();
                $id = get_the_ID();
                $grami = get_post_meta($id, 'gram', true);
                $dolari = get_post_meta($id, 'dolar', true);
                $off = get_post_meta($id, 'off', true);
                if (!empty($grami)) {
                    $pricing = intval($grami) * intval($_POST['gram']);
                    update_post_meta($id, '_regular_price', $pricing);
                    update_post_meta($id, '_price', $pricing);

                    if (isset($off) && !empty($off) && $off!== 0 ) {
                        $offpricing = $pricing - (($pricing) * $off / 100);
                        update_post_meta($id, '_sale_price', $offpricing);
                        update_post_meta($id, '_price', $offpricing);
                    } else {

                        delete_post_meta($id, '_sale_price');

                    }

                }
                if (!empty($dolari)) {
                    $pricing = intval($dolari) * intval($_POST['dolar']);

                    update_post_meta($id, '_regular_price', $pricing);

                    update_post_meta($id, '_price', $pricing);

                    if (isset($off) && !empty($off) && $off!== 0 ) {
                        $offpricing = $pricing - (($pricing) * $off / 100);
                        update_post_meta($id, '_sale_price', $offpricing);
                        update_post_meta($id, '_price', $offpricing);
                    } else {

                        delete_post_meta($id, '_sale_price');

                    }
                }

            }
        } else {

        }

        wp_reset_postdata();
    }
    $dolar = get_option('dolar', false);
    $gram = get_option('gram', false);


    wp_reset_postdata();
    ?>
    <div>
        <form action="" method="post">
            <p>
                <label for="">قیمت دلار</label>
                <input type="text" name="dolar" value="<?php echo $dolar ?>">
            </p>
            <p>
                <label for="">قیمت هر گرم</label>
                <input type="text" name="gram" value="<?php echo $gram ?>">
            </p>
            <input type="submit" name="updte" value="بروز رسانی">
        </form>
    </div>

    <?php
}




