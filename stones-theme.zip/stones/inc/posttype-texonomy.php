<?php

add_action('init', 'custom_post_type', 0);
add_action('init', 'create_subjects_hierarchical_taxonomy', 0);
function create_subjects_hierarchical_taxonomy()
{
    $labels = array(
        'name' => "دسته بندی",
        'singular_name' => "دسته بندی",
        'search_items' => "جستجو",
        'all_items' => "همه",
        'parent_item' => "والد",
        'parent_item_colon' => "والد",
        'edit_item' => "ویرایش",
        'update_item' => "بروزرسانی",
        'add_new_item' => "افزودن",
        'new_item_name' => "افزودن",
        'menu_name' => "دسته بندی",
    );
    register_taxonomy('cat', array('faq'), array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'cat'),
    ));
}

function custom_post_type()
{


    $labels = array(
        'name' => 'پرسش پاسخ',
        'singular_name' => 'پرسش پاسخ',
        'menu_name' => 'سوالات متداول',
        'parent_item_colon' => 'والد',
        'all_items' => 'همه',
        'view_item' => 'مشاهده',
        'add_new_item' => 'افزودن',
        'add_new' => 'افزودن',
        'edit_item' => 'ویرایش',
        'update_item' => 'بروزرسانی',
        'search_items' => 'جستجو',
        'not_found' => 'یافت نشد',
        'not_found_in_trash' => 'یافت نشد',
    );


    $args = array(
        'label' => 'faq',
        'description' => '',
        'labels' => $labels,

        'supports' => array('title', 'editor'),

        'taxonomies' => array('genres'),

        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => true,

    );


    register_post_type('faq', $args);

}
