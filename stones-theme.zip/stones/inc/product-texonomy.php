<?php

function ayar_texonomy()
{
    register_taxonomy(
        'ayar',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
        'product',             // post type name
        array(
            'hierarchical' => false,
            'label' => 'عیار', // display name
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'ayar',    // This controls the base slug that will display before each term
                'with_front' => false  // Don't display the category base before
            )
        )
    );
}

add_action('init', 'ayar_texonomy');




function calection_taxonomy()
{
    register_taxonomy(
        'colection',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
        'product',             // post type name
        array(
            'hierarchical' => false,
            'label' => 'کالکشن', // display name
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'colection',    // This controls the base slug that will display before each term
                'with_front' => false  // Don't display the category base before
            )
        )
    );
}

add_action('init', 'calection_taxonomy');




