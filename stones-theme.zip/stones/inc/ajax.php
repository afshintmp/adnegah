<?php

add_action('wp_enqueue_scripts', 'my_enqueue');
function my_enqueue($hook)
{

    wp_enqueue_script('ajax-script', get_template_directory_uri() . '/assets/js/ajax-script.js', array('jquery'));

    wp_localize_script('ajax-script', 'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php')));
}


add_action('wp_ajax_archivajax', 'archivajax_1');
add_action('wp_ajax_nopriv_archivajax', 'archivajax_1');
function archivajax_1()
{
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 9,
    );
    if (isset($_POST['page'])) {
        $offset = (intval($_POST['page']) - 1) * 9;
        $args['offset'] = $offset;
    }
    if (!empty($_POST['checkedgram'])) {
        $args['meta_query'] = array(
            'relation' => 'OR',
        );


        if (in_array('c-1', $_POST['checkedgram'])) {
            $args['meta_query'][] = array(
                'key' => 'gram',
                'value' => array(1, 2),
                'type' => 'numeric',
                'compare' => 'BETWEEN',
            );
        }
        if (in_array('c-2', $_POST['checkedgram'])) {
            $args['meta_query'][] = array(
                'key' => 'gram',
                'value' => array(2, 4),
                'type' => 'numeric',
                'compare' => 'BETWEEN',
            );
        }
        if (in_array('c-3', $_POST['checkedgram'])) {
            $args['meta_query'][] = array(
                'key' => 'gram',
                'value' => array(4, 6),
                'type' => 'numeric',
                'compare' => 'BETWEEN',
            );
        }
        if (in_array('c-4', $_POST['checkedgram'])) {
            $args['meta_query'][] = array(
                'key' => 'gram',
                'value' => 6,
                'type' => 'numeric',
                'compare' => '>=',
            );
        }
    }
    if (!empty($_POST['checkedayar'])) {
        if (array_key_exists('tax_query', $args)) {
            $args['tax_query']['relation'] = 'AND';
        }
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'ayar',
                'field' => 'term_id',
                'terms' => $_POST['checkedayar'],
                'operator' => 'IN',
            ),
        );
    }
    if (!empty($_POST['checkedcat'])) {
        if (array_key_exists('tax_query', $args)) {
            $args['tax_query']['relation'] = 'AND';
        }
        $args['tax_query'][] =
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $_POST['checkedcat'],
                'operator' => 'IN',

            );
    }
    if (!empty($_POST['checkedcolect'])) {
        if (array_key_exists('tax_query', $args)) {
            $args['tax_query']['relation'] = 'AND';
        }
        $args['tax_query'][] =
            array(
                'taxonomy' => 'colection',
                'field' => 'term_id',
                'terms' => $_POST['checkedcolect'],
                'operator' => 'IN',

            );
    }
    if (!empty($_POST['keyword'])) {
        $args['s'] = $_POST['keyword'];
    }
    if ($_POST['sort'] !== 'nosort') {

        $args['meta_key'] = '_regular_price';
        $args['orderby'] = 'meta_value_num';
        $args['order'] = $_POST['sort'];

    }
    if (!empty($_POST['instock'])) {
        $args['meta_query'][] =
            array(
                'key' => '_stock_status',
                'value' => 'instock'
            );

    };
    $string = '';
    $the_query = new WP_Query($args);
    if ($the_query->have_posts()) :
        while ($the_query->have_posts()) : $the_query->the_post();
            $postthumbid = get_post_thumbnail_id();
            $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
            $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
            $newseles = get_post_meta(get_the_ID(), '_sale_price', true);
            ?>
            <div class="col-xl-4 col-md-6 prl-10px">
                <div class="item">
                    <?php
                    if (get_post_meta(get_the_ID(), '_stock_status', true) == 'outofstock' || empty(get_post_meta(get_the_ID(), '_regular_price', true))) {

                    } else {
                        ?>
                        <button class="add-cart"
                                onclick="ajaxaddtocart(<?php echo get_the_ID() ?>,this)">
                            <span class="spinner"></span>
                            <i class="icon-shopping-cart1"></i>
                        </button>
                    <?php } ?>
                    <?php if (!empty($newseles)) : ?>
                        <span class="label">
                                                 فـــروش ویـــژه
                                            </span>
                    <?php endif; ?>
                    <a href="<?php echo get_the_permalink() ?>">
                        <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                    </a>
                    <a href="<?php echo get_the_permalink() ?>" class="title">
                        <?php echo get_the_title() ?>
                    </a>
                    <span class="subtitle kalameh">


                                                <?php
                                                if (get_post_meta(get_the_ID(), '_stock_status', true) == 'outofstock') {
                                                    echo "ناموجود";
                                                } else {

                                                    if (!empty($newseles)) {

                                                        echo number_format($newseles, 0, ',', ',');
                                                        echo ' ' . get_woocommerce_currency_symbol();
                                                    } elseif (!empty(get_post_meta(get_the_ID(), '_regular_price', true))) {

                                                        echo number_format(get_post_meta(get_the_ID(), '_regular_price', true), 0, ',', ',');
                                                        echo ' ' . get_woocommerce_currency_symbol();
                                                    } else {
                                                        echo "ناموجود";
                                                    }

                                                }

                                                ?>

                                            </span>
                </div>
            </div>
        <?php

        endwhile;

        wp_reset_postdata();

    else :
        $string = '';
    endif;

    wp_die($string);
}

function archivajax()
{
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 9,
    );
    if (isset($_POST['page'])) {
        $offset = (intval($_POST['page']) - 1) * 9;
        $args['offset'] = $offset;
    }
    if (!empty($_POST['checkedgram'])) {
        $args['meta_query'] = array(
            'relation' => 'OR',
        );


        if (in_array('c-1', $_POST['checkedgram'])) {
            $args['meta_query'][] = array(
                'key' => 'gram',
                'value' => array(1, 2),
                'type' => 'numeric',
                'compare' => 'BETWEEN',
            );
        }
        if (in_array('c-2', $_POST['checkedgram'])) {
            $args['meta_query'][] = array(
                'key' => 'gram',
                'value' => array(2, 4),
                'type' => 'numeric',
                'compare' => 'BETWEEN',
            );
        }
        if (in_array('c-3', $_POST['checkedgram'])) {
            $args['meta_query'][] = array(
                'key' => 'gram',
                'value' => array(4, 6),
                'type' => 'numeric',
                'compare' => 'BETWEEN',
            );
        }
        if (in_array('c-4', $_POST['checkedgram'])) {
            $args['meta_query'][] = array(
                'key' => 'gram',
                'value' => 6,
                'type' => 'numeric',
                'compare' => '>=',
            );
        }
    }
    if (!empty($_POST['checkedayar'])) {
        if (array_key_exists('tax_query', $args)) {
            $args['tax_query']['relation'] = 'AND';
        }
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'ayar',
                'field' => 'term_id',
                'terms' => $_POST['checkedayar'],
                'operator' => 'IN',
            ),
        );
    }
    if (!empty($_POST['checkedcat'])) {
        if (array_key_exists('tax_query', $args)) {
            $args['tax_query']['relation'] = 'AND';
        }
        $args['tax_query'][] =
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $_POST['checkedcat'],
                'operator' => 'IN',

            );
    }
    if (!empty($_POST['checkedcolect'])) {
        if (array_key_exists('tax_query', $args)) {
            $args['tax_query']['relation'] = 'AND';
        }
        $args['tax_query'][] =
            array(
                'taxonomy' => 'colection',
                'field' => 'term_id',
                'terms' => $_POST['checkedcolect'],
                'operator' => 'IN',

            );
    }
    if (!empty($_POST['keyword'])) {
        $args['s'] = $_POST['keyword'];
    }
    if ($_POST['sort'] !== 'nosort') {

        $args['meta_key'] = '_regular_price';
        $args['orderby'] = 'meta_value_num';
        $args['order'] = $_POST['sort'];

    }
    if (!empty($_POST['instock'])) {
        $args['meta_query'][] =
            array(
                'key' => '_stock_status',
                'value' => 'instock'
            );

    };


    $string = '';
    $the_query = new WP_Query($args);
    if ($the_query->have_posts()) :
        while ($the_query->have_posts()) : $the_query->the_post();

            $postthumbid = get_post_thumbnail_id();
            $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
            $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
            $newseles = get_post_meta(get_the_ID(), '_sale_price', true);
            $string .= '<div class="col-xl-4 col-md-6 prl-10px">
                <div class="item">';
            if (get_post_meta(get_the_ID(), '_stock_status', true) == 'outofstock' || empty(get_post_meta(get_the_ID(), '_regular_price', true))) {
            } else {
                $string .= '    <button class="add-cart"
                                                        onclick="ajaxaddtocart(' . get_the_ID() . ' , this)">
                                                    <span class="spinner"></span>
                                                    <i class="icon-shopping-cart1"></i>
                                                </button>';
            }
            if (!empty($newseles)) :
                $string .= '
                        <span class="label">
                                                 فـــروش ویـــژه
                                            </span> ';
            endif;
            $string .= ' <a href="' . get_the_permalink() . '">
                        <img src="' . $postthumburl . '" alt="' . $image_alt . '">
                    </a>
                    <a href="' . get_the_permalink() . '" class="title">
                     ' . get_the_title() . '
                    </a>
                    <span class="subtitle kalameh">';
            if (get_post_meta(get_the_ID(), '_stock_status', true) == 'outofstock') {
                $string .= "ناموجود";
            } else {
               
                if (!empty($newseles)) {
                    $string .= number_format($newseles, 0, ',', ',');
                } else {
                    $string .= number_format(get_post_meta(get_the_ID(), '_regular_price', true), 0, ',', ',');
                }
                $string .= ' ' . get_woocommerce_currency_symbol();
            }

            $string .= ' </span>
            </div>
            </div>';


        endwhile;

        wp_reset_postdata();

    else :
        $string .= '';
    endif;

    wp_die($string);
}

add_action('wp_ajax_woocommerce_ajax_add_to_cart', 'woocommerce_ajax_add_to_cart');
add_action('wp_ajax_nopriv_woocommerce_ajax_add_to_cart', 'woocommerce_ajax_add_to_cart');

function woocommerce_ajax_add_to_cart()
{
    global $wpdb, $woocommerce;

    $product_id = apply_filters('woocommerce_add_to_cart_product_id', absint($_POST['product_id']));
    $quantity = empty($_POST['quantity']) ? 1 : wc_stock_amount($_POST['quantity']);
    $variation_id = absint($_POST['variation_id']);
    $passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);
    $product_status = get_post_status($product_id);


    if ($passed_validation && WC()->cart->add_to_cart($product_id, $quantity, $variation_id) && 'publish' === $product_status) {
        echo WC()->cart->get_cart_contents_count();

    } else {

        echo 0;
    }

    wp_die();
}


add_action('wp_ajax_searchajax', 'search_ajax');
add_action('wp_ajax_nopriv_searchajax', 'search_ajax');

function search_ajax()

{
    $keysearch = $_POST['keyword'];
    $args = array(
        'post_type' => array('post', 'product'),
        'posts_per_page' => 6 ,
        's' => $keysearch
    );
    $the_query = new WP_Query($args);


    if ($the_query->have_posts()) {

        while ($the_query->have_posts()) {
            $the_query->the_post();
            $postthumbid = get_post_thumbnail_id();
            $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
            $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
            $newseles = get_post_meta(get_the_ID(), '_price', true);
            ?>
            <li class="search-itt">
                <a href="<?php echo get_the_permalink() ?>">
                    <div class="tumb">
                        <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>"
                             style="width: 30px;height: 30px;">
                    </div>
                    <div class="tt">
                        <p><?php echo get_the_title() ?></p>
                    </div>
                    <?php if (!empty($newseles)) : ?>
                        <div class="pr">
                            قیمت :
                            <span><?php echo number_format($newseles, '0', ',', ',') ?></span>
                        </div>
                    <?php endif; ?>
                </a>
            </li>

            <?php
        }

    } else {

    }

    wp_reset_postdata();
    wp_die();
}
