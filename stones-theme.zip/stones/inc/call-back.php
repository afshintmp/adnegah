<?php
function wpdocs_my_custom_submenu_page_callback()
{

    global $option;
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');

    define("ME_URL", rtrim(WP_PLUGIN_URL,'/') . '/'.basename(dirname(__FILE__)) );
    define("ME_DIR", rtrim(dirname(__FILE__), '/'));

    if (isset($_POST['newsave'])) {
        update_option('baner-1', $_POST['baner-1']);
        update_option('baner-2', $_POST['baner-2']);
        update_option('baner-3', $_POST['baner-3']);
        update_option('baner-4', $_POST['baner-4']);
        update_option('baner-5', $_POST['baner-5']);
        update_option('pic-1', $_POST['pic-1']);
        update_option('pic-2', $_POST['pic-2']);
        update_option('pic-3', $_POST['pic-3']);
        update_option('pic-4', $_POST['pic-4']);
        update_option('pic-5', $_POST['pic-5']);
        update_option('tt-1', $_POST['tt-1']);
        update_option('tt-2', $_POST['tt-2']);
        update_option('tt-3', $_POST['tt-3']);
        update_option('tt-4', $_POST['tt-4']);
        update_option('tt-5', $_POST['tt-5']);
        update_option('st-1', $_POST['st-1']);
        update_option('st-2', $_POST['st-2']);
        update_option('st-3', $_POST['st-3']);
        update_option('st-4', $_POST['st-4']);
        update_option('st-5', $_POST['st-5']);
        update_option('alt-1-1', $_POST['alt-1-1']);
        update_option('alt-1-2', $_POST['alt-1-2']);

        update_option('alt-2-1', $_POST['alt-2-1']);
        update_option('alt-2-2', $_POST['alt-2-2']);


        update_option('alt-3-1', $_POST['alt-3-1']);
        update_option('alt-3-2', $_POST['alt-3-2']);


        update_option('alt-4-1', $_POST['alt-4-1']);
        update_option('alt-4-2', $_POST['alt-4-2']);


        update_option('alt-5-1', $_POST['alt-5-1']);
        update_option('alt-5-2', $_POST['alt-5-2']);


        update_option('l-1', $_POST['l-1']);
        update_option('l-2', $_POST['l-2']);
        update_option('l-3', $_POST['l-3']);
        update_option('l-4', $_POST['l-4']);
        update_option('l-5', $_POST['l-5']);
    }
    $baner_1 = get_option('baner-1', false);
    $baner_2 = get_option('baner-2', false);
    $baner_3 = get_option('baner-3', false);
    $baner_4 = get_option('baner-4', false);
    $baner_5 = get_option('baner-5', false);
    $pic_1 = get_option('pic-1', false);
    $pic_2 = get_option('pic-2', false);
    $pic_3 = get_option('pic-3', false);
    $pic_4 = get_option('pic-4', false);
    $pic_5 = get_option('pic-5', false);
    $tt_1 = get_option('tt-1', false);
    $tt_2 = get_option('tt-2', false);
    $tt_3 = get_option('tt-3', false);
    $tt_4 = get_option('tt-4', false);
    $tt_5 = get_option('tt-5', false);
    $st_1 = get_option('st-1', false);
    $st_2 = get_option('st-2', false);
    $st_3 = get_option('st-3', false);
    $st_4 = get_option('st-4', false);
    $st_5 = get_option('st-5', false);

    $alt_1_1 = get_option('alt-1-1', false);
    $alt_1_2 = get_option('alt-1-2', false);

    $alt_2_1 = get_option('alt-2-1', false);
    $alt_2_2 = get_option('alt-2-2', false);

    $alt_3_1 = get_option('alt-3-1', false);
    $alt_3_2 = get_option('alt-3-2', false);

    $alt_4_1 = get_option('alt-4-1', false);
    $alt_4_2 = get_option('alt-4-2', false);

    $alt_5_1 = get_option('alt-5-1', false);
    $alt_5_2 = get_option('alt-5-2', false);

    $l_1 = get_option('l-1', false);
    $l_2 = get_option('l-2', false);
    $l_3 = get_option('l-3', false);
    $l_4 = get_option('l-4', false);
    $l_5 = get_option('l-5', false);
?>

    <div style="margin-left: 20px;">
        <form action="" method="post">


            <h2 style="margin-bottom: 5px; margin-top: 35px;">اسلایدر اول</h2>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">

                <label for="">بنر محصول
                    :</label>
                <br>
                <input type="text" name="baner-1" style="width: 100%;"
                       value="<?php echo $baner_1 ?>">

            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%" name="alt-1-1" value="<?php echo $alt_1_1 ?>">
            </p>

            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <input id="upload_baner_button" type="button" value="اپلود بنر"/>
            </p>


            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول
                    :</label>
                <input type="text" name="pic-1" style="width: 100%;" value="<?php echo $pic_1 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" name="alt-1-2" value="<?php echo $alt_1_2 ?>">
            </p>



            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;margin-right: 5px; ">
                <input style="margin-right: 15px;" id="upload_img_button" type="button" value="اپلود عکس"/>
            </p>



            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text" style="width: 100%;" name="l-1" value="<?php echo $l_1 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان
                    :</label>
                <input type="text" style="width: 100%;" name="tt-1" value="<?php echo $tt_1 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">
                    زیر عنوان
                    :</label>
                <input type="text" style="width: 100%;" name="st-1" value="<?php echo $st_1 ?>">

            </p>
            <hr>
            <h2 style="margin-bottom: 5px; margin-top: 15px;">اسلایدر دوم</h2>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">بنر محصول</label>
                <input type="text" style="width: 100%;" name="baner-2" value="<?php echo $baner_2 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-2-1" value="<?php echo $alt_2_1 ?>">
            </p>


            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <input id="upload_baner_button_two" type="button" value="اپلود بنر"/>
            </p>

            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول</label>
                <input type="text" style="width: 100%;" name="pic-2" value="<?php echo $pic_2 ?>">
            </p>
            <p style="width: calc(15% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-2-2" value="<?php echo $alt_2_2 ?>">
            </p>


            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;margin-right: 5px; ">
                <input style="margin-right: 15px;" id="upload_img_button_two" type="button" value="اپلود عکس"/>
            </p>


            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text" style="width: 100%;" name="l-2" value="<?php echo $l_2 ?>">
            </p>

            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان</label>
                <input type="text" style="width: 100%;" name="tt-2" value="<?php echo $tt_2 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">زیر عنوان</label>
                <input type="text" style="width: 100%;" name="st-2" value="<?php echo $st_2 ?>">
            </p>


            <hr>
            <h2 style="margin-bottom: 5px; margin-top: 15px;">اسلایدر سوم</h2>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">بنر محصول</label>
                <input type="text" style="width: 100%;" name="baner-3" value="<?php echo $baner_3 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-3-1" value="<?php echo $alt_3_1 ?>">

            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;margin-right: 5px;">
                <input id="upload_baner_button_tree" type="button" value="اپلود بنر"/>
            </p>

            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول</label>
                <input type="text" style="width: 100%;" name="pic-3" value="<?php echo $pic_3 ?>">
            </p>


            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-3-2" value="<?php echo $alt_3_2 ?>">
            </p>

            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;margin-right: 5px; ">
                <input style="margin-right: 15px;" id="upload_img_button_tree" type="button" value="اپلود عکس"/>
            </p>



            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text" style="width: 100%;" name="l-3" value="<?php echo $l_3 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان</label>
                <input type="text" style="width: 100%;" name="tt-3" value="<?php echo $tt_3 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">زیر عنوان</label>
                <input type="text" style="width: 100%;" name="st-3" value="<?php echo $st_3 ?>">
            </p>
            <hr>
            <h2 style="margin-bottom: 5px; margin-top: 15px;">اسلایدر چهارم</h2>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">بنر محصول</label>
                <input type="text" style="width: 100%;" name="baner-4" value="<?php echo $baner_4 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input style="width: 100%;" type="text" name="alt-4-1" value="<?php echo $alt_4_1 ?>">
            </p>
            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;margin-right: 5px;">
                <input id="upload_baner_button_four" type="button" value="اپلود بنر"/>
            </p>



            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول</label>
                <input type="text" style="width: 100%;" name="pic-4" value="<?php echo $pic_4 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input style="width: 100%;" type="text" name="alt-4-2" value="<?php echo $alt_4_2 ?>">
            </p>
            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;margin-right: 5px; ">
                <input style="margin-right: 15px;" id="upload_img_button_four" type="button" value="اپلود عکس"/>
            </p>


            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text" style="width: 100%;" name="l-4" value="<?php echo $l_4 ?>">
            </p>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان</label>
                <input style="width: 100%;" type="text" name="tt-4" value="<?php echo $tt_4 ?>">
            </p>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">زیر عنوان</label>
                <input style="width: 100%;" type="text" name="st-4" value="<?php echo $st_4 ?>">
            </p>
            <hr>


            <h2 style="margin-bottom: 5px; margin-top: 15px;">اسلایدر پنجم</h2>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">بنر محصول</label>
                <input type="text" style="width: 100%;" name="baner-5" value="<?php echo $baner_5 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-5-1" value="<?php echo $alt_5_1 ?>"></p>
            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;margin-right: 5px;">
                <input id="upload_baner_button_five" type="button" value="اپلود بنر"/>
            </p>
            <p style="width: calc(25% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">عکس محصول</label>
                <input type="text" style="width: 100%;" name="pic-5" value="<?php echo $pic_5 ?>">
            </p>
            <p style="width: calc(15% - 5px)!important;display: inline-block;margin-bottom: 5px;">
                <label for="">متن جایگزین</label>
                <input type="text" style="width: 100%;" name="alt-5-2" value="<?php echo $alt_5_2 ?>">
            </p>
            <p style="width: calc(10% - 5px)!important;display: inline-block;margin-bottom: 5px;margin-right: 5px; ">
                <input style="margin-right: 15px;" id="upload_img_button_five" type="button" value="اپلود عکس"/>
            </p>


            <p style="width: calc(50% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">لینک الصاق
                    :</label>
                <input type="text"  style="width: 100%;" name="l-5" value="<?php echo $l_5 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">عنوان</label>
                <input type="text" style="width: 100%;" name="tt-5" value="<?php echo $tt_5 ?>">
            </p>
            <p style="width: calc(25% - 5px);display: inline-block;margin-bottom: 5px;">
                <label for="">زیر عنوان</label>
                <input type="text" style="width: 100%;" name="st-5" value="<?php echo $st_5 ?>">
            </p>

            <hr>
            <input type="submit" class="w-100" value="ذخیره" name="newsave">
        </form>
    </div>






    <script>
        jQuery(document).ready(function ($) {
            $('#upload_baner_button').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="baner-1"]').val(imgurl);
                    $('input[name="alt-1-1"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });
            $('#upload_img_button').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="pic-1"]').val(imgurl);
                    $('input[name="alt-1-2"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });
            $('#upload_baner_button_two').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="baner-2"]').val(imgurl);
                    $('input[name="alt-2-1"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });
            $('#upload_img_button_two').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="pic-2"]').val(imgurl);
                    $('input[name="alt-2-2"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });


            $('#upload_baner_button_tree').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="baner-3"]').val(imgurl);
                    $('input[name="alt-3-1"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });
            $('#upload_img_button_tree').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="pic-3"]').val(imgurl);
                    $('input[name="alt-3-2"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });

            $('#upload_baner_button_four').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="baner-4"]').val(imgurl);
                    $('input[name="alt-4-1"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });
            $('#upload_img_button_four').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="pic-4]').val(imgurl);
                    $('input[name="alt-4-2"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });

            $('#upload_baner_button_five').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="baner-5"]').val(imgurl);
                    $('input[name="alt-5-1"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });
            $('#upload_img_button_five').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('input[name="pic-5"]').val(imgurl);
                    $('input[name="alt-5-2"]').val(imgalt);
                    tb_remove();
                }

                return false;
            });

        });
    </script>
<?php
}