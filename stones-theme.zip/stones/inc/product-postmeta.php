<?php


function pricing($post)
{
    global $option;
    $gram = get_post_meta($post->ID, 'gram', true);
    $dolar = get_post_meta($post->ID, 'dolar', true);
    $off = get_post_meta($post->ID, 'off', true);
    $dolari = get_option('dolar', false);
    $grami = get_option('gram', false);
    ?>

    <div>
        <p>
            <label for="">قیمت دلار</label>
            <input type="text" value="<?php echo $dolari ?>" readonly>
        </p>
        <p>
            <label for="">قیمت گرمی</label>
            <input type="text" value="<?php echo $grami ?>" readonly>
        </p>
        <p>
            <label for="g">محصول گرمی</label>
            <input type="radio" id="g" name="myradio" value="g" <?php echo !empty($gram) ? 'checked' : "" ?>>

            <input type="text" id="gram" name="gram"
                <?php echo !empty($gram) ? 'value="' . $gram . '"' : "readonly" ?>>
        </p>
        <p>
            <label for="d">محصول دلاری</label>
            <input type="radio" id="d" name="myradio" value="d" <?php echo !empty($dolar) ? 'checked' : "" ?>>

            <input type="text" id="dolar"
                   name="dolar" <?php echo !empty($dolar) ? 'value="' . $dolar . '"' : "readonly" ?>>
        </p>
        <p>
            <label for="off">
                تخفیف محصول
                (درصد)
            </label>


            <input type="text" id="off"
                   name="off" value="<?php echo $off ?>">
        </p>

    </div>
    <script>
        jQuery("#g").on('click', function (e) {
            jQuery('#gram').val('').prop('readonly', false);
            jQuery('#dolar').val('').prop('readonly', true);

        })
    </script>
    <script>
        jQuery("#d").on('click', function (e) {

            jQuery('#gram').val('').prop('readonly', true);
            jQuery('#dolar').val('').prop('readonly', false);
        })
    </script>


    <?php

}

add_action('add_meta_boxes', function () {

    add_meta_box('pricing-id', 'قیمت', 'pricing', 'product', 'side', 'low');
});
add_action('save_post', function ($post_id) {
    global $option;

    $dolari = get_option('dolar', false);
    $grami = get_option('gram', false);
    if (isset($_POST['off']) && !empty($_POST['off']) && ((isset($_POST['gram']) && !empty($_POST['gram'])) || (isset($_POST['dolar']) && !empty($_POST['dolar'])))) {
        update_post_meta($post_id, 'off', $_POST['off']);
    } else {
        update_post_meta($post_id, 'off', '');
    }

    if (isset($_POST['gram']) && !empty($_POST['gram'])) {
        $c_gram = ($_POST['gram']);
        $pricing = ($grami) * $c_gram;
        update_post_meta($post_id, 'gram', $c_gram);

        update_post_meta($post_id, '_regular_price', $pricing);
        update_post_meta($post_id, '_price', $pricing);

        if (isset($_POST['off']) && !empty($_POST['off'])) {
            $offpricing = $pricing - (($pricing) * $_POST['off'] / 100);
            update_post_meta($post_id, '_sale_price', $offpricing);
            update_post_meta($post_id, '_price', $offpricing);
        } else {
            delete_post_meta($post_id, '_sale_price');
        }

    } else {
        update_post_meta($post_id, 'gram', '');
    }

    if (isset($_POST['dolar']) && !empty($_POST['dolar'])) {
        $c_dolar = ($_POST['dolar']);
        $pricing = ($dolari) * $c_dolar;
        update_post_meta($post_id, 'dolar', $c_dolar);
        update_post_meta($post_id, '_regular_price', $pricing);
        update_post_meta($post_id, '_price', $pricing);

        if (isset($_POST['off']) && !empty($_POST['off'])) {
            $offpricing = $pricing - (($pricing) * $_POST['off'] / 100);
            update_post_meta($post_id, '_sale_price', $offpricing);
            update_post_meta($post_id, '_price', $offpricing);
        } else {
            delete_post_meta($post_id, '_sale_price');
        }

    } else {
        update_post_meta($post_id, 'dolar', '');
    }


});


function cm_field_cb($post)
{
    $cs_meta_val = get_post_meta($post->ID);
    ?>
    <input type="text" name="cs-meta-name" style="width: 100%;"
           value="<?php if (isset ($cs_meta_val['cs-meta-name'])) echo $cs_meta_val['cs-meta-name'][0] ?>">
    <?php

}

add_action('save_post', function ($post_id) {

    if (isset($_POST['cs-meta-name'])) {

        update_post_meta($post_id, 'cs-meta-name', $_POST['cs-meta-name']);
    }

});
add_action('add_meta_boxes', function () {

    add_meta_box('csm-id', 'عنوان انگلیسی', 'cm_field_cb', 'product', 'normal', 'high');
});


function baner_pro($post)
{
    $cs_meta_val = get_post_meta($post->ID);
    ?>
    <label for="">بنر اول :</label>

    <input id="upload_image" type="text" size="36" name="upload_image"
           value="<?php if (isset ($cs_meta_val['banner_one'])) echo $cs_meta_val['banner_one'][0] ?>"/>

    <label for="">متن جایگزین اول :</label>
    <input type="text" id="img-alt" name="alt_one"
           value="<?php if (isset ($cs_meta_val['alt_one'])) echo $cs_meta_val['alt_one'][0] ?>">
    <input id="upload_image_button" type="button" value="Upload Image"/>

    <br>
    <br>
    <br>
    <hr>
    <hr>
    <label for="">بنر دوم :</label>

    <input id="upload_image_two" type="text" size="36" name="upload_image_two"
           value="<?php if (isset ($cs_meta_val['banner_two'])) echo $cs_meta_val['banner_two'][0] ?>"/>

    <label for="">متن جایگزین دوم :</label>
    <input type="text" id="img-alt-two" name="alt_two"
           value="<?php if (isset ($cs_meta_val['alt_two'])) echo $cs_meta_val['alt_two'][0] ?>">
    <input id="upload_image_button_two" type="button" value="Upload Image"/>

    <script>
        jQuery(document).ready(function ($) {

            $('#upload_image_button').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('#upload_image').val(imgurl);
                    $('#img-alt').val(imgalt);
                    tb_remove();
                }

                return false;
            });
            $('#upload_image_button_two').click(function () {

                formfield = $('#upload_image').attr('name');
                tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
                window.send_to_editor = function (html) {
                    imgurl = $(html).attr('src');
                    imgalt = $(html).attr('alt');

                    $('#upload_image_two').val(imgurl);
                    $('#img-alt-two').val(imgalt);
                    tb_remove();
                }

                return false;
            });
        });
    </script>
    <?php

}

add_action('save_post', function ($post_id) {

    if (isset($_POST['upload_image'])) {
        update_post_meta($post_id, 'banner_one', $_POST['upload_image']);
    }
    if (isset($_POST['alt_one'])) {
        update_post_meta($post_id, 'alt_one', $_POST['alt_one']);
    }
    if (isset($_POST['upload_image_two'])) {
        update_post_meta($post_id, 'banner_two', $_POST['upload_image_two']);
    }
    if (isset($_POST['alt_two'])) {
        update_post_meta($post_id, 'alt_two', $_POST['alt_two']);
    }

});
add_action('add_meta_boxes', function () {

    add_meta_box('banner-id', 'بنر محصولات', 'baner_pro', 'product', 'normal', 'high');
});

function atr_pro($post)
{
    $cs_meta_val = get_post_meta($post->ID);
    ?>
    <p style="width: (50% - 5px);display: inline-block;border-left: 2px solid #000;padding-left: 7px;margin: 0;padding-top: 15px;padding-bottom: 15px; ">
        <input type="text" name="tt_1" placeholder="عنوان"
               value="<?php if (isset ($cs_meta_val['tt_1'])) echo $cs_meta_val['tt_1'][0] ?>">


        <input type="text" name="st_1" placeholder="متن"
               value="<?php if (isset ($cs_meta_val['st_1'])) echo $cs_meta_val['st_1'][0] ?>">
    </p>
    <p style="width: (50% - 5px);display: inline-block;padding-right: 5px;margin: 0;padding-top: 15px;padding-bottom: 15px;">
        <input type="text" name="tt_2" placeholder="عنوان"
               value="<?php if (isset ($cs_meta_val['tt_2'])) echo $cs_meta_val['tt_2'][0] ?>">


        <input type="text" name="st_2" placeholder="متن"
               value="<?php if (isset ($cs_meta_val['st_2'])) echo $cs_meta_val['st_2'][0] ?>">
    </p>
    <p style="width: (50% - 5px);display: inline-block;border-left: 2px solid #000;padding-left: 7px;margin: 0;padding-top: 15px;padding-bottom: 15px;">
        <input type="text" name="tt_3" placeholder="عنوان"
               value="<?php if (isset ($cs_meta_val['tt_3'])) echo $cs_meta_val['tt_3'][0] ?>">


        <input type="text" name="st_3" placeholder="متن"
               value="<?php if (isset ($cs_meta_val['st_3'])) echo $cs_meta_val['st_3'][0] ?>">
    </p>
    <p style="width: (50% - 5px);display: inline-block;padding-right: 5px;margin: 0;padding-top: 15px;padding-bottom: 15px;">
        <input type="text" name="tt_4" placeholder="عنوان"
               value="<?php if (isset ($cs_meta_val['tt_4'])) echo $cs_meta_val['tt_4'][0] ?>">


        <input type="text" name="st_4" placeholder="متن"
               value="<?php if (isset ($cs_meta_val['st_4'])) echo $cs_meta_val['st_4'][0] ?>">
    </p>
    <p style="width: (50% - 5px);display: inline-block;border-left: 2px solid #000;padding-left: 7px;margin: 0;padding-top: 15px;padding-bottom: 15px;">
        <input type="text" name="tt_5" placeholder="عنوان"
               value="<?php if (isset ($cs_meta_val['tt_5'])) echo $cs_meta_val['tt_5'][0] ?>">


        <input type="text" name="st_5" placeholder="متن"
               value="<?php if (isset ($cs_meta_val['st_5'])) echo $cs_meta_val['st_5'][0] ?>">
    </p>
    <p style="width: (50% - 5px);display: inline-block;padding-right: 5px;margin: 0;padding-top: 15px;padding-bottom: 15px;">
        <input type="text" name="tt_6" placeholder="عنوان"
               value="<?php if (isset ($cs_meta_val['tt_6'])) echo $cs_meta_val['tt_6'][0] ?>">


        <input type="text" name="st_6" placeholder="متن"
               value="<?php if (isset ($cs_meta_val['st_6'])) echo $cs_meta_val['st_6'][0] ?>">
    </p>
    <?php
}

add_action('save_post', function ($post_id) {

    if (isset($_POST['tt_1'])) {
        update_post_meta($post_id, 'tt_1', $_POST['tt_1']);
        update_post_meta($post_id, 'st_1', $_POST['st_1']);
    }
    if (isset($_POST['tt_2'])) {
        update_post_meta($post_id, 'tt_2', $_POST['tt_2']);
        update_post_meta($post_id, 'st_2', $_POST['st_2']);
    }
    if (isset($_POST['tt_3'])) {
        update_post_meta($post_id, 'tt_3', $_POST['tt_3']);
        update_post_meta($post_id, 'st_3', $_POST['st_3']);
    }
    if (isset($_POST['tt_4'])) {
        update_post_meta($post_id, 'tt_4', $_POST['tt_4']);
        update_post_meta($post_id, 'st_4', $_POST['st_4']);
    }
    if (isset($_POST['tt_5'])) {
        update_post_meta($post_id, 'tt_5', $_POST['tt_5']);
        update_post_meta($post_id, 'st_5', $_POST['st_5']);
    }
    if (isset($_POST['tt_6'])) {
        update_post_meta($post_id, 'tt_6', $_POST['tt_6']);
        update_post_meta($post_id, 'st_6', $_POST['st_6']);
    }
});
add_action('add_meta_boxes', function () {

    add_meta_box('peoductatr', 'ویژگی محصول', 'atr_pro', 'product', 'normal', 'high');
});


