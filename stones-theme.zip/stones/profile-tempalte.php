<?php
/* Template Name: Profile Template */
if (get_current_user_id()){

}else{
   wp_redirect(get_home_url() .'/login');
}
get_header();
get_template_part('partials/profile', 'head');
?>



<main>
  <?php the_content(); ?>
</main>
<?php
get_footer('profile');
?>




































































































