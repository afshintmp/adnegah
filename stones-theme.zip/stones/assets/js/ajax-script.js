function getchecked() {
    setTimeout(function () {
        var checkedgram = [];
        var checkedayar = [];
        var checkedcat = [];
        var checkedcolect = [];
        sort = jQuery('.sortselect:checked').val()
        instock = jQuery('.instock:checked').val()
        keyword = jQuery('#keyworddec').val()

        jQuery('.gramset:checked').each(function () {
            checkedgram.push(jQuery(this).val());
        });
        jQuery('.colectset:checked').each(function () {
            checkedcolect.push(jQuery(this).val());
        });
        jQuery('.ayarset:checked').each(function () {
            checkedayar.push(jQuery(this).val());
        });
        jQuery('.catset:checked').each(function () {
            checkedcat.push(jQuery(this).val());
        });


        jQuery.ajax({
            type: "POST",
            // dataType : "json",
            url: ajax_object.ajax_url,
            data: {
                action: "archivajax",
                checkedgram: checkedgram,
                checkedayar: checkedayar,
                checkedcat: checkedcat,
                checkedcolect: checkedcolect,
                keyword: keyword,
                sort: sort,
                instock: instock
            },
            success: function (responce) {   // success callback function
                jQuery('#ajax-inner').html(responce)
                jQuery('.nav-pagination>.nav-item').removeClass('active')
                jQuery('.frist').addClass('active')
            },
            error: function (jqXhr, textStatus, errorMessage) { // error callback

            }
        });


    }, 100);

}

function getcheckedM() {
    setTimeout(function () {
        var checkedgram = [];
        var checkedayar = [];
        var checkedcat = [];
        var checkedcolect = [];
        sort = jQuery('.sortselect:checked').val()
        instock = jQuery('.instock:checked').val()
        keyword = jQuery('#keyword').val()

        jQuery('.gramsetm:checked').each(function () {
            checkedgram.push(jQuery(this).val());
        });
        jQuery('.colectsetm:checked').each(function () {
            checkedcolect.push(jQuery(this).val());
        });
        jQuery('.ayarsetm:checked').each(function () {
            checkedayar.push(jQuery(this).val());
        });
        jQuery('.catsetm:checked').each(function () {
            checkedcat.push(jQuery(this).val());
        });


        jQuery.ajax({
            type: "POST",
            // dataType : "json",
            url: ajax_object.ajax_url,
            data: {
                action: "archivajax",
                checkedgram: checkedgram,
                checkedayar: checkedayar,
                checkedcat: checkedcat,
                checkedcolect: checkedcolect,
                keyword: keyword,
                sort: sort,
                instock: instock
            },
            success: function (responce) {   // success callback function
                jQuery('#ajax-inner').html(responce)
                jQuery('.nav-pagination>.nav-item').removeClass('active')
                jQuery('.frist').addClass('active')
            },
            error: function (jqXhr, textStatus, errorMessage) { // error callback

            }
        });


    }, 100);

}

function pageset(eve) {
    pagemy = jQuery(eve).attr('data-page');
    var checkedgram = [];
    var checkedayar = [];
    var checkedcat = [];
    var checkedcolect = [];

    keyword = jQuery('#keyword').val()
    sort = jQuery('.sortselect:checked').val()
    jQuery('.gramset:checked').each(function () {
        checkedgram.push(jQuery(this).val());
    });
    jQuery('.colectset:checked').each(function () {
        checkedcolect.push(jQuery(this).val());
    });
    jQuery('.ayarset:checked').each(function () {
        checkedayar.push(jQuery(this).val());
    });
    jQuery('.catset:checked').each(function () {
        checkedcat.push(jQuery(this).val());
    });
    jQuery.ajax({
        type: "POST",
        // dataType : "json",
        url: ajax_object.ajax_url,
        data: {
            action: "archivajax",
            checkedgram: checkedgram,
            checkedayar: checkedayar,
            checkedcat: checkedcat,
            checkedcolect: checkedcolect,
            page: pagemy,
            keyword: keyword,
            sort: sort

        },
        success: function (responce) {   // success callback function
            jQuery('#ajax-inner').html(responce)
            jQuery('.nav-pagination>.nav-item').removeClass('active')
            jQuery(eve).parent().addClass('active')
        },
        error: function (jqXhr, textStatus, errorMessage) { // error callback

        }
    });

}


function ajaxaddtocart(id, eve) {

    jQuery(eve).addClass('spin')

    var data = {
        action: 'woocommerce_ajax_add_to_cart',
        product_id: id,
        product_sku: '',
        quantity: 1,
        variation_id: '',

    };
    jQuery.ajax({
        type: 'post',
        url: ajax_object.ajax_url,
        data: data,


        success: function (response) {

            if (response !== 0) {
                jQuery(eve).removeClass('spin')
                jQuery('.alert-popup').fadeIn();
                setTimeout(function () {
                    jQuery('.alert-popup').fadeOut()
                }, 5000);
                jQuery('#cart-counter').html(response)
            } else {
                jQuery(eve).removeClass('spin')
                jQuery('.alert-popup-w').fadeIn();
                setTimeout(function () {
                    jQuery('.alert-popup-w').fadeOut()
                }, 5000);
            }
        },
        error: function () {
            jQuery(eve).removeClass('spin')
            jQuery('.alert-popup-w').fadeIn();
            setTimeout(function () {
                jQuery('.alert-popup-w').fadeOut()
            }, 5000);
        }
    });
}


function ajaxsearch(eve) {
    if (jQuery(eve).val().length > 2){
        keyword = jQuery(eve).val()
        jQuery.ajax({
            type: "POST",
            // dataType : "json",
            url: ajax_object.ajax_url,
            data: {
                action: "searchajax",

                keyword: keyword,


            },
            success: function (responce) {   // success callback function
                jQuery('#search-result').html(responce)
                jQuery('.search-box').slideDown()
            },
            error: function (jqXhr, textStatus, errorMessage) { // error callback

            }
        });

    }

}


function ajaxsearchm(eve){
    if (jQuery(eve).val().length > 2){
        keyword = jQuery(eve).val()
        jQuery.ajax({
            type: "POST",
            // dataType : "json",
            url: ajax_object.ajax_url,
            data: {
                action: "searchajax",
                keyword: keyword,

            },
            success: function (responce) {   // success callback function
                jQuery('#search-resultm').html(responce)
                jQuery('.search-boxm').slideDown()
            },
            error: function (jqXhr, textStatus, errorMessage) { // error callback

            }
        });

    }

}