
/* SELECT 2*/
$(document).ready(function() {
    $('.js-example-basic-single').select2({
        dir:'rtl',
    });
});


$('.btn-menu').click(function () {
    $('.menu-responsive').fadeIn();
    $('.menu-responsive').addClass('show')
})
$('.menu-responsive .btn-close').click(function () {
    $('.menu-responsive').fadeOut();
    $('.menu-responsive').removeClass('show')
})

$('.btn-menu-profile').click(function () {
    $('.menu-profile').fadeIn();
    $('.menu-profile').addClass('show')
})
$('.menu-profile .btn-close').click(function () {
    $('.menu-profile').fadeOut();
    $('.menu-profile').removeClass('show')
})



$('.btn-filter').click(function () {
    $('.filter-popup').addClass('show')
})
$('.filter-popup .btn-close , .filter-popup .after').click(function () {
    $('.filter-popup').removeClass('show')
})


$('.dropdown').hover(function() {
    $(this).find('.dropdown-menu').stop(true, true).delay(50).slideDown(500).addClass('active');
}, function() {
    $(this).find('.dropdown-menu').stop(true, true).delay(50).slideUp(500).removeClass('active');
});


var btn_burger = $('.btn-menuburger-search') , loader = new SVGLoader( document.getElementById( 'loader-search' ), { speedIn : 1000, easingIn : mina.easeinout } );
var items = document.querySelectorAll('.nav-animate');

// get vendor transition property
var docElemStyle = document.documentElement.style;
var transitionProp = typeof docElemStyle.transition == 'string' ?
    'transition' : 'WebkitTransition';
btn_burger.on('click' , function () {
    $(this).toggleClass('open menuburger-open');

    if (btn_burger.hasClass('open')) {
        loader.show();
        /* START NEW SCRIPT */
        $('#loader-search .detail-search').delay(500).fadeIn()
        /* END NEW SCRIPT */
    } else  {
        loader.hide();

    }
    for ( var i=0; i < items.length; i++ ) {
        var item = items[i];
        // stagger transition with transitionDelay
        item.style[ transitionProp + 'Delay' ] = ( i * 100 ) + 'ms';
        item.classList.toggle('is-moved');
    }
});
$('#close-search').on('click' , function () {
    loader.hide();
    /* START NEW SCRIPT */
    $('#loader-search .detail-search').fadeOut(300)
    /* END NEW SCRIPT */
    $('.btn-menuburger-search').toggleClass('open menuburger-open');
});


$('.sub-menu-toggle').click(function () {
    $(this).toggleClass('active')
    $(this).parent().find('.sub-menu').slideToggle()
})




$(document).ready(function(){
    // clicking button with class "category-button"
    $(".tab-item").click(function(){
        // get the data-filter value of the button
        var filterValue = $(this).attr('data-filter');

        $('.filter-item').not('.'+filterValue).hide();
        $('.filter-item').filter('.'+filterValue).show();

        $(this).parent().find('.active').removeClass('active')
        $(this).addClass('active');
    });
});

$(function() {
    var Accordion = function(el, multiple) {
        this.el = el || {};
        // more then one submenu open?
        this.multiple = multiple || false;

        var dropdownlink = this.el.find('.dropdownlink');
        dropdownlink.on('click',
            { el: this.el, multiple: this.multiple },
            this.dropdown);
    };

    Accordion.prototype.dropdown = function(e) {
        var $el = e.data.el,
            $this = $(this),
            //this is the ul.submenuItems
            $next = $this.next();

        $next.slideToggle();
        $this.parent().toggleClass('active');

        if(!e.data.multiple) {
            //show only one menu at the same time
            $el.find('.submenu').not($next).slideUp().parent().removeClass('active');
        }
    }

    var accordion = new Accordion($('.accordion-menu'), false);
})



if ($(window).width() < 576 ) {
    $(".change-text").attr("placeholder","سوال مورد نظر خود را جستجو کنید . . .");
}
else { $(".change-text").attr("placeholder","سوال مورد نظر خود را درباره مرجوع مرسوله جستجو کنید . . .");}











var swiperheader = new Swiper('.swiper-header', {
    spaceBetween: 0,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-header',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-header',
        prevEl: '.swiper-button-prev-header',
    },
});


var swiperp1 = new Swiper('.swiper-p1', {
    spaceBetween: 30,
    slidesPerView: 3,
    pagination: {
        el: '.swiper-pagination-p1',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-p1',
        prevEl: '.swiper-button-prev-p1',
    },
    breakpoints: {
        480 : {
            slidesPerView: 1,

        },
        992 : {
            spaceBetween: 15,
            slidesPerView: 2,
        },
    }
});
var swiperp2 = new Swiper('.swiper-p2', {
    spaceBetween: 30,
    slidesPerView: 3,
    pagination: {
        el: '.swiper-pagination-p2',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-p2',
        prevEl: '.swiper-button-prev-p2',
    },
    breakpoints: {
        480 : {
            slidesPerView: 1,

        },
        992 : {
            spaceBetween: 15,
            slidesPerView: 2,
        },
    }
});
var swiperp3 = new Swiper('.swiper-p3', {
    spaceBetween: 15,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-p3',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-p3',
        prevEl: '.swiper-button-prev-p3',
    },
});
var swiperp4 = new Swiper('.swiper-p4', {
    spaceBetween: 15,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-p4',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-p4',
        prevEl: '.swiper-button-prev-p4',
    },
});

var swiperproduct4 = new Swiper('.swiper-products-4', {
    slidesPerView: 1,
    spaceBetween: 0,
    pagination: {
        el: '.swiper-pagination-products-4',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-products-4',
        prevEl: '.swiper-button-prev-products-4',
    },
});
var swiperarticle1 = new Swiper('.swiper-article-1', {
    slidesPerView: 1,
    spaceBetween: 10,
    pagination: {
        el: '.swiper-pagination-article-1',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-article-1',
        prevEl: '.swiper-button-prev-article-1',
    },
});


var swiperarticles = new Swiper('.swiper-articles', {
    spaceBetween: 30,
    slidesPerView: 3,
    pagination: {
        el: '.swiper-pagination-articles',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-articles',
        prevEl: '.swiper-button-prev-articles',
    },
    breakpoints: {
        480 : {
            slidesPerView: 1,

        },
        992 : {
            spaceBetween: 15,
            slidesPerView: 2,
        },
    }
});

var swipertestimonial = new Swiper('.swiper-testimonial', {
    slidesPerView: 2,
    spaceBetween: 30,
    pagination: {
        el: '.swiper-pagination-testimonial',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-testimonial',
        prevEl: '.swiper-button-prev-testimonial',
    },
    breakpoints: {

        992: {
            slidesPerView: 1,
        },
        1200: {
            spaceBetween: 15,
        },
    }
});


var thumbsyncsswiper = new Swiper('.swiper-thumbs', {
    spaceBetween: 15,
    slidesPerView: 'auto',
    freeMode: true,
    direction: 'vertical',
    watchSlidesVisibility: true,
    watchSlidesProgress: true,
    breakpoints: {

        992: {
            spaceBetween: 10,

        },
    }
});
var swipermainsync= new Swiper('.swiper-main-sync', {
    spaceBetween: 15,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-main-sync',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-main-sync',
        prevEl: '.swiper-button-prev-main-sync',
    },
    thumbs: {
        swiper: thumbsyncsswiper,
    },
});