<?php
/* Template Name: SignUp Template */

if (is_user_logged_in()) {
    wp_redirect(get_home_url() . '/my-account');
} else {


    if (isset($_POST['saveone'])) {

        $error = false;

        $mass = array();

        if (empty($_POST['myuser'])) {
            $error = true;
            $mass[] = "نام کاربری خود را چک کنید";
        } else {
            $user = get_user_by('login', $_POST['myuser']);
            if (!$user) {
                $username = sanitize_text_field($_POST['myuser']);
            } else {
                $error = true;
                $mass[] = "این نام کاربری انتخاب شده";
            }
        }

        if (empty($_POST['useremail'])) {
            $error = true;
            $mass[] = "ایمیل خود را چک کنید";

        } else {
            $user = get_user_by('email', $_POST['useremail']);
            if (!$user) {
                $useremail = sanitize_email($_POST['useremail']);
            } else {
                $error = true;
                $mass[] = "با این ایمیل ثبت نام انجام شده";
            }
        }
        if (!($error)) {
            if (!empty($_POST['pass']) && !empty($_POST['repass']) && ($_POST['pass'] == $_POST['repass'])) {

                $userdata = array(
                    'user_login' => $username,
                    'user_email' => $useremail,
                    'user_pass' => $_POST['pass']
                );

                $user_id = wp_insert_user($userdata);
                if (is_wp_error($user_id)) {
                    $error = true;
                    $mass[] = "خطایی در ثبت نام رخ داده لدفا دوباره تلاش کنید";
                } else {
                    $creds = array(
                        'user_login' => $username,
                        'user_password' => $_POST['pass'],
                        'remember' => true
                    );
                    $user = wp_signon($creds, true);
                    var_dump($creds);
                    if (is_wp_error($user)) {
                   
                    } else {
                        wp_redirect(get_home_url() . '/my-account');
                    }
                }

            } else {
                $error = true;
                $mass[] = "پسورد خود را چک کنید";

            }
        } else {

        }


    }

    get_header('single');

    global $wp;
    $postthumbid = get_post_thumbnail_id();
    $postthumburl = wp_get_attachment_image_url($postthumbid, 'single');
    $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
    $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    get_template_part('partials/stones', 'head') ?>

    <style>
        p.my-alert {
            background: orange;
            color: #fff;
            padding: 11px;
            text-align: center;
        }
    </style>
    <!--START-MAIN-->
    <main>
        <!--START-BREAD-CRUMB-->
        <div class="bread-crumb">
            <div class="container d-flex justify-content-between align-items-center flex-wrap">
                <ul class="nav nav-bread">
                    <li class="nav-item">
                        <a href="<?php echo get_home_url() ?>" class="nav-link">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo $url ?>" class="nav-link">
                            ایجاد حساب کاربری جدید
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!--END-BREAD-CRUMB-->

        <!--START-LOGIN-->
        <div class="login-section">
            <div class="container p-0 d-flex flex-wrap">
                <div class="col-xl-6 col-lg-7">

                    <div class="main">
                        <?php
                        if ($error == true) {
                            foreach ($mass as $mas) {
                                ?>
                                <p class="my-alert"><?php echo $mas ?></p>
                                <?php
                            }
                        }
                        ?>

                        <form action="" method="post" id="register">
                            <div class="form-group">
                                <label for="" class="label">
                                    نام کاربری
                                </label>
                                <div class="relative">
                                    <input type="text" name="myuser" class="text-left-input" placeholder="user name">
                                    <i class="icon-user absolute-icon"></i>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="" class="label">
                                    پست الکترونیک
                                </label>
                                <div class="relative">
                                    <input type="text" name="useremail" class="text-left-input" placeholder="stonesgallery@gmail.com">
                                    <i class="icon-email absolute-icon"></i>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="" class="label">
                                    کلمه عبور
                                </label>
                                <div class="relative">
                                    <input type="password" name="pass" class="text-left-input-2" value="" id="passinput">
                                    <i class="icon-padlock absolute-icon"></i>
                                    <div class="show" id="showpass">
                                        <i class="icon-visibility"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="" class="label">
                                    تکرار کلمه عبور
                                </label>
                                <div class="relative">
                                    <input type="password" name="repass" class="text-left-input-2" value="" id="passinput1">
                                    <i class="icon-padlock absolute-icon"></i>
                                    <div class="show" id="showpass1">
                                        <i class="icon-visibility"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="w-res-100">
                                    <input checked type="checkbox" onchange="disSign()" id="c" class="d-none qavanin-check">
                                    <label class="label-check" for="c">
                                        <span class="circle"></span>
                                        قوانین و مقررات را قبول میکنم
                                    </label>
                                    <span class="text">
                                    اگر حساب کاربری دارید <a href="<?php echo get_home_url() .'/login' ?>">اینجا</a> را کلیک کنید
                                </span>
                                </div>
                                <style>
                                    .login-section .btn-submit {
                                        background-color: #c3a775 !important;
                                    }

                                    .w-unset {
                                        width: unset !important;
                                    }
                                </style>
                                <?php echo do_shortcode("[bws_google_captcha]") ?>
                                <input  type="submit" name="saveone" class="btn btn-submit d-inline-block w-unset"
                                       value="عضویت">

                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-5 d-none d-lg-block">
                    <div class="img r-h">
                        <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                    </div>
                </div>
            </div>
        </div>
        <!--END-LOGIN-->


    </main>
    <!--END-MAIN-->

    <script>
        function disSign(){
            setTimeout(function () {
                if (jQuery('#c').is(':checked')) {
                    jQuery(':input[type="submit"]').prop('disabled', false);
                }else {
                    jQuery(':input[type="submit"]').prop('disabled', true);
                }

            }, 100);
        }
    </script>
    <?php get_footer('profile');
} ?>
