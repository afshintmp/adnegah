<?php
global $wp;
global $post;
$_product       = wc_get_product( $post->ID );
$url            = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$cs_meta_val    = get_post_meta( $post->ID );
$attachment_ids = $_product->get_gallery_image_ids();
$tumbnuil_id    = get_post_thumbnail_id();
$view           = get_post_meta( $post->ID, 'view', true );
if ( ! isset( $_COOKIE['veiw'] ) && ! $_COOKIE['veiw'] == get_the_ID() ) {
	$view = intval( $view ) + 1;
	update_post_meta( $post->ID, 'view', $view );
	$time = time() + 3600 * 24 * 365;
	setcookie( "veiw", $post->ID, $time );  /* expire in 1 hour */
}
$like = get_post_meta( $post->ID, 'like', true );
if ( empty( $like ) ) {
	$like = 0;
}
if ( isset( $_GET['like'] ) ) {
	if ( ! isset( $_COOKIE['like'] ) && $_COOKIE['like'] !== get_the_ID() ) {
		$like = intval( $like ) + 1;
		update_post_meta( $post->ID, 'like', $like );
		$time = time() + 3600 * 24 * 365;
		setcookie( "like", $post->ID, $time );  /* expire in 1 hour */
	}
}
$view = get_post_meta( $post->ID, 'view', true );
$like = get_post_meta( $post->ID, 'like', true );
if ( empty( $like ) ) {
	$like = 0;
}
get_header( 'shop' );
?>

    <div class="alert-popup success">
        <div class="container">
            محصول مورد نظر به سبد خرید اضافه شد
            <span><a href="<?php echo get_home_url() . '/cart' ?>">مشاهده ی سبد خرید</a></span>
        </div>
    </div>
    <style>
        html {
            overflow-x: hidden;
        }
    </style>
<?php get_template_part( 'partials/stones', 'head' ) ?>


    <main>

        <div class="bread-crumb">
            <div class="container d-flex justify-content-between align-items-center flex-wrap">
				<?php $terms = get_the_terms( get_the_ID(), 'product_cat' ); ?>

                <ul class="nav nav-bread">
                    <li class="nav-item">
                        <a href="<?php echo get_home_url() ?>" class="nav-link">
                            <i class="icon-home"></i>
                        </a>
                    </li>
					<?php foreach ( $terms as $term ): ?>
                        <li class="nav-item">
                            <a href="<?php echo get_home_url() . '/shop?catid' . $term->term_id ?>" class="nav-link">
								<?php echo $term->name ?>
                            </a>
                        </li>
					<?php endforeach; ?>


                    <li class="nav-item">
                        <a href="<?php echo get_permalink() ?>" class="nav-link">
							<?php echo get_the_title() ?>
                        </a>
                    </li>
                </ul>


            </div>
        </div>


        <!--START-PRODUCT-SINGLE-->
        <div class="product-single">
            <div class="container p-0 d-flex flex-wrap">
                <ul class="nav nav-tab col-12 d-lg-flex d-none">
                    <li class="nav-item tab-item" id="go-target1">
                        <i class="icon-search"></i>
                        اطلاعات کلی محصول
                    </li>
                    <li class="nav-item tab-item" id="go-target2">
                        <i class="icon-settings"></i>
                        مشخصات
                    </li>

                    <li class="nav-item tab-item" id="go-target3">
                        <i class="icon-box"></i>
                        توضیحات
                    </li>

                    <li class="nav-item tab-item" id="go-target4">
                        <i class="icon-chat"></i>
                        نظرات کاربران
                    </li>
                </ul>
                <div class="col-12 d-lg-none d-flex justify-content-between align-items-start flex-wrap">
                    <div>
                     <span class="name ">
                         <?php echo get_the_title() ?>
                        </span>
                        <span class="model ">
                            <?php if ( isset ( $cs_meta_val['cs-meta-name'] ) )
	                            echo $cs_meta_val['cs-meta-name'][0] ?>
                         </span>
                        <ul class="nav nav-info">
                            <li class="nav-item">
                                دسته بندی
                                <span style="color: #b6b6b6">
                              دستبند ها
                        </span>
                            </li>
                        </ul>
                    </div>

                    <ul class="nav nav-view">
                       
                        <li class="nav-item">
                            <i class="icon-chat"></i>
							<?php echo get_comments_number() ?>
                            نظر
                        </li>
                        <li class="nav-item">
                            <i class="icon-view"></i>
							<?php echo $view ?>
                            بازدید
                        </li>
                    </ul>
                </div>
                <div class="col-xl-5 d-flex align-items-start" id="target1">
                    <div class="swiper-container swiper-thumbs">
                        <div class="swiper-wrapper">
							<?php
							$attachment_id = get_post_thumbnail_id();
							if ( ! empty( $attachment_id ) ) {
								$image_link = wp_get_attachment_url( $attachment_id );
								$alt        = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
								?>
                                <div class="swiper-slide item">
                                    <img src="<?php echo $image_link ?>" alt="<?php echo $alt ?>">
                                </div>
								<?php
							}
							foreach ( $attachment_ids as $attachment_id ) {
								$image_link = wp_get_attachment_url( $attachment_id );
								$alt        = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
								?>
                                <div class="swiper-slide item">
                                    <img src="<?php echo $image_link ?>" alt="<?php echo $alt ?>">
                                </div>
								<?php
							}
							?>

                        </div>
                    </div>
                    <div class="swiper-container swiper-main-sync">
                        <div class="swiper-wrapper">


							<?php
							$attachment_id = get_post_thumbnail_id();
							if ( ! empty( $attachment_id ) ) {
								$image_link = wp_get_attachment_url( $attachment_id );
								$alt        = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
								?>
                                <a data-fancybox="gallery1" href="<?php echo $image_link ?>" class="swiper-slide item">
                                    <img src="<?php echo $image_link ?>" alt="<?php echo $alt ?>">
                                </a>
                                <!-- <div class="swiper-slide item">
                                    <img src="<?php /*echo $image_link */ ?>" alt="<?php /*echo $alt */ ?>">
                                </div>-->
								<?php
							}
							if ( ! empty( $attachment_ids ) ) {
								foreach ( $attachment_ids as $attachment_id ) {
									$image_link = wp_get_attachment_url( $attachment_id );
									$alt        = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
									?>
                                    <a data-fancybox="gallery1" href="<?php echo $image_link ?>"
                                       class="swiper-slide item">
                                        <img src="<?php echo $image_link ?>" alt="<?php echo $alt ?>">
                                    </a>

                                    <!-- <div class="swiper-slide item">
                                        <img src="<?php /*echo $image_link */ ?>" alt="<?php /*echo $alt */ ?>">
                                    </div>-->
									<?php
								}
							}
							?>

							<?php


							?>
                        </div>
                        <ul class="nav nav-action d-lg-none d-flex">

                            <li class="nav-item">
                                <a href="?like=1" class="nav-link">
                                    <i class="icon-heart"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                <span class="name d-lg-block d-none">
 <?php $terms_col = get_the_terms( get_the_ID(), 'colection' );
 if ( $terms_col && ! empty( $terms_col ) ) {
	 foreach ( $terms_col as $tax ) {
		 echo $tax->name . ' / ';
	 }
 }
 echo get_the_title() ?>
                </span>
                    <span class="model d-lg-block d-none">
                     <?php if ( isset ( $cs_meta_val['cs-meta-name'] ) )
	                     echo $cs_meta_val['cs-meta-name'][0] ?>
                </span>
                    <ul class="nav nav-info d-lg-flex d-none">
						<?php $terms = get_the_terms( $_product->get_id(), 'product_cat' ) ?>
                        <li class="nav-item">
                            دسته بندی
							<?php
							$i            = 1;
							$term_ids_f_p = array();
							foreach ( $terms as $newterm ) {
								?>
                                <span style="color: #b6b6b6">
                                        <?php echo $i == 1 ? ' ' : ' / ';
                                        echo $newterm->name ?>
                                    </span>
								<?php
								$i ++;
								$term_ids_f_p[] = $newterm->term_id;
							} ?>

                        </li>
                    </ul>
                    <ul class="nav nav-view d-lg-flex d-none">
                        <li class="nav-item">
                            <i class="icon-star"></i>
							<?php echo $like ?>
                        </li>
                        <li class="nav-item">
                            <i class="icon-chat"></i>
							<?php echo get_comments_number() ?>
                            نظر
                        </li>
                        <li class="nav-item">
                            <i class="icon-view"></i>
							<?php echo $view ?>
                            بازدید
                        </li>
                    </ul>


					<?php $product_atr = get_post_meta( get_the_ID(), '_product_attributes' );
					if ( $product_atr && ! empty( $product_atr ) ) {
						foreach ( $product_atr[0] as $atr ) {
							$rental_features = get_taxonomy( $atr["name"] );
							?>
                            <div class="d-flex align-items-center" style="margin-bottom: 15px">
                            <span class="titr">
                            انتخاب
                            <?php echo ' ' . ( $rental_features->labels->singular_name ) ?>
                            </span>
                                <select class="js-example-basic-single" name="state">

									<?php $pro_arry = explode( ', ', $_product->get_attribute( $atr["name"] ) );
									foreach ( $pro_arry as $pro_a ) {
										$category = get_term_by( 'name', $pro_a, $atr["name"] );
										?>
                                        <option value="<?php echo $category->slug ?>">
											<?php echo $pro_a ?>
                                        </option>
										<?php
									}


									?>
                                </select>
                            </div>
							<?php
						}
					}
					?>

					<?php if ( has_excerpt() ) : ?>
                        <span class="title">
                    ویژگی های محصول
                </span>
                        <div class="expert">
							<?php echo get_the_excerpt() ?>
                        </div>
					<?php endif; ?>

                </div>
				<?php $forprice = get_post_meta( get_the_ID() ) ?>

                <div class="col-xl-4 col-md-6">
                    <div class="box">
						<?php if ( get_post_meta( get_the_ID(), '_stock_status', true ) == 'outofstock' || empty( get_post_meta( get_the_ID(), '_regular_price', true ) ) ) {
							?>
                            <div class="row">
                                <a
                                        class="btn btn-add-cart" style="background: #c3a775!important;color: #fff">
                                    ناموجود
                                </a>
                            </div>
							<?php
						} else {
							?>

                            <div class="row justify-content-between align-items-center">

                            <span class="price mb-0">
                            <?php if ( ! empty( $forprice['_sale_price'][0] ) ) { ?>
                                <del>

                                <?php

                                echo number_format( $forprice['_regular_price'][0], 0, ',', ',' )
                                ?>

                            </del>
                            <?php } ?>
                        </span>
								<?php if ( ! empty( $forprice['_sale_price'][0] ) ) { ?>
                                    <span class="profit">

                            سود شما

                                <?php echo number_format( ( $forprice['_regular_price'][0] - $forprice['_sale_price'][0] ), 0, '', ',' ) ?>
										<?php echo '  ' . get_woocommerce_currency_symbol() . ' ' ?>

                            </span>

                                    <div class="lines">
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
								<?php } ?>
                            </div>

                            <div class="row justify-content-center pb-0">

                            <span class="price">
 <?php if ( ! empty( $forprice['_sale_price'][0] ) ) { ?>
	 <?php echo number_format( $forprice['_sale_price'][0], 0, ',', ',' ) ?>
 <?php } else { ?>
	 <?php echo number_format( $forprice['_regular_price'][0], 0, ',', ',' ) ?>
 <?php } ?>
                            <span class="small">
                             <?php echo get_woocommerce_currency_symbol() ?>
                            </span>
                        </span>
                            </div>
                            <div class="row pt-0">

                                <!--START-CHANGE-->
                                <button class="btn btn-add-cart"
                                        onclick="ajaxaddtocart(<?php echo get_the_ID() ?> , this)">
                                    <i class="icon-shopping-cart"></i>
                                    اضافه به سبد خرید

                                    <span class="spinner"></span>
                                </button>
                                <!--END-CHANGE-->

                            </div>
						<?php } ?>
                    </div>
                    <style>
                        .post-ratings {
                            margin-top: 5px;
                        }

                        .post-ratings > div {
                            text-align: center !important;
                            margin-top: 5px;
                        }
                    </style>
                    <ul class="nav nav-action d-lg-flex d-none">

						<?php if ( function_exists( 'the_ratings' ) ) {
							the_ratings();
						} ?>

                    </ul>
                </div>
            </div>
        </div>
        <!--END-PRODUCT-SINGLE-->

        <!--START-PRODUCT-DETAIL-->
        <div class="product-detail">
            <div class="container" id="target3">

				<?php echo get_the_content() ?>

				<?php $cs_meta_val = get_post_meta( $post->ID ); ?>
                <div class="row prl-5px">

					<?php if ( ! empty( $cs_meta_val['banner_one'][0] ) ) { ?>
						<?php if ( ! empty( $cs_meta_val['banner_two'][0] ) ) { ?>
                            <div class="col-xl-4 col-lg-5 prl-10px">

                                <div class="img">
                                    <img src="<?php if ( isset ( $cs_meta_val['banner_one'] ) )
										echo $cs_meta_val['banner_one'][0] ?>"
                                         alt="<?php if ( isset ( $cs_meta_val['alt_one'] ) )
										     echo $cs_meta_val['alt_one'][0] ?>">
                                </div>

                            </div>
						<?php } ?>
						<?php if ( empty( $cs_meta_val['banner_two'][0] ) ) { ?>
                            <div class="col-xl-12 col-lg-12 prl-10px">

                                <div class="img">
                                    <img src="<?php if ( isset ( $cs_meta_val['banner_one'] ) )
										echo $cs_meta_val['banner_one'][0] ?>"
                                         alt="<?php if ( isset ( $cs_meta_val['alt_one'] ) )
										     echo $cs_meta_val['alt_one'][0] ?>">
                                </div>

                            </div>
						<?php } ?>
					<?php } ?>

					<?php if ( ! empty( $cs_meta_val['banner_two'][0] ) ) { ?>
						<?php if ( ! empty( $cs_meta_val['banner_one'][0] ) ) { ?>
                            <div class="col-xl-8 col-lg-7 prl-10px">
                                <div class="img">
                                    <img src="<?php if ( isset ( $cs_meta_val['banner_two'] ) )
										echo $cs_meta_val['banner_two'][0] ?>"
                                         alt="<?php if ( isset ( $cs_meta_val['alt_two'] ) )
										     echo $cs_meta_val['alt_two'][0] ?>">
                                </div>
                            </div>
						<?php } ?>
						<?php if ( empty( $cs_meta_val['banner_one'][0] ) ) { ?>
                            <div class="col-xl-12 col-lg-12 prl-10px">
                                <div class="img">
                                    <img src="<?php if ( isset ( $cs_meta_val['banner_two'] ) )
										echo $cs_meta_val['banner_two'][0] ?>"
                                         alt="<?php if ( isset ( $cs_meta_val['alt_two'] ) )
										     echo $cs_meta_val['alt_two'][0] ?>">
                                </div>
                            </div>
						<?php } ?>
					<?php };
					$cs_meta_val = get_post_meta( $post->ID ); ?>
                    <div class="table" id="target2">
                        <div class="tr row prl-10px">

							<?php if ( ! empty( $cs_meta_val['tt_1'][0] ) ) { ?>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="th">
                                        <i class="icon-left-chevron"></i>
										<?php echo $cs_meta_val['tt_1'][0] ?>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="td">
										<?php echo $cs_meta_val['st_1'][0] ?>
                                    </div>
                                </div>
							<?php } ?>


							<?php if ( ! empty( $cs_meta_val['tt_2'][0] ) ) { ?>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="th">
                                        <i class="icon-left-chevron"></i>
										<?php echo $cs_meta_val['tt_2'][0] ?>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="td">
										<?php echo $cs_meta_val['st_2'][0] ?>
                                    </div>
                                </div>
							<?php } ?>


							<?php if ( ! empty( $cs_meta_val['tt_3'][0] ) ) { ?>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="th">
                                        <i class="icon-left-chevron"></i>
										<?php echo $cs_meta_val['tt_3'][0] ?>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="td">
										<?php echo $cs_meta_val['st_3'][0] ?>
                                    </div>
                                </div>
							<?php } ?>
							<?php if ( ! empty( $cs_meta_val['tt_4'][0] ) ) { ?>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="th">
                                        <i class="icon-left-chevron"></i>
										<?php echo $cs_meta_val['tt_4'][0] ?>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="td">
										<?php echo $cs_meta_val['st_4'][0] ?>
                                    </div>
                                </div>
							<?php } ?>
							<?php if ( ! empty( $cs_meta_val['tt_5'][0] ) ) { ?>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="th">
                                        <i class="icon-left-chevron"></i>
										<?php echo $cs_meta_val['tt_5'][0] ?>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="td">
										<?php echo $cs_meta_val['st_5'][0] ?>
                                    </div>
                                </div>
							<?php } ?>

							<?php if ( ! empty( $cs_meta_val['tt_6'][0] ) ) { ?>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="th">
                                        <i class="icon-left-chevron"></i>
										<?php echo $cs_meta_val['tt_6'][0] ?>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-6 prl-5px">
                                    <div class="td">
										<?php echo $cs_meta_val['st_6'][0] ?>
                                    </div>
                                </div>
							<?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            <!--END-PRODUCT-DETAIL-->

            <!--START-PRODUCTS-->
            <div class="products">
                <div class="container">
                    <div class="header-section">
                <span class="title kalameh">
                    محــصولات مرتبــط گــالری تهرانــی
                </span>
                        <div class="lines">
                            <div class="line"></div>
                            <div class="line"></div>
                            <div class="line"></div>
                        </div>
                    </div>
                    <div class="slider-container overflow-visible">
                        <div class="swiper-container swiper-p2">
                            <div class="swiper-wrapper">
								<?php
								$args      = array(
									'post_type'      => 'product',
									'posts_per_page' => 9,
									'tax_query'      => array(
										array(
											'taxonomy' => 'product_cat',
											'field'    => 'term_id',
											'terms'    => $term_ids_f_p,
											'operator' => 'IN',
										)
									)
								);
								$the_query = new WP_Query( $args );
								if ( $the_query->have_posts() ) :
									while ( $the_query->have_posts() ) : $the_query->the_post();

										$postthumbid  = get_post_thumbnail_id();
										$postthumburl = wp_get_attachment_image_url( $postthumbid, 'full' );
										$image_alt    = get_post_meta( $postthumbid, '_wp_attachment_image_alt', true );
										$newseles     = get_post_meta( get_the_ID(), '_sale_price', true )
										?>
                                        <a href="<?php echo get_the_permalink() ?>" class="swiper-slide item">
											<?php if ( ! empty( $newseles ) ) : ?>
                                                <span class="label">
                                                 فـــروش ویـــژه
                                            </span>
											<?php endif; ?>
                                            <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                                            <span class="title">
                                                 <?php echo get_the_title() ?>
                                             </span>
                                            <span class="subtitle kalameh">
                          <?php
                          if ( get_post_meta( get_the_ID(), '_stock_status', true ) == 'outofstock' ) {
	                          echo "ناموجود";
                          } else {

	                          if ( ! empty( $newseles ) ) {

		                          echo number_format( $newseles, 0, ',', ',' );
		                          echo ' ' . get_woocommerce_currency_symbol();
	                          } elseif ( ! empty( get_post_meta( get_the_ID(), '_regular_price', true ) ) ) {

		                          echo number_format( get_post_meta( get_the_ID(), '_regular_price', true ), 0, ',', ',' );
		                          echo ' ' . get_woocommerce_currency_symbol();
	                          } else {
		                          echo "ناموجود";
	                          }

                          }

                          ?>
                        </span>
                                        </a>
									<?php endwhile; ?>
								<?php endif; ?>

                            </div>
                        </div>
                        <div class="button-nav next swiper-button-next-p2">
                            <i class="icon-left"></i>
                        </div>
                        <div class="button-nav prev swiper-button-prev-p2">
                            <i class="icon-right"></i>
                        </div>
                    </div>
                </div>
            </div>
            <!--END-PRODUCTS-->


            <!--START-FORM-ELEMENTS-->
            <div class="form-elements only-section" id="target4">
                <div class="container">
            <span class="title kalameh">
                <img src="<?php echo get_template_directory_uri() . '/assets/img/shape-1.png' ?>" alt="shape">
                فــرم ارســال نــظر کاربــران
            </span>
					<?php
					$commenter     = wp_get_current_commenter();
					$req           = get_option( 'require_name_email' );
					$aria_req      = ( $req ? " aria-required='true'" : '' );
					$fields        = array(
						'author' => '  <div class="row align-items-center">
     <div class="col-xl-6 p-0 d-flex flex-wrap">
                                    <div class="col-md-12 prl-10px">
                                        <div class="form-group">
                                            <label for="name" class="label">
                                                نام و نام خانوادگی
                                            </label>
                                            <input type="text" name="author" id="name" placeholder="سید فرهاد" value="' . esc_attr( $commenter['comment_author'] ) . '">
                                            <i class="icon-user absolute-icon"></i>
                                        </div>
                                    </div>',
						'email'  => ' <div class="col-md-12 prl-10px">
                                 <div class="form-group">
                                     <label for="phone" class="label">
                                         ایمیل
                                     </label>
                                     <input type="text"  name="email" id="email" placeholder="info @ Stones - Gallery.ir" value="' . esc_attr( $commenter['comment_author_email'] ) . '">
                                     <i class="icon-phone absolute-icon"></i>
                                 </div>
                             </div>
                             </div>
                   ',
					);
					$comments_args = array(

						'fields'               => $fields,
						'comment_field'        => ' <div class="col-xl-6 prl-10px">
                        <div class="form-group">
                            <label for="text" class="label">
                                نظر خود را یادداشت کنید
                            </label>
                            <textarea id="text" name="comment" style="resize: none"
                                      placeholder="در این بخش میتوانید نظر یا پیشنهاد خود را مطرح کنید . . ."></textarea>
                        </div>

                    </div>',
						'label_submit'         => ' نظر خود را ارسال کنید',
						'submit_button'        => ' <div class="col-sm-auto mr-auto prl-10px">
 <input name="%1$s" type="submit" id="%2$s" class="%3$s btn btn-submit" value="نظر خود را ارسال کنید" />  </div>
                  ',
						'title_reply'          => '',
						'comment_notes_before' => '',
						'comment_notes_after'  => '',


					);
					comment_form( $comments_args );
					?>

                </div>
            </div>

            <div class="comment-section">
                <div class="container">
            <span class="title kalameh">
                <img src="assets/img/shape-1.png" alt="">
                نــظرات کاربــران دربــاره مقالــه
            </span>
					<?php
					$comment_args  = array(
						'orderby'                   => 'comment_date_gmt',
						'order'                     => 'DESC',
						'status'                    => 'approve',
						'post_id'                   => $post->ID,
						'no_found_rows'             => false,
						'update_comment_meta_cache' => false, // We lazy-load comment meta for performance.
					);
					$comment_query = new WP_Comment_Query( $comment_args );
					$_comments     = $comment_query->comments;


					$comments_flat = array();
					foreach ( $_comments as $_comment ) {
						$comments_flat[]  = $_comment;
						$comment_children = $_comment->get_children(
							array(
								'format'  => 'flat',
								'status'  => $comment_args['status'],
								'orderby' => $comment_args['orderby'],
							)
						);

						foreach ( $comment_children as $comment_child ) {
							$comments_flat[] = $comment_child;
						}
					}


					foreach ( $comments_flat as $comment ) {
						if ( $comment->comment_parent == 0 ) {
							?>

                            <div class="w-100">
                                <div class="item">
                                    <div class="top-bar">
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo get_template_directory_uri() . '/assets/img/empty.png' ?>"
                                                 alt="">
                                            <span>
                            <span class="name">
                                <?php echo $comment->comment_author ?>
                            </span>
                            <span class="date">
                                <?php echo $comment->comment_date ?>
                            </span>
                        </span>
                                        </div>
                                        <div class="d-flex align-items-center mr-auto">

                                            <a class="btn btn-reply"
                                               href="<?php echo '?replytocom=' . $comment->comment_ID . '#respond' ?>">
                                                پاسخ دادن
                                            </a>
                                        </div>

                                    </div>
                                    <p class="text">
										<?php echo $comment->comment_content ?>
                                    </p>
                                </div>
								<?php foreach ( $comment->get_children() as $child_cm ) {
									$aouther_id = $child_cm->user_id;

									if ( $aouther_id !== null && $aouther_id !== 0 ) {
										$user_meta = get_userdata( $aouther_id );
										if ( $user_meta ) {
											$user_roles = $user_meta->roles;
										}
									}
									if ( $aouther_id && in_array( 'administrator', $user_roles, true ) ) {
										?>

                                        <div class="item reply-theme gold-theme">
                                            <div class="top-bar">
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo get_template_directory_uri() . '/assets/img/empty.png' ?>"
                                                         alt="">
                                                    <span>
                               <span class="name">
                                   کارشناس فروش
                               </span>
                               <span class="date">
                                   <?php echo $comment->comment_date ?>
                               </span>
                           </span>
                                                </div>
                                                <div class="d-flex align-items-center mr-auto">
                                                    <a class="btn btn-reply"
                                                       href="<?php echo '?replytocom=' . $comment->comment_ID . '#respond' ?>">
                                                        پاسخ دادن
                                                    </a>
                                                </div>
                                            </div>
                                            <p class="text">
												<?php echo $comment->comment_content ?>
                                            </p>
                                        </div>
										<?php
									} else {
										?>
                                        <div class="item reply-theme mb-3">
                                            <div class="top-bar">
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo get_template_directory_uri() . '/assets/img/empty.png' ?>"
                                                         alt="">
                                                    <span>
                               <span class="name">
                                   <?php echo $comment->comment_author ?>
                               </span>
                               <span class="date">
                                   <?php echo $comment->comment_date ?>
                               </span>
                           </span>
                                                </div>
                                                <div class="d-flex align-items-center mr-auto">

                                                    <a class="btn btn-reply"
                                                       href="<?php echo '?replytocom=' . $comment->comment_ID . '#respond' ?>">
                                                        پاسخ دادن
                                                    </a>
                                                </div>

                                            </div>
                                            <p class="text">
												<?php echo $comment->comment_content ?>
                                            </p>
                                        </div>
										<?php
									}
								} ?>
                            </div>
						<?php } ?>

					<?php } ?>
                    <!-- <div class="w-100">
                         <div class="item">
                             <div class="top-bar">
                                 <div class="d-flex align-items-center">
                                     <img src="assets/img/empty.png" alt="">
                                     <span>
                                        <span class="name">
                                            فرهاد موسوی راد
                                        </span>
                                        <span class="date">
                                            24 اسفند ماه 1399    /    ساعت 15:48 ظهر
                                        </span>
                                    </span>
                                 </div>
                                 <div class="d-flex align-items-center mr-auto">
                                     <button class="btn btn-like">
                                         <i class="icon-like"></i>
                                         <span class="d-none d-xl-block">
                                                خواندن این مقاله را پیشنهاد میکنم
                                            </span>
                                         <span class="d-block d-xl-none">
                                                پیشنهاد میکنم
                                            </span>
                                     </button>
                                     <div class="rate">
                                         4.0
                                         <i class="icon-star"></i>
                                     </div>
                                     <button class="btn btn-reply">
                                         پاسخ دادن
                                     </button>
                                 </div>

                             </div>
                             <p class="text">
                                 لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.
                                 چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی
                                 تکنولوژی
                                 مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه
                                 درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت
                                 بیشتری
                                 را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در
                                 این
                                 صورت می توان امید داشت که تمام و دشواری موجود است .
                             </p>
                         </div>

                         <div class="item reply-theme">
                             <div class="top-bar">
                                 <div class="d-flex align-items-center">
                                     <img src="assets/img/empty.png" alt="">
                                     <span>
                                        <span class="name">
                                            فاطمه فرهادی پور
                                        </span>
                                        <span class="date">
                                            24 اسفند ماه 1399    /    ساعت 15:48 ظهر
                                        </span>
                                    </span>
                                 </div>
                                 <div class="d-flex align-items-center mr-auto">
                                     <button class="btn btn-like">
                                         <i class="icon-like"></i>
                                         <span class="d-none d-xl-block">
                                                خواندن این مقاله را پیشنهاد میکنم
                                            </span>
                                         <span class="d-block d-xl-none">
                                                پیشنهاد میکنم
                                            </span>
                                     </button>
                                     <div class="rate">
                                         4.0
                                         <i class="icon-star"></i>
                                     </div>
                                     <button class="btn btn-reply">
                                         پاسخ دادن
                                     </button>
                                 </div>

                             </div>
                             <p class="text">
                                 لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.
                                 چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی
                                 تکنولوژی
                                 مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه
                                 درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت
                                 بیشتری
                                 را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در
                                 این
                                 صورت می توان امید داشت که تمام و دشواری موجود است .
                             </p>
                         </div>
                         <div class="item reply-theme gold-theme">
                             <div class="top-bar">
                                 <div class="d-flex align-items-center">
                                     <img src="assets/img/empty.png" alt="">
                                     <span>
                                        <span class="name">
                                            کارشناس فروش
                                        </span>
                                        <span class="date">
                                            24 اسفند ماه 1399    /    ساعت 15:48 ظهر
                                        </span>
                                    </span>
                                 </div>
                                 <div class="d-flex align-items-center mr-auto">
                                     <button class="btn btn-reply">
                                         پاسخ دادن
                                     </button>
                                 </div>
                             </div>
                             <p class="text">
                                 لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.
                                 چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی
                                 تکنولوژی
                                 مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه
                                 درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت
                                 بیشتری
                                 را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در
                                 این
                                 صورت می توان امید داشت که تمام و دشواری موجود است .
                             </p>
                         </div>
                     </div>-->


                </div>
            </div>

    </main>
    <!--END-MAIN-->

<?php get_footer( 'single-product' ) ?>