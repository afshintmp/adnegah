<div class="articles">
    <div class="container">
        <div class="header-section">
                <span class="title kalameh">
                   <?php block_field('tt') ?>
                </span>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </div>
        <div class="swiper-container swiper-articles">
            <div class="swiper-wrapper">
                <?php
                $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 9
                );
                $the_query = new WP_Query($args);


                if ($the_query->have_posts()) {

                    while ($the_query->have_posts()) {
                        $the_query->the_post();
                        $postthumbid = get_post_thumbnail_id();

                        $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
                        $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);

                        ?>
                        <div class="swiper-slide item">
                            <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                            <article>
                                <a href="<?php echo get_the_permalink() ?>" class="more">
                                    <i class="icon-left-arrow"></i>
                                </a>
                                <span class="date">
                                <?php echo get_the_date() ?>
                            </span>
                                <span class="title">
                                 <?php echo get_the_title() ?>
                            </span>
                            </article>
                        </div>
                <?php
                    }

                } else {

                }

                wp_reset_postdata();
                ?>
            </div>

            <div class="button-nav next swiper-button-next-articles d-lg-none d-flex">
                <i class="icon-left"></i>
            </div>
            <div class="button-nav prev swiper-button-prev-articles d-lg-none d-flex">
                <i class="icon-right"></i>
            </div>
        </div>
    </div>
</div>