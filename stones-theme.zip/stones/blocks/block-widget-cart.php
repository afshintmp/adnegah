<!--START-OUR-WIDGET-->
<div class="our-widget">
    <div class="container p-0 d-flex align-items-center flex-wrap">
        <div class="grid-div col-sm-4 col-6">
            <div class="item">
                <div class="icon">
                    <i class="<?php  block_field('icon') ?>"></i>
                </div>
                <article>
                    <h2 class="title kalameh">
                        <?php  block_field('title') ?>
                    </h2>
                    <span class="subtitle">
                           <?php  block_field('sub-title') ?>
                        </span>
                </article>
            </div>
        </div>
        <div class="grid-div col-sm-4 col-6">
            <div class="item">
                <div class="icon">
                    <i class="<?php  block_field('icon-2') ?>"></i>
                </div>
                <article>
                    <h2 class="title kalameh">
                        <?php  block_field('title-2') ?>
                    </h2>
                    <span class="subtitle">
                           <?php  block_field('sub-title-2') ?>
                        </span>
                </article>
            </div>
        </div>
        <div class="grid-div col-sm-4">
            <div class="item">
                <div class="icon">
                    <i class="<?php  block_field('icon-3') ?>"></i>
                </div>
                <article>
                    <h2 class="title kalameh">
                        <?php  block_field('title-3') ?>
                    </h2>
                    <span class="subtitle">
                           <?php  block_field('sub-title-3') ?>
                        </span>
                </article>
            </div>
        </div>
    </div>
</div>
<!--END-OUR-WIDGET-->