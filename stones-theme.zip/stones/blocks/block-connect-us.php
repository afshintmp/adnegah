<!--START-CONTACT-US-->
<div class="contact-us">
    <div class="container">
        <div class="main">
            <div class="row">
                <div class="col-lg-6">
                    <div class="item">
                        <h1 class="title kalameh">
                            <i class="<?php block_field('icon') ?>"></i>
                           <?php block_field('title') ?>
                        </h1>
                        <span class="subtitle">
                          <?php block_field('text') ?>
                        </span>
                    </div>
                </div>
                <div class="lines d-block d-lg-none">
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
                <div class="col-lg-6">
                    <div class="item">
                        <h2 class="title kalameh">
                            <i class="<?php block_field('icon-2') ?>"></i>
                           <?php block_field('title-2') ?>
                        </h2>
                        <span class="subtitle">
                         <?php block_field('text-2') ?>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 p-0">
                <div class="lines">
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-6 col-lg-5">
                    <div class="item">
                        <h2 class="title kalameh">
                            <i class="<?php block_field('icon-3') ?>"></i>
                           <?php block_field('title-3') ?>
                        </h2>
                        <span class="subtitle number-theme">
                           <?php block_field('text-3') ?>
                        </span>
                    </div>
                </div>
                <div class="lines d-block d-lg-none">
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="item">
                        <h2 class="title kalameh">
                            <i class="<?php block_field('icon-4') ?>"></i>
                            <?php block_field('title-4') ?>
                        </h2>
                        <span class="subtitle">
                           <?php block_field('text-4') ?>
                        </span>
                    </div>
                </div>
                <div class="lines d-block d-md-none">
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="item">
                        <h2 class="title kalameh">
                            <i class="icon-headphones"></i>
                            شبکــه هــای اجتماعــی
                        </h2>
                        <ul class="nav nav-social">
                            <?php if (!empty(block_value('telgram'))) {
                                ?>
                                <li class="nav-item">
                                    <a href="<?php block_field( 'telgram' ); ?>" class="nav-link">
                                        <i class="icon-telegram"></i>
                                    </a>
                                </li>

                                <?php
                            }
                            ?>
                            <?php if (!empty(block_value('insta'))) {
                                ?>
                                <li class="nav-item">
                                    <a href="<?php block_field( 'insta' ); ?>" class="nav-link">
                                        <i class="icon-instagram1"></i>
                                    </a>
                                </li>

                                <?php
                            }
                            ?>
                            <?php if (!empty(block_value('whatsap'))) {
                                ?>
                                <li class="nav-item">
                                    <a href="<?php block_field( 'whatsap' ); ?>" class="nav-link">
                                        <i class="icon-whatsapp"></i>
                                    </a>
                                </li>

                                <?php
                            }
                            ?>
                            <?php if (!empty(block_value('youtube'))) {
                                ?>
                                <li class="nav-item">
                                    <a href="<?php block_field( 'youtube' ); ?>" class="nav-link">
                                        <i class="icon-youtube"></i>
                                    </a>
                                </li>

                                <?php
                            }
                            ?>

                        </ul>
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>
<!--END-CONTACT-US-->

