<style>
    .text-color-- > div > p {

        font-size: 16px;
        color: #ffffff;
        opacity: 0.4;
        display: block;
        text-align: justify;
        text-align-last: right;
        margin-bottom: 0px;

    }
</style>
<div class="about-us-background" style="background-image: url(<?php block_field('img') ?>)">
    <div class="container text-color--">
        <div class="col-lg-6 p-0">
            <div class="header-section right-theme white-theme">
                    <h1 class="subtitle">
                      <?php block_field('sub-title') ?>
                    </h1>
                <h2 class="title kalameh">
                      <?php block_field('title') ?>
                    </h2>
                <div class="lines">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </div>

            <?php echo block_value('text') ?>

        </div>
    </div>
</div>

