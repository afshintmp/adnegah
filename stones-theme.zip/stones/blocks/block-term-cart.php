<div class="item">
                <span class="title">
                    <i class="icon-down-arrow-circle"></i>
                 <?php echo block_field('title') ?>
                </span>
    <p class="text">
        <?php echo block_field('text') ?>
    </p>
</div>
