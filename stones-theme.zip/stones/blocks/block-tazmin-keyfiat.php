<!--START-ABOUT-US-INDEX-->
<div class="about-us-index">
    <div class="container p-0 d-flex flex-wrap align-items-center">
        <div class="col-lg-6">
            <img src=" <?php  block_field('img') ?>" alt=" <?php  block_field('alt') ?>">
        </div>
        <div class="col-lg-6">
            <div class="header-section right-theme">
                    <span class="subtitle">
                        <?php  block_field('st') ?>
                    </span>
                <span class="title kalameh">
 <?php  block_field('tt') ?>
                    </span>
                <div class="lines">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </div>
            <p class="text">
                <?php  block_field('text') ?>
            </p>
            <a href="<?php  block_field('link') ?>" class="more d-inline-block">
                <?php  block_field('text-btn') ?>
            </a>
        </div>
    </div>
</div>
<!--END-ABOUT-US-INDEX-->