<!--START-CHANGE-->
<!--START-VIDEO-POPUP-->
<div class="video-popup">
    <div class="main">
        <button class="btn btn-close" onclick="pause()">
            بستن
        </button>
        <video controls preload="none" poster="" id="video1">
            <source src="<?php block_field('vid') ?>" type="video/mp4">
        </video>
    </div>
</div>
<!--END-VIDEO-POPUP-->
<!--END-CHANGE-->

<!--START-ABOUT-US-->
<div class="about-us">
    <div class="container">
        <div class="main">
                <h1 class="title">
                    <img src="<?php echo get_template_directory_uri() .'/assets/img/shape-1.png' ?>" alt="shape"
                         class="">
                    <?php block_field('title') ?>
                </h1>
            <?php block_field('text') ?>
        </div>
        <div class="video" style="background-image: url(<?php block_field('poster') ?>)">
            <!--START-CHANGE-->
            <button class="btn btn-play show-popup-video" onclick="play()">
                <i class="icon-youtube"></i>
            </button>
            <!--END-CHANGE-->
        </div>
    </div>
</div>
<!--EN-ABOUT-US-->
<!--START-CHANGE-->
<script>
    var $ = jQuery
    $('.show-popup-video').click(function () {
        $('.video-popup').fadeIn()
    })
    $('.video-popup .btn-close').click(function () {
        $('.video-popup').fadeOut()
    })

    var vid1 = document.getElementById("video1");

    function play() {
        vid1.play();
    }

    function pause() {
        vid1.pause();
    }
</script>
<!--END-CHANGE-->