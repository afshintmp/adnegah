<?php
$term_id = block_value('term');
$category = get_term_by('id', $term_id, 'product_tag');

?>
<div class="products-set">
    <div class="container">
        <div class="row align-items-center flex-md-row flex-column-reverse">
            <?php
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => 9,
//            'product_tag' => $term_id,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'product_tag',
                        'field' => 'term_id',
                        'terms' => $term_id,

                    ),
                ),
            );
            $the_query = new WP_Query($args);
            if ($the_query->have_posts()) {
            ?>
            <div class="col-md-6">
                <div class="swiper-container swiper-p4">
                    <div class="swiper-wrapper">
                        <?php
                        while ($the_query->have_posts()) {
                            $the_query->the_post();
                            $postthumbid = get_post_thumbnail_id();
                            $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
                            $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
                            $newseles = get_post_meta(get_the_ID(), '_sale_price', true);
                            ?>


                                <a href="<?php echo get_the_permalink() ?>" class="swiper-slide item">
                                    <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                                    <span class="title">
                                    <?php echo get_the_title() ?>
                                </span>
                                    <span class="subtitle kalameh">
<?php echo $category->name ?>
                                </span>
                                </a>

                        <?php } ?>

                    </div>
                </div>
                <div class="pagination swiper-pagination-p4"></div>
                <?php } ?>
            </div>
            <div class="col-md-6">
                <div class="img">
                    <img src="<?php block_field('img') ?>" alt="<?php echo block_value('alt') ?>">
                </div>
            </div>
        </div>
    </div>
</div>

