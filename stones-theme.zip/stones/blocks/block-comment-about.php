<div class="testimonial">
    <div class="container">
        <div class="main">
            <div class="header-item">
                    <span class="title">
                        <img src="<?php echo get_template_directory_uri() . '/assets/img/shape-1.png' ?>" alt="shape">
                        <span class="d-none d-sm-block">
                               <?php  block_field('title') ?>
                        </span>
                        <span class="d-block d-sm-none">
                               <?php  block_field('sub-title') ?>
                        </span>
                    </span>
                <div class="swiper-navigation">
                    <div class="button swiper-button-prev-testimonial">
                        <i class="icon-right-arrow"></i>
                    </div>
                    <div class="button swiper-button-next-testimonial">
                        <i class="icon-left-arrow"></i>
                    </div>
                </div>
            </div>
            <div class="swiper-container swiper-testimonial">
                <div class="swiper-wrapper">
                    <div class="swiper-slide item">
                        <div class="top-bar">
                            <img src="<?php  block_field('img') ?>" alt="<?php  block_field('name') ?>">
                            <span class="name">
                                <b>
                                       <?php  block_field('name') ?>
                                </b>
                                   <?php  block_field('s-n') ?>
                            </span>
                        </div>
                        <p class="text">
                            <?php  block_field('text') ?>
                        </p>
                    </div>



                    <div class="swiper-slide item">
                        <div class="top-bar">
                            <img src="<?php  block_field('img-1') ?>" alt="<?php  block_field('name-1') ?>">
                            <span class="name">
                                <b>
                                    <?php  block_field('name-1') ?>
                                </b>
                                 <?php  block_field('s-n-1') ?>
                            </span>
                        </div>
                        <p class="text">  <?php  block_field('text-1') ?>    </p>
                    </div>
                    <div class="swiper-slide item">
                        <div class="top-bar">
                            <img src="<?php  block_field('img-2') ?>" alt="<?php  block_field('name-2') ?>">
                            <span class="name">
                                <b>
                                    <?php  block_field('name-2') ?>
                                </b>
                                <?php  block_field('s-n-2') ?>
                            </span>
                        </div>
                        <p class="text"><?php  block_field('text-2') ?></p>
                    </div>
                    <div class="swiper-slide item">
                        <div class="top-bar">
                            <img src="<?php  block_field('img-3') ?>" alt="<?php  block_field('name-3') ?>">
                            <span class="name">
                                <b>
                                    <?php  block_field('name-3') ?>
                                </b>
                                  <?php  block_field('s-n-3') ?>
                            </span>
                        </div>
                        <p class="text">  <?php  block_field('text-3') ?>   </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
