<div class="seller-box">
                    <span class="title">
                      <?php block_field('title') ?>
                    </span>
    <div class="d-flex align-items-center">
        <a href="" class="call">
            <?php block_field('btn-text') ?>
        </a>
        <a href="" class="number">
             <?php block_field('phone') ?>
        </a>
    </div>
    <img src="<?php block_field('img') ?>" alt="  <?php block_field('alt-text') ?>" class="shape">
</div>