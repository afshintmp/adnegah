<style>
    .form-contact iframe{
        height: 670px!important;
    }
</style>
<!--START-FORM-CONTACT-->
<div class="form-contact">
    <div class="container">
        <div class="main">
            <div class="col-xl-6">
                <div class="form-elements">
                        <span class="title">
                            <img src="<?php echo get_template_directory_uri() .'/assets/img/shape-1.png' ?>" alt="">
                           <?php block_field( 'title' ); ?>
                        </span>
                    <?php echo do_shortcode('[contact-form-7 id="72"]') ?>
                </div>
            </div>

            <div class="col-xl-6">
                <?php
                $str = str_replace("<p>", "", block_value('map'), $count);
                $str = str_replace("</p>", "",$str, $count);

                ?>

                <iframe src="<?php echo $str ?>" width="600" height="650" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                            </div>
        </div>
    </div>
</div>
<!--END-FORM-CONTACT-->
