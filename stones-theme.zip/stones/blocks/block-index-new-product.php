<div class="products has-shadow">
    <div class="container">
        <div class="header-section">
                <span class="title kalameh">
                      <?php block_field('title') ?>
                </span>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </div>
        <div class="slider-container">
            <div class="swiper-container swiper-p1">
                <div class="swiper-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'product',
                        'posts_per_page' => 9,
                    );
                    $the_query = new WP_Query($args);

                    // The Loop
                    if ($the_query->have_posts()) {

                        while ($the_query->have_posts()) {
                            $the_query->the_post();
                            $postthumbid = get_post_thumbnail_id();
                            $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
                            $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);

                            ?>
                            <a href="<?php echo get_the_permalink() ?>" class="swiper-slide item">
                                <img src="<?php echo $postthumburl ?>" alt="<?php echo $image_alt ?>">
                                <span class="title">
                                 <?php echo get_the_title() ?>
                                </span>
                                <?php $tags = get_the_terms(get_the_ID(), 'colection');
                                if (!empty($tags) && $tags) {
                                    foreach ($tags as $tax) {
                                        ?>
                                        <span class="subtitle kalameh">
                                       <?php if (!empty($tax->name) && $tax->name) {
                                           echo $tax->name;
                                       }
                                       ?>
                                     </span>

                                    <?php }
                                } ?>


                            </a>
                            <?php
                        }

                    } else {
                        echo " لطفا ووکامرس را نصب و محصولات را وارد نماید ";
                    }

                    wp_reset_postdata();


                    ?>

                </div>
            </div>
            <div class="button-nav next swiper-button-next-p1 d-lg-none">
                <i class="icon-left"></i>
            </div>
            <div class="button-nav prev swiper-button-prev-p1 d-lg-none">
                <i class="icon-right"></i>
            </div>
        </div>

    </div>
</div>