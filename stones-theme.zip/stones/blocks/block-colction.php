<?php
$term_id = block_value('term');
$category = get_term_by('id', $term_id, 'colection');

?>
<!--START-PRODUCTS-->
<div class="products">
    <div class="container">
        <div class="header-section">
                <span class="title kalameh">
                    <?php echo $category->name ?>
    گالــری تهرانــی
                </span>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </div>
        <?php
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 9 ,
//            'product_tag' => $term_id,
            'tax_query' => array(
                array(
                    'taxonomy' => 'colection',
                    'field'    => 'term_id',
                    'terms'    => $term_id,

                ),
            ),
        );
        $the_query = new WP_Query($args);


        if ($the_query->have_posts()) {
            ?>
            <div class="slider-container">
                <div class="swiper-container swiper-p2">
                    <div class="swiper-wrapper">
                        <?php
                        while ($the_query->have_posts()) {
                            $the_query->the_post();
                            $postthumbid = get_post_thumbnail_id();
                            $postthumburl = wp_get_attachment_image_url($postthumbid, 'full');
                            $image_alt = get_post_meta($postthumbid, '_wp_attachment_image_alt', TRUE);
                            $newseles = get_post_meta(get_the_ID(), '_sale_price', true);
                            ?>
                            <a href="<?php echo get_the_permalink()?>" class="swiper-slide item">
                                <?php if (!empty($newseles)) : ?>
                                    <span class="label">
                                                 فـــروش ویـــژه
                                    </span>
                                <?php endif; ?>
                                <img src="<?php echo $postthumburl?>" alt="<?php echo $image_alt ?>">
                                <span class="title">
                                      <?php echo get_the_title()?>
                                </span>
                                <span class="subtitle kalameh">


                                                <?php echo !empty($newseles) ? number_format($newseles, 0, ',', ',') : number_format(get_post_meta(get_the_ID(), '_regular_price', true), 0, ',', ',') ?>
                                    <?php echo get_woocommerce_currency_symbol() ?>
                                            </span>
                                <span class="subtitle kalameh">

                        </span>
                            </a>
                            <?php

                        }
                        ?>
                    </div>
                </div>
                <div class="button-nav next swiper-button-next-p2">
                    <i class="icon-left"></i>
                </div>
                <div class="button-nav prev swiper-button-prev-p2">
                    <i class="icon-right"></i>
                </div>
            </div>
            <?php
        } else {

        }

        wp_reset_postdata();
        ?>

    </div>
</div>
<!--END-PRODUCTS-->