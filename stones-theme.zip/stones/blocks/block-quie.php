<span class="title-blog">
                    <i class="<?php echo block_field('icon-class') ?>"></i>
                  <?php echo block_field('text') ?>
</span>
