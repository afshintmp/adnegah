<div class="lines">
    <div class="line"></div>
    <div class="line"></div>
    <div class="line"></div>
</div>