<div class="map">
    <iframe src="<?php block_field("url") ?>" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    <ul class="nav nav-map">
        <li class="nav-item">
            <a href="" class="nav-link">
                <i class="icon-waze"></i>
            </a>
        </li>
        <li class="nav-item">
            <a href="" class="nav-link">
                <i class="icon-google-maps"></i>
            </a>
        </li>
    </ul>
</div>