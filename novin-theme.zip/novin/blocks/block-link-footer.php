<span class="title">
                                    <span class="lines">
                                        <span class="line"></span>
                                        <span class="line"></span>
                                    </span>

          <?php block_field( 'tt' ); ?>

                                </span>

<?php
wp_nav_menu( array(
	'theme_location' => 'footer_3',
	'container'      => "ul",
	'menu_class'     => "nav nav-menu"
) );
?>