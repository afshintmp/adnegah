<?php
$args = array('post_type' => 'our-team',);
$the_query = new WP_Query($args); ?>

<?php if ($the_query->have_posts()) : ?>
    <div class="our-team">
        <div class="container">
      <span class="title">
        <span class="line before-line"></span>
        <b class="kalameh"><?php block_field("tt") ?></b>
<?php block_field("sub-tt") ?>
        <span class="line after-line"></span>
      </span>
            <div class="swiper-container swiper-team">
                <div class="swiper-wrapper">

                    <?php while ($the_query->have_posts()) : $the_query->the_post();
                        $job_tt = get_post_meta($post->ID, 'job-tt', true);
                        $inst = get_post_meta($post->ID, 'inst', true);
                        $twit = get_post_meta($post->ID, 'twit', true);
                        $rez = get_post_meta($post->ID, 'rez', true);
                        $image_id = get_post_thumbnail_id(get_the_ID());
                        $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);
                        ?>


                        <div class="swiper-slide item">
                            <div class="img">
                                <img src="<?php echo wp_get_attachment_url($image_id) ?>"
                                     alt="<?php echo $image_alt ?>">
                                <article>
                <span class="name kalameh">
               <?php echo get_the_title() ?>
                </span>
                                    <span class="sub-name">
              <?php echo $job_tt ?>
                </span>
                                </article>
                            </div>
                            <div class="bottom-bar">
                                <ul class="nav">
                                    <?php if (!empty($inst)) : ?>
                                        <li class="nav-item">
                                            <a href="<?= $inst ?>" class="nav-link">
                                                <i class="icon-instagram1"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if (!empty($twit)) : ?>
                                        <li class="nav-item">
                                            <a href="<?= $twit ?>" class="nav-link">
                                                <i class="icon-twitter"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>


                                </ul>
                                <?php if (!empty($rez)) : ?>
                                    <a href="<?= $rez ?>" class="btn">
                                        <i class="icon-money-transfer"></i>
                                        رزومـــه
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>


                    <?php endwhile; ?>

                </div>
                <div class="btn-nav next swiper-button-next-team">
                    <i class="icon-left-chevron"></i>
                </div>
                <div class="btn-nav prev swiper-button-prev-team">
                    <i class="icon-right-chevron"></i>
                </div>
            </div>
        </div>
    </div>
    <?php wp_reset_postdata(); ?>

<?php else : ?>

<?php endif; ?>
