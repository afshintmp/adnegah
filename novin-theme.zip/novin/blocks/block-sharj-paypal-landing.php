<!--START-LAN-1-->
<div class="lan-1">
    <div class="container p-0 d-flex flex-wrap align-items-center">
        <div class="col-lg-6">
            <div class="img">
                <img src="<?php block_field("pic") ?>" alt="<?php block_field("alt-text") ?>">
            </div>
        </div>
        <div class="col-lg-6 mr-auto">
                <span class="title kalameh">
                    <?php block_field("tt") ?>
                </span>
            <span class="subtitle">
                 <?php block_field("sub-tt") ?>

                </span>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
            </div>
            <div class="text">
              <?php block_field("text") ?>
            </div>
            <ul class="nav">
              <?php block_field("list") ?>

            </ul>
            <a href="<?php block_field("btn-link") ?>" class="more">
                <?php block_field("btn-text") ?>
                <span class="icon">
                        <i class="icon-left-arrow"></i>
                    </span>
            </a>
        </div>

    </div>
</div>
<!--END-LAN-1-->
