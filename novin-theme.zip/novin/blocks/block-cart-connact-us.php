<div class="box">
    <?php if (!empty(block_value("tt-1"))) : ?>
    <div class="item">
        <i class="<?php block_field("icon-1") ?>">

        </i>
        <div class="has-ml">
            <b class="kalameh">
                <?php block_field("tt-1") ?>
            </b>
            <?php block_field("sub-tt-1") ?>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty(block_value("tt-1-1"))) : ?>
    <div class="item">
        <i class="<?php block_field("icon-1-1") ?>">

        </i>
        <div class="has-ml">
            <b class="kalameh">
                <?php block_field("tt-1-1") ?>
            </b>
            <?php block_field("sub-tt-1-1") ?>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty(block_value("tt-1-2"))) : ?>
        <div class="item">
            <i class="<?php block_field("icon-1-2") ?>">

            </i>
            <div class="has-ml">
                <b class="kalameh">
                    <?php block_field("tt-1-2") ?>
                </b>
                <?php block_field("sub-tt-1-2") ?>
            </div>
        </div>
    <?php endif; ?>
</div>