<ul class="accordion-menu">
	<li class="item-accordion">
		<a href="#" class="dropdownlink" onclick="return false">
                            <span class="icon plus">
                                +
                            </span>
			<span class="icon minus">
                                -
                            </span>
			<?php block_field( "tt", $echo = true ); ?>
		</a>
		<div class="submenu">
			<?php block_field( "txy", $echo = true ); ?>
		</div>
	</li>
</ul>