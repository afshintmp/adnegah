<div class="video-bar">
	<img src="<?php block_field( " pic", $echo = true ); ?>" alt="<?php block_field( "tt", $echo = true ); ?>">
	<div class="bar play-vid" onclick="playVid1()">
		<div class="circle">
			<i class="icon-play1"></i>
		</div>
		<span>
                             <?php block_field( "tt", $echo = true ); ?>
                                <b>
                                   <?php block_field( "sub-tt", $echo = true ); ?>
                                </b>
                            </span>
	</div>
	<div class="main-video">

		<video src="<?php block_field( "vid-link", $echo = true ); ?>" id="video1"
		       controls
		       preload="none">
		</video>
		<div class="btn btn-close" onclick="pauseVid1()">
			<i class="icon-close"></i>
		</div>
	</div>
</div>

<script>
    var vid1 = document.getElementById("video1");
    function playVid1() {vid1.play()}
    function pauseVid1() {vid1.pause()}

    jQuery('.play-vid').click( function () {
        jQuery(this).parent().find('.main-video').show();
    })
    jQuery('.main-video .btn-close').click( function () {
        jQuery(this).parent().parent().find('.main-video').hide();
    })
</script>