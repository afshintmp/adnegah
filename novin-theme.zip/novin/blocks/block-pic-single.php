<?php
$counter       = 0;
$dynamic_class = "";
if ( block_value( "pic-1" ) ):
	$counter ++;
endif;
if ( block_value( "pic-2" ) ):
	$counter ++;
endif;

if ( $counter == 1 ):
	$dynamic_class = "col-md-12";
elseif ( $counter == 2 ):
	$dynamic_class = "col-md-6";
endif;


?>


<div class="row prl-5px">
	<?php if ( ! empty( block_value( "pic-1" ) ) ) : ?>
        <div class="<?php echo $dynamic_class ?> prl-10px">
            <div class="img">
                <img src="<?php block_field( "pic-1", $echo = true ); ?>"
                     alt="<?php block_field( "txt-1", $echo = true ); ?>">
            </div>
        </div>
	<?php endif; ?>
	<?php if ( ! empty( block_value( "pic-2" ) ) ) : ?>
        <div class="<?php echo $dynamic_class ?> prl-10px">
            <div class="img">
                <img src="<?php block_field( "pic-2", $echo = true ); ?>"
                     alt="<?php block_field( "txt-2", $echo = true ); ?>">
            </div>
        </div>
	<?php endif; ?>
   
</div>