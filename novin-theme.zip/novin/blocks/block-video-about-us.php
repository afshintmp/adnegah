<!--START-VIDEO-SECTION-->
<div class="video-section">
    <div class="container">
        <div class="main">
            <div class="img play-vid" style="background-image: url(<?php block_field("pic") ?>)" onclick="playVid1()">
                <article>
                    <button class="btn btn-video">
                        <i class="icon-play"></i>
                    </button>
                    <span class="title kalameh">
              <?php block_field("tt") ?>
            </span>
                    <span class="subtitle">
             <?php block_field("sub-tt") ?>
            </span>
                </article>
            </div>
            <div class="main-video">
                <video src="<?php block_field("video-link") ?>" id="video1"
                       controls
                       preload="none">
                </video>
                <div class="btn btn-close" onclick="pauseVid1()">
                    <i class="icon-close"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<!--END-VIDEO-SECTION-->
