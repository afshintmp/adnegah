<span class="title">
                    <span class="lines">
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                   <?php block_field( 'tt' ); ?>
                </span>
<div class="d-flex">

	<?php
	wp_nav_menu( array(
		'theme_location' => 'footer_1',
		'container'      => "ul",
		'menu_class'     => "nav nav-menu"
	) );
	?>
   <!-- <ul class="nav nav-menu">
		<li class="nav-item">
			<a href="" class="nav-link">
				صفحه نخست
			</a>
		</li>
		<li class="nav-item">
			<a href="" class="nav-link">
				درباره ما
			</a>
		</li>
		<li class="nav-item">
			<a href="" class="nav-link">
				قوانین و مقررات
			</a>
		</li>
		<li class="nav-item">
			<a href="" class="nav-link">
				وبلاگ
			</a>
		</li>
		<li class="nav-item">
			<a href="" class="nav-link">
				تماس با ما
			</a>
		</li>
	</ul>-->

	<?php
	wp_nav_menu( array(
		'theme_location' => 'footer_2',
		'container'      => "ul",
		'menu_class'     => "nav nav-menu"
	) );
	?>
  <!--  <ul class="nav nav-menu">
		<li class="nav-item">
			<a href="" class="nav-link">
				پرسش های متداول
			</a>
		</li>
		<li class="nav-item">
			<a href="" class="nav-link">
				راهنمای خرید
			</a>
		</li>
		<li class="nav-item">
			<a href="" class="nav-link">
				خدمات مشتریان
			</a>
		</li>
		<li class="nav-item">
			<a href="" class="nav-link">
				نحوه ثبت سفارش
			</a>
		</li>
		<li class="nav-item">
			<a href="" class="nav-link">
				احراز هویت
			</a>
		</li>
	</ul>-->


</div>