<span class="title">
                    <span class="lines">
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                    دریافت اپلیکیشن
                </span>
<p class="text">
	آسان ترین و سریع ترین و مطمئن‌ترین روش تهیه ارز  را با
	اپلیکیشن ما تجربه کنید. صرافی آنلاین در جیب شماست .
</p>
<ul class="nav nav-app">
	<li class="nav-item">
		<a href="" class="nav-link">
			Google
			<br>
			Play
			<i class="icon-playstore"></i>
		</a>
	</li>
	<li class="nav-item">
		<a href="" class="nav-link">
			Apple
			<br>
			Store
			<i class="icon-apple"></i>
		</a>
	</li>
</ul>