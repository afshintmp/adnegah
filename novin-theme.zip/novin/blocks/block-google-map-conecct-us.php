<div class="map">
    <iframe src="<?php block_field("url") ?>" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    <ul class="nav nav-map">
        <li class="nav-item">
            <a href="" class="nav-link">
                <i class="icon-waze"></i>
            </a>
        </li>
        <li class="nav-item">
            <a href="" class="nav-link">
                <i class="icon-google-maps"></i>
            </a>
        </li>
    </ul>
</div>
<!--<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d207372.70304860492!2d51.2097323426304!3d35.696732948857345!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3f8e00491ff3dcd9%3A0xf0b3697c567024bc!2sTehran%2C%20Tehran%20Province%2C%20Iran!5e0!3m2!1sen!2s!4v1643655678670!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>-->