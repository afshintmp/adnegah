<!--START-OUR-TESTIMONIAL-->
<div class="testimonial">
	<div class="container">
		<div class="header-section d-flex align-items-center justify-content-between">
			<div class="clear-fix"></div>
			<span class="title text-center kalameh">
                    <span class="lines before">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                   <?php block_field( "tt"); ?>
                    <span class="light">
                        <?php block_field( "sub-tt"); ?>
                    </span>
                    <span class="lines after">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                </span>
			<div class="clear-fix"></div>
		</div>
		<div class="swiper-container swiper-testimonial">
			<div class="swiper-wrapper">
				<?php if (!empty(  block_value( "txt-1") )) {
					?>
					<div class="swiper-slide item">
						<div class="name">
							<i class="icon-quotation"></i>
							<b><?php block_field( "nam-1"); ?></b>
							<?php block_field( "tt -1"); ?>
						</div>
						<div class="text">
							<?php block_field( "txt-1"); ?>
									</div>
					</div>

					<?php
				} ?>

				<?php if (!empty(  block_value( "txt-1-1") )) {
					?>
					<div class="swiper-slide item">
						<div class="name">
							<i class="icon-quotation"></i>
							<b><?php block_field( "nam-1-1"); ?></b>
							<?php block_field( "tt -1-1"); ?>
						</div>
						<div class="text">
							<?php block_field( "txt-1-1"); ?>
						</div>
					</div>

					<?php
				} ?>
				<?php if (!empty(  block_value( "txt-1-2") )) {
					?>
					<div class="swiper-slide item">
						<div class="name">
							<i class="icon-quotation"></i>
							<b><?php block_field( "nam-1-2"); ?></b>
							<?php block_field( "tt -1-2"); ?>
						</div>
						<div class="text">
							<?php block_field( "txt-1-2"); ?>
						</div>
					</div>

					<?php
				} ?>
				<?php if (!empty(  block_value( "txt-1-3") )) {
					?>
					<div class="swiper-slide item">
						<div class="name">
							<i class="icon-quotation"></i>
							<b><?php block_field( "nam-1-3"); ?></b>
							<?php block_field( "tt -1-3"); ?>
						</div>
						<div class="text">
							<?php block_field( "txt-1-3"); ?>
						</div>
					</div>

					<?php
				} ?>
				<?php if (!empty(  block_value( "txt-1-4") )) {
					?>
					<div class="swiper-slide item">
						<div class="name">
							<i class="icon-quotation"></i>
							<b><?php block_field( "nam-1-4"); ?></b>
							<?php block_field( "tt -1-4"); ?>
						</div>
						<div class="text">
							<?php block_field( "txt-1-4"); ?>
						</div>
					</div>

					<?php
				} ?>
				<?php if (!empty(  block_value( "txt-1-5") )) {
					?>
					<div class="swiper-slide item">
						<div class="name">
							<i class="icon-quotation"></i>
							<b><?php block_field( "nam-1-5"); ?></b>
							<?php block_field( "tt -1-5"); ?>
						</div>
						<div class="text">
							<?php block_field( "txt-1-5"); ?>
						</div>
					</div>

					<?php
				} ?>

			</div>
		</div>
		<div class="pagination swiper-pagination-testimonial"></div>
	</div>
</div>
<!--END-OUR-TESTIMONIAL-->