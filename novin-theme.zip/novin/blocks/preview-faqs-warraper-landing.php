<div style="width: 100%">
    <img src="<?php echo DU .'/assets/img/block-faqs-warraper-landing.jpg' ?>" alt="">
</div>