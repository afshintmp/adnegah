<!---START-OUR-SERVICES-->
<div class="our-services">
	<div class="container">
		<div class="header-section d-flex align-items-center justify-content-between">
			<div class="clear-fix"></div>
			<span class="title text-center kalameh">
                    <span class="lines before">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                    <?php block_field( "tt" ); ?>
                    <span class="light">
                        <?php block_field( "sub-tt" ); ?>
                    </span>
                    <span class="lines after">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                </span>
			<div class="clear-fix"></div>
		</div>
		<div class="text">
			<?php block_field( "txt" ); ?>	</div>
		<div class="row prl-5px">
			<div class="col-lg-4 col-md-6 col-12 prl-10px">
				<div class="item">
					<div class="icon">
						<i class="<?php block_field( "icon-1" ); ?>"></i>
					</div>
					<span class="title kalameh">
                            <?php block_field( "tt -1" ); ?>
                        </span>
					<span class="subtitle">
                            <?php block_field( "sub-tt -1" ); ?>
                        </span>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-12 prl-10px">
				<div class="item">
					<div class="icon">
						<i class="<?php block_field( "icon-1-1" ); ?>"></i>
					</div>
					<span class="title kalameh">
                            <?php block_field( "tt -1-1" ); ?>
                        </span>
					<span class="subtitle">
                            <?php block_field( "sub-tt -1-1" ); ?>
                        </span>
				</div>
			</div>
			<div class="col-lg-4 col-12 prl-10px">
				<div class="item">
					<div class="icon">
						<i class="<?php block_field( "icon-1-2" ); ?>"></i>
					</div>
					<span class="title kalameh">
                            <?php block_field( "tt -1-2" ); ?>
                        </span>
					<span class="subtitle">
                            <?php block_field( "sub-tt -1-2" ); ?>
                        </span>
				</div>
			</div>
		</div>
	</div>
</div>
<!--END-OUR-SERVICES-->