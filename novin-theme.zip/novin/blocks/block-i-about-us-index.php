<div class="i-about-us">
	<img src="<?php echo DU .'/' ?>assets/img/shape.png" class="shape" alt="">
	<div class="bg">
		<div class="container p-0 d-flex align-items-end flex-wrap">
			<div class="col-lg-6 d-none d-lg-block">
				<img src="<?php echo DU .'/' ?>assets/img/i-about-us.png" alt="" class="img">
			</div>
			<div class="col-lg-6">
				<ul class="nav nav-tab">
					<li class="nav-item tab-item-1 active" data-filter="one">
						<?php block_field( 'sub-tt-1' ); ?>
					</li>
					<li class="nav-item tab-item-1" data-filter="two">
						<?php block_field( 'sub-tt-1-1' ); ?>
					</li>
				</ul>
				<span class="title kalameh filter-item-1 one">
                        <?php block_field( 'tt-1' ); ?>
                    </span>
				<span class="title kalameh filter-item-1 two" style="display: none">
                        <?php block_field( 'tt-1-1' ); ?>
                    </span>
			</div>
			<div class="col-12">
				<div class="box filter-item-1 one">
					<div class="text">
						<?php block_field( 'txt-1' ); ?>		</div>
					<div class="more show-more-text">
						<i class="icon-down-chevron"></i>
						<span>
                                مشــاهده کامــل توضیحــات
                            </span>
						<span style="display: none">
                                مشــاهده کمتر توضیحــات
                            </span>
					</div>
				</div>
				<div class="box filter-item-1 two" style="display: none">
					<div class="text">
						<?php block_field( 'txt-1-1' ); ?>		</div>
					<div class="more show-more-text">
						<i class="icon-down-chevron"></i>
						<span>
                                مشــاهده کامــل توضیحــات
                            </span>
						<span style="display: none">
                                مشــاهده کمتر توضیحــات
                            </span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>