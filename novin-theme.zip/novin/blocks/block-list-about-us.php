<li class="nav-item">
    <div class="icon">
        <i class="icon-tick"></i>
    </div>
    <?php block_field("text") ?>
</li>