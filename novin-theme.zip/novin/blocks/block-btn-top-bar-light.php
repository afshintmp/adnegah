<li class="nav-item">
    <a href="<?php block_field("btn-link") ?>" class="nav-link">
        <i class="<?php block_field("icon") ?>"></i>
        <span class="d-none d-lg-block">
                            <?php block_field("btn-txt") ?>
                        </span>
    </a>
</li>