<div class="social-bar">
    <div class="container d-flex align-items-center justify-content-between flex-wrap">
		<?php if ( ! empty( block_value( 'pho' ) ) ) : ?>
            <a href="tel:<?php block_field( 'pho' ); ?>" class="title-column">
                <i class="icon-phone-call"></i>
                <span>
                <span class="number">
                   <?php block_field( 'pho' ); ?>
                </span>
                    <?php block_field( 'pho -txt' ); ?>
            </span>
            </a>
		<?php endif; ?>
        <ul class="nav nav-social nav-social-footer">
	        <?php if ( ! empty( block_value( 'inst' ) ) ) : ?>
            <li class="nav-item active">
                <a href="<?php block_field( 'inst' ); ?>" class="nav-link">
                        <span>
<?php block_field( 'inst -txt' ); ?>
                        </span>
                    <div class="icon">
                        <i class="icon-instagram"></i>
                    </div>
                </a>
            </li>
            <?php endif;
	        if ( ! empty( block_value( 'tel' ) ) ) : ?>
            <li class="nav-item">
                <a href="<?php block_field( 'tel' ); ?>" class="nav-link">
                        <span>
<?php block_field( 'tel -txt' ); ?>
                        </span>
                    <div class="icon">
                        <i class="icon-telegram"></i>
                    </div>
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</div>