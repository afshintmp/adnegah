<ul class="nav nav-social">
    <?php if (!empty(block_value('instagram'))) : ?>
    <li class="nav-item instagram">
        <a href="<?php block_field('instagram') ?>" class="nav-link">
            <i class="icon-instagram1"></i>
        </a>
    </li>
    <?php endif; ?>
    <?php if (!empty(block_value('telegram'))) : ?>
    <li class="nav-item telegram">
        <a href="<?php block_field('telegram') ?>" class="nav-link">
            <i class="icon-telegram1"></i>
        </a>
    </li>
    <?php endif; ?>
    <?php if (!empty(block_value('youtube'))) : ?>
    <li class="nav-item youtube">
        <a href="<?php block_field('youtube') ?>" class="nav-link">
            <i class="icon-youtube"></i>
        </a>
    </li>
    <?php endif; ?>
    <?php if (!empty(block_value('linkedin'))) : ?>
    <li class="nav-item linkedin">
        <a href="<?php block_field('linkedin') ?>" class="nav-link">
            <i class="icon-linkedin"></i>
        </a>
    </li>
    <?php endif; ?>
</ul>