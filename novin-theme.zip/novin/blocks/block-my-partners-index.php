<!--START-OUR-BRANDS-->

<?php

$args = array(
	"post_type" => "companies"

);


$the_query = new WP_Query( $args );

$i = 1;
if ( $the_query->have_posts() ) {
	?>
    <div class="brands">
        <div class="swiper-container swiper-brands">
            <div class="swiper-wrapper"><?php
				while ( $the_query->have_posts() ) {
					$the_query->the_post();
					$companies_url = get_post_meta( $post->ID, 'companies-url', true );
					$image_url = wp_get_attachment_image_url( get_post_thumbnail_id(get_the_ID()) );
					$image_alt = get_post_meta( get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true );

					?>
                    <a href="<?php echo $companies_url ?>" class="swiper-slide item">
                        <img src="<?php echo $image_url ?>" alt="<?php echo $image_alt ?>">
                    </a>
					<?php
				}
				?>

            </div>
        </div>
    </div>
    <!--END-OUR-BRANDS-->
	<?php
} else {

} ?>



