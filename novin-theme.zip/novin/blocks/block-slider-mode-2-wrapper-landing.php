<!--START-LAN-4-->
<div class="lan-4">
    <div class="container">
        <div class="header-section-lan">
                <span class="title kalameh">
                    <?php block_field("tt") ?>
                </span>
            <span class="subtitle">
                    <?php block_field("sub-tt") ?>
                </span>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </div>

        <div class="slider-container">
            <div class="swiper-container swiper-lan-3">
                <div class="swiper-wrapper">

                 <?php block_field("wrapper") ?>


                </div>
            </div>
            <div class="btn-nav next swiper-button-next-lan-3">
                <i class="icon-left-chevron"></i>
            </div>
            <div class="btn-nav prev swiper-button-prev-lan-3">
                <i class="icon-right-chevron"></i>
            </div>
        </div>

    </div>
</div>
<!--END-LAN-4-->
