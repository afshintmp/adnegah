<?php
$slide = array();
$args  = array(
	"post_type" => "services"

);


$the_query = new WP_Query( $args );

$i = 1;
if ( $the_query->have_posts() ) {

	while ( $the_query->have_posts() ) {
		$the_query->the_post();
		$tt        = get_post_meta( $post->ID, 'tt', true );
		$sub_tt    = get_post_meta( $post->ID, 'sub-tt', true );
		$tt_icon   = get_post_meta( $post->ID, 'tt-icon', true );
		$btn_txt   = get_post_meta( $post->ID, 'btn-txt', true );
		$btn_link  = get_post_meta( $post->ID, 'btn-link', true );
		$class     = "";
		$image_url = wp_get_attachment_image_url( get_post_thumbnail_id(get_the_ID()) );
		$image_alt = get_post_meta( get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true );
		if ( empty( $btn_link ) ) {
			$btn_link = get_the_permalink();
		}
		if ( $i == 1 ) {
			$class = "active";
		}
		$slide[ get_the_ID() ]['head-tab'] = '<li class="nav-item tab-item-2 ' . $class . '" data-filter="' . get_the_ID() . '">
                <i class="' . $tt_icon . '"></i>
                <span>
                        ' . $tt . '
                    </span>
            </li>';
		$slide[ get_the_ID() ]['tab']      = '<div class="swiper-slide item filter-item-2 ' . get_the_ID() . '">
            <div class="img">
                <img src="' . $image_url . '" alt="' . $image_alt . '">
            </div>
            <article>
                <h2 class="title">
                    <b class="kalameh"> ' . get_the_title() . '
                   
                    </b>
                  ' . $sub_tt . '
                </h2>
                <div class="text">
                    ' . get_the_content() . '
                         </div>
                <a href="' . $btn_link . '" class="more">
                   ' . $btn_txt . '
                    <i class="icon-left-arrow"></i>
                </a>
            </article>
        </div>';

		$i ++;
	}

} else {

}

wp_reset_postdata();
?>
<!--START-TAB-SECTION-->
<div class="tab-section">
    <div class="container">
        <ul class="nav nav-tab">
			<?php foreach ( $slide as $s ) :
				echo $s["head-tab"];
			endforeach; ?>

        </ul>
        <div class="slider-container">
            <div class="swiper-container swiper-tab">
                <div class="swiper-wrapper">
					<?php foreach ( $slide as $s ) :
						echo $s['tab'];
					endforeach; ?>

           
                </div>
            </div>
            <div class="btn-nav next swiper-button-next-tab">
                <i class="icon-left"></i>
            </div>
            <div class="btn-nav prev swiper-button-prev-tab">
                <i class="icon-right"></i>
            </div>
        </div>
    </div>
</div>
<!--END-TAB-SECTION-->