<div class="about-us">
    <div class="container p-0 d-flex flex-wrap">
        <div class="col-12">
            <div class="text center-theme">
            <?php block_field("text") ?>
            </div>
        </div>
    </div>
</div>