<!--START-HOW-START-->
<div class="how-start">
	<div class="container p-0 d-flex flex-wrap">
		<div class="col-lg-6">
			<h4 class="title">
				<b class="kalameh"><?php block_field( 'tt' ); ?></b>
				<?php block_field( 'sub-tt' ); ?>
				<span class="lines">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
			</h4>
			<div class="text">
				<?php block_field( ' txt' ); ?>	</div>
			<a href="<?php block_field( 'brn-link' ); ?>" class="more">
				<?php block_field( 'btn-txt' ); ?>
				<i class="icon-left-arrow"></i>
			</a>
		</div>
		<div class="col-lg-6 d-lg-block d-none">
			<img src="<?php block_field( 'pic' ); ?>" alt="<?php block_field( 'alt-txt' ); ?>">
		</div>
	</div>
</div>
<!--END-HOW-START-->