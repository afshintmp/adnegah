<div class="lan-1">
    <div class="container p-0 d-flex flex-wrap align-items-center">
        <div class="col-12">
            <div class="text has-mt mb-0">
            <?php block_field("text") ?>
            </div>
        </div>
    </div>
</div>