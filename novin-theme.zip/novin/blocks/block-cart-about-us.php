<div class="col-lg-6 prl-10px">
    <div class="item">
        <div class="icon">
            <i class="<?php block_field("icon") ?>"></i>
        </div>
        <article>
            <span class="title">
              <b class="kalameh"><?php block_field("tt") ?></b>
<?php block_field("sub-tt") ?>
            </span>
            <div class="text">
                <?php block_field("text") ?>
            </div>
        </article>
    </div>
</div>