<?php
$response = wp_remote_get('https://panel.novinpardakht.com/api/v1/currencies');
$body = json_decode(wp_remote_retrieve_body($response));


//https://panel.novinpardakht.com/

?>
<div class="crypto-list">
    <div class="container">
        <div class="sort">
            نمایش بازار بر اساس
            <ul class="nav">
                <li class="nav-item tab-item active" data-filter="one">
                    تومان TMN
                </li>
                <li class="nav-item tab-item" data-filter="two">
                    تتر USDT
                </li>
                <li class="nav-item tab-item" data-filter="three">
                    بیت کوین BTC
                </li>
            </ul>
        </div>
        <table style="border-collapse:collapse;" cellspacing="0" cellpadding="0" border=0>
            <thead>
            <tr>
                <th>
                    <div class="th">
                        رمز ارز
                    </div>
                </th>
                <th>
                    <div class="th text-center">
                        آخرین قیمت
                    </div>
                </th>
                <th class="d-none d-lg-table-cell">
                    <div class="th text-center">
                        تغییرات
                    </div>
                </th>
                <th class="d-none d-lg-table-cell">
                    <div class="th text-center">
                        بیشترین قیمت(24h)
                    </div>
                </th>
                <th class="d-none d-lg-table-cell">
                    <div class="th text-center">
                        کمترین قیمت(24h)
                    </div>
                </th>
                <th>
                    <div class="th"></div>
                </th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($body  as $bo):
            ?>
            <tr>
                <td>
                    <div class="td d-flex align-items-sm-center flex-sm-row flex-column align-items-start">
                        <img src="<?php echo 'https://panel.novinpardakht.com' . $bo->icon ?>" alt="">
                        <span>
                                  <?php echo $bo->name ?>
                                    <br>
                                   <?php echo $bo->abbreviation ?>
                                </span>
                    </div>
                </td>
                <td>
                    <div class="td d-flex align-items-center justify-content-center">
                            <span class="filter-item one">
                                <?php echo $bo->price ?>
                            </span>
                        <span class="filter-item two" style="display: none">
                                50,000
                            </span>
                        <span class="filter-item three" style="display: none">
                                1
                            </span>
                    </div>
                </td>
                <td class="d-none d-lg-table-cell">


                    <?php if ($bo->changes === "down"):
                        ?>
                        <div class="td red-theme d-flex justify-content-center align-items-center">
                            <?php echo number_format($bo->rate, 2) ?>
                            <i class="icon-down"></i>
                        </div>
                    <?php
                    else: ?>
                        <div class="td green-theme d-flex justify-content-center align-items-center">
                            <?php echo number_format($bo->rate, 2) ?>
                            <i class="icon-up"></i>
                        </div>
                    <?php
                    endif;
                    ?>


    </div>
    </td>
    <td class="d-none d-lg-table-cell">
        <div class="td d-flex align-items-center justify-content-center">

                            <span class="filter-item one">
                                 1,748,499,000
                            </span>
            <span class="filter-item two" style="display: none">
                                50,000
                            </span>
            <span class="filter-item three" style="display: none">
                                1
                            </span>
        </div>
    </td>
    <td class="d-none d-lg-table-cell">
        <div class="td d-flex align-items-center justify-content-center">
                            <span class="filter-item one">
                                 1,652,000,002
                            </span>
            <span class="filter-item two" style="display: none">
                                50,000
                            </span>
            <span class="filter-item three" style="display: none">
                                1
                            </span>
        </div>

    </td>
    <td>
        <div class="td d-flex align-items-center">
            <a href="" class="more">
                معامله کنید
            </a>
        </div>
    </td>
    </tr>
    <?php

    endforeach;
    ?>


    </tbody>
    </table>
</div>
</div>
