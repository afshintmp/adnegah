<!--START-OTHER-BLOG-->
<div class="b-other-blog">
    <div class="container">
        <div class="header-section-blog">
                <span class="title kalameh">
        <?php block_field("tt") ?>
                </span>
            <a href="<?php echo get_home_url() . '/blog' ?>" class="more gray-theme">
                مشاهده آرشیو
                <span class="icon">
                        <i class="icon-folder"></i>
                    </span>
            </a>
        </div>
        <div class="row prl-10px">
            <?php
            $args = array(
                'post_per_page' => 4,
                'post_type' => 'post',

            );

            $the_query = new WP_Query($args);
            ?>
            <?php

            if ($the_query->have_posts()) {

                while ($the_query->have_posts()) {
                    $the_query->the_post();
                    $image_id = get_post_thumbnail_id(get_the_ID());
                    $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);
                    $jobfinder_post_time = get_post_meta($post->ID, 'jobfinder-post-time', true);
                    ?>
                    <div class="col-lg-12 col-md-6 prl-5px">
                        <div class="item">
                            <img src="<?php echo wp_get_attachment_url($image_id) ?>"
                                 alt="<?php echo $image_alt ?>">
                            <article>
                                <h3 class="title">
                                    <?php echo get_the_title() ?>
                                </h3>
                                <p class="text">
                                    <?php echo get_the_excerpt() ?>
                                </p>
                                <div class="bottom-bar d-flex align-items-center">
                                    <ul class="nav nav-info">
                                        <?php $terms = wp_get_post_terms(get_the_ID(), "category");
                                        if (!empty($terms)) :
                                            ?>
                                            <li class="nav-item">
                                                <b>
                                                    دسته بندی
                                                </b>
                                                <?php echo $terms[0]->name ?>
                                            </li>
                                        <?php endif; ?>
                                        <li class="nav-item">
                                            <b>
                                                انتشار در تاریخ
                                            </b>
                                            <?php echo get_the_date('d F Y', get_the_ID()); ?>
                                        </li>
                                    </ul>
                                    <?php if (!empty($jobfinder_post_time)) : ?>
                                        <span class="btn btn-time">
                            زمان مطالعه
                                            <?php echo $jobfinder_post_time?>
                                            دقیقه
                        </span>
                                    <?php endif; ?>

                                    <a href="<?php echo get_the_permalink() ?>" class="btn btn-more">
                                        ادامه مطلب
                                    </a>
                                </div>
                            </article>
                        </div>
                    </div>
                    <?php
                }

            } else {

            }

            wp_reset_postdata();
            ?>

        </div>
    </div>
</div>
<!--END-OTHER-BLOG-->