<?php
$args = array(
	"posts_per_page" => 6,
	"post_type"      => "post"
);

$the_query = new WP_Query( $args );


if ( $the_query->have_posts() ) {
	?>

    <!--START-ARTICLES-->
    <div class="articles">
        <div class="container">
            <div class="header-section d-flex align-items-center justify-content-between">
                <a href="<?php block_field('link') ?>" class="see-all">
                    مشاهده آرشیو
                </a>
                <span class="title kalameh">
                    <span class="lines before">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                   <?php block_field( "tt" ); ?>
                    <span class="lines after">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                </span>
                <div class="swiper-pagination swiper-pagination-articles"></div>
            </div>
            <div class="swiper-container swiper-articles">
                <div class="swiper-wrapper">

					<?php


					while ( $the_query->have_posts() ) {
						$the_query->the_post();
						$image_url = wp_get_attachment_image_url( get_post_thumbnail_id( get_the_ID() ) );
						$image_alt = get_post_meta( get_post_thumbnail_id( get_the_ID() ), '_wp_attachment_image_alt', true );

						?>
                        <a href="<?php echo get_the_permalink() ?>" class="swiper-slide item">
                            <div class="img">
                                <img src="<?php echo $image_url ?>" alt="<?php echo $image_alt ?>">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <i class="icon-heart"></i>
										<?php
										$new_view = get_post_meta( get_the_ID(), "view", true );
										if ( empty( $new_view ) ) {
											$new_view = 0;
										}
										echo $new_view; ?> بازدید

                                    </li>
                                    <li class="nav-item">
                                        <i class="icon-chat"></i>
										<?php echo get_comments_number() ?>
                                        نظر
                                    </li>
                                </ul>
                            </div>
                            <article>
                            <span class="info">
                                <b>دسته بندی</b>
                             <?php $cat = wp_get_post_terms( get_the_ID(), "category" ) ?>
	                            <?php echo ! empty( $cat ) ? ' . ' . $cat[0]->name : " " ?>
                                <br class="d-none d-lg-block d-xl-none">
                                <b>در تاریخ</b>
                                   <?php echo get_the_date( 'd F Y', get_the_ID() ); ?>
                            </span>
                                <span class="title">
                                    <?php echo get_the_title() ?>
                            </span>
                                <p class="text">
									<?php echo get_the_excerpt() ?>
                                </p>
                                <div class="more">
                                    ادامه مطلب
                                </div>
                            </article>
                        </a>

						<?php
					}
					?>
                </div>
            </div>
        </div>
    </div>
    <!--END-ARTICLES-->

	<?php

} else {

}

wp_reset_postdata(); ?>


