<section class="text">
                <div class="position-relative">

                    <?php block_field( 'txt' ); ?>
                </div>
    <span class="lines">
                    <span class="line"></span>
                    <span class="line"></span>
                </span>
</section>