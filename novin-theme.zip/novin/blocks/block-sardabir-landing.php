<!--START-BLOG-ARCHIVE-->
<div class="b-blog-archive">
    <div class="container">
        <div class="header-section-blog">
                <span class="title kalameh">
                    <?php block_field('tt') ?>
                </span>
            <a href="<?php echo get_home_url() .'/blog' ?>" class="more gray-theme">
                مشاهده آرشیو
                <span class="icon">
                        <i class="icon-folder"></i>
                    </span>
            </a>
        </div>
        <div class="slider-container position-relative">
            <div class="swiper-container swiper-blog-1">
                <div class="swiper-wrapper">

                    <?php
                    $args = array(
                        "post_type" => "post",
                        'meta_query' => array(
                            array(
                                'key' => 'jobfinder-post-selected',
                                'value' => 'on',
                                'compare' => 'LIKE',
                            ),
                        ),
                    );


                    $the_query = new WP_Query($args); ?>

                    <?php if ($the_query->have_posts()) : ?>

                        <?php
                        while ($the_query->have_posts()) : $the_query->the_post();
                            $image_id = get_post_thumbnail_id(get_the_ID());
                            $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);
                            $jobfinder_post_time = get_post_meta($post->ID, 'jobfinder-post-time', true);

                            ?>


                            <a href="<?php echo get_the_permalink() ?>" class="swiper-slide item">
                                <img src="<?php echo wp_get_attachment_url($image_id) ?>"
                                     alt="<?php echo $image_alt ?>">
                                <article>
                            <span class="subtitle">
                                <?php $terms = wp_get_post_terms(get_the_ID(), "category");
                                echo $terms[0]->name
                                ?>
                                /
<?php echo get_the_date('d F Y', get_the_ID()); ?>


                            </span>
                                    <h3 class="title">
                                        <?php echo get_the_title() ?>
                                    </h3>
                                    <p class="text">
                                        <?php echo get_the_excerpt() ?>
                                    </p>
                                </article>
                            </a>

                        <?php endwhile; ?>

                        <?php wp_reset_postdata(); ?>

                    <?php else : ?>

                    <?php endif; ?>

                </div>
            </div>
            <div class="swiper-button-next swiper-button-next-blog-1">
                <i class="icon-left"></i>
            </div>
            <div class="swiper-button-prev swiper-button-prev-blog-1">
                <i class="icon-right"></i>
            </div>
        </div>
    </div>
</div>
<!--END-BLOG-ARCHIVE-->