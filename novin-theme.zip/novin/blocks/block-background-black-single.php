<div class="quote-box">
    <b><?php block_field( " tt", $echo = true ); ?></b>
	<?php block_field( "txt", $echo = true ); ?>
</div>

