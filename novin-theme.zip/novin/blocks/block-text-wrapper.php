<!--START-LAN-5-->
<div class="lan-5">
    <div class="container">
        <div class="box">
                <span class="title kalameh">
                    <i class="<?php block_field("iccon") ?>"></i>
                  <?php block_field("tt") ?>
                </span>
            <div class="scroll">
                <div class="text">
                    <?php block_field("txt") ?>     </div>
            </div>
        </div>
    </div>
</div>
<!--END-LAN-5-->