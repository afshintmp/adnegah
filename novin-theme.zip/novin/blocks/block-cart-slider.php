<div class="swiper-slide item">
    <div class="icon">
        <i class="<?php block_field("icon") ?>"></i>
    </div>
    <span class="title kalameh">
                         <?php block_field("tt") ?>
                        </span>
    <span class="subtitle">
                         <?php block_field("sub-tt") ?>
                        </span>
</div>