<!--START-MAIN-SLIDE-->
<div class="main-slide" style="background-image: url(<?php block_field( "pic" ); ?>)">
    <div class="container">
            <span class="subtitle">
	            <?php block_field( "txt" ); ?>
            </span>
        <h1 class="title kalameh">
			<?php block_field( "tt" ); ?>
        </h1>
        <div class="swiper-container swiper-main-slide">
            <div class="swiper-wrapper">
				<?php
				$args = array(
					'post_type'  => 'page',
					'meta_query' => array(
						array(
							'key'     => 'jobfinder-index-select',
							'value'   => 'on',
							'compare' => 'LIKE',
						),
					),
				);


				$the_query = new WP_Query( $args );


				if ( $the_query->have_posts() ) {

					while ( $the_query->have_posts() ) {
						$the_query->the_post();
						?>
                        <a href="<?php echo get_the_permalink() ?>" class="swiper-slide item tab-item">
                            <i class="icon-pm">
                                <img src="<?php echo wp_get_attachment_image_url( get_post_thumbnail_id() ) ?>"
                                     alt="<?php get_post_meta( get_post_thumbnail_id( get_the_ID() ), '_wp_attachment_image_alt', true ) ?>">
                            </i>
							<?php echo get_the_title() ?>
                        </a>
						<?php
					}

				} else {

				}

				wp_reset_postdata();
				?>


            </div>
        </div>
    </div>
</div>
<!--END-MAIN-SLIDE-->