<!--START-MAIN-SLIDE-->
<div class="b-main-slide">
    <div class="container">
        <div class="swiper-container swiper-main-1">
            <div class="swiper-wrapper">
                <?php
                $args = array(
                    "post_type" => "post",
                    'meta_query' => array(
                        array(
                            'key' => 'jobfinder-slider-selected',
                            'value' => 'on',
                            'compare' => 'LIKE',
                        ),
                    ),
                );


                $the_query = new WP_Query($args); ?>

                <?php if ($the_query->have_posts()) : ?>

                    <?php
                    while ($the_query->have_posts()) : $the_query->the_post();
                        $image_id = get_post_thumbnail_id(get_the_ID());
                        $jobfinder_post_time = get_post_meta($post->ID, 'jobfinder-post-time', true);
                        ?>
                        <a href="<?php echo get_the_permalink() ?>" class="swiper-slide item"
                           style="background-image: url(<?php echo wp_get_attachment_url($image_id) ?>)">
                            <article>
                                <?php if (!empty($jobfinder_post_time)) : ?>
                                    <span class="time">
                                <i class="icon-clock"></i>
                                <?= $jobfinder_post_time ?>
                                 دقیقه مطالعه
                            </span>
                                <?php endif; ?>
                                <h2 class="title kalameh">
                                    <?php echo get_the_title() ?>
                                </h2>
                                <p class="text">
                                    <?php echo get_the_excerpt() ?>
                                </p>
                            </article>
                        </a>
                    <?php endwhile; ?>
                    <!-- end of the loop -->

                    <!-- pagination here -->

                    <?php wp_reset_postdata(); ?>

                <?php else : ?>

                <?php endif; ?>


            </div>
            <div class="swiper-button-next swiper-button-next-main-1">
                <i class="icon-left"></i>
            </div>
            <div class="swiper-button-prev swiper-button-prev-main-1">
                <i class="icon-right"></i>
            </div>
        </div>
    </div>
</div>
<!--END-MAIN-SLIDE-->
