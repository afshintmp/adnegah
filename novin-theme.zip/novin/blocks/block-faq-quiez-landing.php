<li class="item-accordion">
    <a class="dropdownlink" onclick="return false">
        <i class="icon-left-circle1 plus"></i>
        <i class="icon-down-circle minus"></i>
        <?php block_field("tt") ?>
    </a>
    <div class="submenu">
        <?php block_field("txt") ?>
    </div>
</li>