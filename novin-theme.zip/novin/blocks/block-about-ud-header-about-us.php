<!--START-ABOUT-US-->
<div class="about-us">
    <div class="container p-0 d-flex flex-wrap">
        <div class="col-lg-6">
        <span class="subtitle">
            <?php
            block_field('sub-tt')
            ?>

        </span>
            <h2 class="title kalameh">
                <?php block_field('tt') ?>
            </h2>
            <div class="text">
                <?php block_field('text') ?>
            </div>
            <ul class="nav">
                <?php block_field('list') ?>
            </ul>
        </div>
        <div class="col-xl-5 col-lg-6 mr-auto d-none d-lg-block">
            <div class="img">
                <img src="<?php block_field('pic') ?>" alt="<?php block_field('alt-text') ?>">
            </div>
        </div>
    </div>
</div>
<!--END-ABOUT-US-->