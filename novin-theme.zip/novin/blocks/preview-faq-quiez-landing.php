<div style="width: 100%">
    <img src="<?php echo DU .'/assets/img/block-img/preview-faq-quiez-landing.php.jpg' ?>" alt="">
</div>
