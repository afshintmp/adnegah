<div class="swiper-slide item">
    <i class="<?php block_field("icon") ?>"></i>
    <span class="subtitle">
                          <?php block_field("tt") ?>
                        </span>
    <h2 class="title kalameh">
        <?php block_field("sub-tt") ?>
    </h2>
</div>