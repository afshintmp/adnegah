<div class="text">

	<?php block_field( 'txt' ); ?>

</div>