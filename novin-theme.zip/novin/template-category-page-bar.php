<?php

/* Template Name: صفحه با منو دسته بندی ها */
get_header();
$url = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

?>
<body>

<?php get_template_part( "partials/top-bar-menu" ) ?>

<!--START-MAIN-->
<main>
    <!--START-CATEGORY-BAR-->
    <div class="category-bar">
        <div class="container d-flex align-items-center justify-content-between">
            <ul class="nav">
                <li class="nav-item">
                    <a href="" class="nav-link">
                        <i class="icon-newspaper"></i>
                        جدیدترین ها
                    </a>
                </li>
                <?php
                $terms = get_terms( array(
                    'taxonomy'   => 'category',
                    'hide_empty' => false,
                ) );
                foreach ( $terms as $term ):
                    $value = get_term_meta( $term->term_id, 'landing', true );
                    ?>
                    <li class="nav-item">
                        <a href="<?php echo get_term_link( $term ) ?>" class="nav-link">
                            <i class="<?php echo $value ?>"></i>
                            <?php echo $term->name ?>
                        </a>
                    </li>
                <?php endforeach; ?>


            </ul>


        </div>
    </div>
    <!--END-CATEGORY-BAR-->
    <?php the_content(); ?>

</main>
<!--END-MAIN-->


<?php get_footer() ?>

</body>
</html>
