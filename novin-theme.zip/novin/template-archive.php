<?php

/* Template Name: ارشیو مقالات */
get_header();
$url = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

?>
<body>

<?php get_template_part( "partials/top-bar-menu" ) ?>

<!--START-MAIN-->
<main>
    <!--START-CATEGORY-BAR-->
    <div class="category-bar">
        <div class="container d-flex align-items-center justify-content-between">
            <ul class="nav">
				<?php
				$terms = get_terms( array(
					'taxonomy'   => 'category',
				
				) );
				foreach ( $terms as $term ):
					$value = get_term_meta( $term->term_id, 'landing', true );
					?>
                    <li class="nav-item">
                        <a href="<?php echo get_term_link( $term ) ?>" class="nav-link">
                            <i class="<?php echo $value ?>"></i>
							<?php echo $term->name ?>
                        </a>
                    </li>
				<?php endforeach; ?>


            </ul>

            <button class="btn btn-search go-to-search  d-none d-lg-flex">
                <i class="icon-search"></i>
            </button>
        </div>
    </div>
    <!--END-CATEGORY-BAR-->

    <!--START-BLOG-ARCHIVE-->
    <div class="blog-archive">
        <div class="container p-0 d-flex flex-wrap">
            <div class="col-lg-4">
                <div class="sidebar">
                    <div class="box target-search">
            <span class="title kalameh orange-theme">
              جستجو کنید
            </span>
                        <form action="" method="get">
                            <div class="form-group">
                                <input name="keyword" type="text" placeholder="">
                            </div>
                            <button class="btn btn-search">
                                <i class="icon-search"></i>
                            </button>
                        </form>
                    </div>

                    <div class="box d-none d-lg-block">
            <span class="title kalameh">
              پربازدیدترین ها
            </span>
						<?php
						$args = array(
							'posts_per_page' => 2,
							'post_type'     => 'post',
							'meta_key'      => 'view',
							'orderby'       => 'meta_value_num',
							'meta_type'     => 'NUMERIC',
							'order'         => 'DESC'
						);

						$the_query = new WP_Query( $args );
						?>
                        <div class="w-100">
							<?php

							if ( $the_query->have_posts() ) {

								while ( $the_query->have_posts() ) {
									$the_query->the_post();
									?>

                                    <div class="item-news">
                                        <a href="<?php echo get_the_permalink() ?>">
											<?php $image_id = get_post_thumbnail_id( get_the_ID() ) ?>
                                            <img src="<?php echo wp_get_attachment_url( $image_id ) ?>"
                                                 alt="<?php echo get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ?>">
                                            <span>
                <b><?php echo get_the_title() ?></b>
            <?php $cat = wp_get_post_terms( get_the_ID(), "category" ) ?>
												<?php echo ! empty( $cat ) ? $cat[0]->name . ' / ' : " " ?> <?php echo get_the_date( 'd F Y', get_the_ID() ); ?>

              </span>
                                        </a>
                                    </div>
									<?php
								}

							} else {

							}

							wp_reset_postdata();
							?>


                        </div>
                    </div>
                    	<?php $tags = get_terms( array(
								'taxonomy'   => 'post_tag',
							
							) ); 
							if(!empty($tags)) :
                    ?>
                    <div class="box d-none d-lg-block">
            <span class="title kalameh">
              برچسب ها
            </span>
                        <ul class="nav nav-tag">
						<?php

							foreach ( $tags as $tag ) :
								?>
                                <li class="nav-item">
                                    <a href="<?php echo add_query_arg( array( "post_tag" => $tag->term_id ), $url ) ?>"
                                       class="nav-link">
										<?php echo $tag->name ?>
                                    </a>
                                </li>
							<?php
							endforeach;
							?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-8">
				<?php
				$args = array(
					"post_type"      => "post",
					"posts_per_page" => 3
				);

				if ( isset( $_GET["keyword"] ) ) {
					$args["s"] = $_GET["keyword"];
				}


				if ( ! empty( $_GET['category'] ) ) {
					if ( array_key_exists( 'tax_query', $args ) ) {
						$args['tax_query']['relation'] = 'AND';
					}
					$args['tax_query'] = array(
						array(
							'taxonomy' => 'category',
							'field'    => 'term_id',
							'terms'    => $_GET['category'],
							'operator' => 'IN',
						),
					);
				}
				if ( ! empty( $_GET['post_tag'] ) ) {
					if ( array_key_exists( 'tax_query', $args ) ) {
						$args['tax_query']['relation'] = 'AND';
					}
					$args['tax_query'][] =
						array(
							'taxonomy' => 'post_tag',
							'field'    => 'term_id',
							'terms'    => $_GET['post_tag'],
							'operator' => 'IN',

						);
				}
				if ( isset( $_GET["pg"] ) ) {
					$offset         = ( intval( $_GET['pg'] ) - 1 ) * 4;
					$args['offset'] = $offset;
				}

				$the_query = new WP_Query( $args );


				if ( $the_query->have_posts() ) {

					while ( $the_query->have_posts() ) {
						$the_query->the_post();
						?>
                        <a href="<?php echo get_permalink() ?>" class="item"
                           style="background-image: url(<?php echo wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ?>)">
                            <article>
                                <div class="d-flex align-items-center">
            <span class="circle">
              <i class="icon-menu1"></i>
            </span>
                                    <ul class="nav">
                                        <li class="nav-item">
											<?php
											$new_view = get_post_meta( get_the_ID(), "view", true );
											if ( empty( $new_view ) ) {
												$new_view = 0;
											}
											echo $new_view;
											?> <i class="icon-show"></i>
                                        </li>
                                        <li class="nav-item">
											<?php echo get_comments_number() ?>
                                            <i class="icon-chat"></i>
                                        </li>
                                    </ul>
                                </div>
                                <span class="date">
              ارسال شده در تاریخ
                                 <?php echo get_the_date( 'd F Y', get_the_ID() ); ?>


									<?php $cat = wp_get_post_terms( get_the_ID(), "category" ) ?>
									<?php echo ! empty( $cat ) ? ' . ' . $cat[0]->name : " " ?>
            </span>
                                <h2 class="title kalameh">
									<?php echo get_the_title() ?>
                                </h2>
                                <p class="text">
									<?php echo get_the_excerpt() ?>
                                </p>
                            </article>
                        </a>
						<?php
					}
	
					/** Stop execution if there's only 1 page */
				if ( $the_query->max_num_pages <= 1 ) {
					return;
				}

				$paged =
					array_key_exists('pg' , $_GET) ? intval( $_GET['pg'] ) : 1;


				$all_post = $the_query->found_posts;

                $max  =  ceil($all_post / 4);

                $links = array();
				/** Add current page to the array */
				if ( $paged >= 1 ) {
					$links[] = $paged;
				}

				/** Add the pages around the current page to the array */
				if ( $paged >= 3 ) {
					$links[] = $paged - 1;
					$links[] = $paged - 2;
				}

				if ( ( $paged + 2 ) <= $max ) {
					$links[] = $paged + 2;
					$links[] = $paged + 1;
				}

				echo ' <ul class="nav nav-pagination"> ' . "\n";


				/** Link to first page, plus ellipses if necessary */
				if ( ! in_array( 1, $links ) ) {
					$class = 1 == $paged ? 'active-link' : '';

					printf( '
 <li class="nav-item %s">
				                            <a href="%s" style="cursor: pointer"
				                               class="nav-link">
											%s
				                            </a>
				                        </li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

					if ( ! in_array( 2, $links ) ) {
						echo '<li>…</li>';
					}
				}

				/** Link to current page, plus 2 pages in either direction if necessary */
				sort( $links );
				foreach ( (array) $links as $link ) {
					$class = $paged == $link ? "active-link" : '';
					printf( '<li class="nav-item %s">
				                            <a href="%s" style="cursor: pointer"
				                               class="nav-link">
											%s
				                            </a>
				                        </li>' . "\n", $class, add_query_arg( array( 'pg' => $link ), $url ), $link );
				}

				/** Link to last page, plus ellipses if necessary */
				if ( ! in_array( $max, $links ) ) {
					if ( ! in_array( $max - 1, $links ) ) {
						echo '<li class="more">…</li>' . "\n";
					}

					$class = $paged == $max ? "active-link" : '';
					printf( '<li class="nav-item %s">
				                            <a href="%s" style="cursor: pointer"
				                               class="nav-link">
											%s
				                            </a>
				                        </li>' . "\n", $class, add_query_arg( array( 'pg' => $max ), $url ), $max );
				}



			
				} else {

				}

				wp_reset_postdata();
				?>

            </div>
            <div class="col-12 d-block d-lg-none">
               <div class="sidebar">

                    <div class="box">
            <span class="title kalameh">
              پربازدیدترین ها
            </span>
						<?php
						$args = array(
							'posts_per_page' => 2,
							'post_type'      => 'post',
							'meta_key'       => 'view',
							'orderby'        => 'meta_value_num',
							'meta_type'      => 'NUMERIC',
							'order'          => 'DESC'
						);

						$the_query = new WP_Query( $args );
						?>
                        <div class="w-100">
							<?php

							if ( $the_query->have_posts() ) {

								while ( $the_query->have_posts() ) {
									$the_query->the_post();
									?>

                                    <div class="item-news">
                                        <a href="<?php echo get_the_permalink() ?>">
											<?php $image_id = get_post_thumbnail_id( get_the_ID() ) ?>
                                            <img src="<?php echo wp_get_attachment_url( $image_id ) ?>"
                                                 alt="<?php echo get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ?>">
                                            <span>
                <b><?php echo get_the_title() ?></b>
            <?php $cat = wp_get_post_terms( get_the_ID(), "category" ) ?>
												<?php echo ! empty( $cat ) ? $cat[0]->name . ' / ' : " " ?> <?php echo get_the_date( 'd F Y', get_the_ID() ); ?>

              </span>
                                        </a>
                                    </div>
									<?php
								}

							} else {

							}

							wp_reset_postdata();
							?>


                        </div>
                    </div>
        <?php $tags = get_terms( array(
								'taxonomy'   => 'post_tag',
							
							) ); 
							if(!empty($tags)) :	?>
                    <div class="box">
            <span class="title kalameh">
              برچسب ها
            </span>
                        <ul class="nav nav-tag">
							

						<?php	foreach ( $tags as $tag ) :
								?>
                                <li class="nav-item">
                                    <a href="<?php echo add_query_arg( array( "post_tag" => $tag->term_id ), $url ) ?>"
                                       class="nav-link">
										<?php echo $tag->name ?>
                                    </a>
                                </li>
							<?php
							endforeach;
							?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!--END-BLOG-ARCHIVE-->
</main>
<!--END-MAIN-->


<?php get_footer() ?>

</body>
</html>
