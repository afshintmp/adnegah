<?php

get_header() ?>
<body>

<?php get_template_part("partials/top-bar-menu") ?>

<!--START-MAIN-->
<main>
    <!--START-MAIN-SLIDE-->
    <div class="main-slide" style="background-image: url('assets/img/main-slide.png')">
        <div class="container">
            <span class="subtitle">
                با نوین پرداخت در همه جا تجربه بهتری داشته باشید
            </span>
            <h1 class="title kalameh">
                خریــد و فــروش ارزهــای دیجیتــال
            </h1>
            <div class="swiper-container swiper-main-slide">
                <div class="swiper-wrapper">
                    <a href="#" class="swiper-slide item tab-item">
                        <i class="icon-pm">
                            <span class="path1"></span>
                            <span class="path2"></span>
                        </i>
                        پرفکت مانی
                    </a>
                    <a href="#" class="swiper-slide item tab-item">
                        <i class="icon-bitcoin1"></i>
                        ارز دیجیتال
                    </a>
                    <a href="#" class="swiper-slide item tab-item">
                        <i class="icon-wm"></i>
                        وب مانی
                    </a>
                    <a href="#" class="swiper-slide item tab-item">
                        <i class="icon-paypal1"></i>
                        پی پال
                    </a>
                    <a href="#" class="swiper-slide item tab-item">
                        <i class="icon-money1"></i>
                        نقد کردن درآمد
                    </a>
                    <a href="#" class="swiper-slide item tab-item">
                        <i class="icon-credit-card1"></i>
                        ویزا و مستر کارت
                    </a>
                    <a href="#" class="swiper-slide item tab-item">
                        <i class="icon-college"></i>
                        ثبت نام آزمون
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!--END-MAIN-SLIDE-->

    <!--START-HOW-START-->
    <div class="how-start">
        <div class="container p-0 d-flex flex-wrap">
            <div class="col-lg-6">
                <h4 class="title">
                    <b class="kalameh">از کــــجا بایــــد شــــروع کــــنم ؟</b>
                    خــــدمات نویــــن و بیــــن المللــــی
                    <span class="lines">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                </h4>
                <p class="text">
                    نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت های بین المللی تشکیل شده است. با
                    سابقه ترین و با تجربه ترین افراد در زمینه ی پرداخت های بین المللی با پیش زمینه تشکیل چندین استارتاپ
                    موفق در یک دهه ی اخیر، گرد هم آمده اند .
                </p>
                <a href="#" class="more">
                    مشاهده همه خدمات
                    <i class="icon-left-arrow"></i>
                </a>
            </div>
            <div class="col-lg-6 d-lg-block d-none">
                <img src="assets/img/mobile.png" alt="">
            </div>
        </div>
    </div>
    <!--END-HOW-START-->

    <!--START-TAB-SECTION-->
    <div class="tab-section">
        <div class="container">
            <ul class="nav nav-tab">
                <li class="nav-item tab-item-2 active" data-filter="one">
                    <i class="icon-money-transfer"></i>
                    <span>
                        پرداخـــت هـــای ارزی
                    </span>
                </li>
                <li class="nav-item tab-item-2" data-filter="two">
                    <i class="icon-wallet1"></i>
                    <span>
                        نقـــد کـــردن درآمـــد
                    </span>
                </li>
                <li class="nav-item tab-item-2" data-filter="three">
                    <i class="icon-account"></i>
                    <span>
                        افتتـــاح حســـاب هـــا
                    </span>
                </li>
                <li class="nav-item tab-item-2" data-filter="four">
                    <i class="icon-bill"></i>
                    <span>
                        شـــارژ حـــساب
                    </span>
                </li>
            </ul>
            <div class="slider-container">
                <div class="swiper-container swiper-tab">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide item filter-item-2 one">
                            <div class="img">
                                <img src="assets/img/paypal.png" alt="">
                            </div>
                            <article>
                                <h2 class="title">
                                    <b class="kalameh">
                                        نقـــد کـــردن درآمـــد ارزی از پـــی پـــال
                                    </b>
                                    انتخــاب بهتریــن و امــن تریــن مسیــر
                                </h2>
                                <p class="text">
                                    نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت های بین المللی تشکیل
                                    شده است. با سابقه ترین و با تجربه ترین افراد در زمینه ی پرداخت های بین المللی با پیش
                                    زمینه تشکیل چندین استارتاپ موفق در یک دهه ی اخیر، گرد هم آمده اند .
                                </p>
                                <a href="" class="more">
                                    سفارش دهید
                                    <i class="icon-left-arrow"></i>
                                </a>
                            </article>
                        </div>
                        <div class="swiper-slide item filter-item-2 two">
                            <div class="img">
                                <img src="assets/img/paypal.png" alt="">
                            </div>
                            <article>
                                <h2 class="title">
                                    <b class="kalameh">
                                        نقـــد کـــردن درآمـــد ارزی از پـــی پـــال
                                    </b>
                                    انتخــاب بهتریــن و امــن تریــن مسیــر 1
                                </h2>
                                <p class="text">
                                    نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت های بین المللی تشکیل
                                    شده است. با سابقه ترین و با تجربه ترین افراد در زمینه ی پرداخت های بین المللی با پیش
                                    زمینه تشکیل چندین استارتاپ موفق در یک دهه ی اخیر، گرد هم آمده اند .
                                </p>
                                <a href="" class="more">
                                    سفارش دهید
                                    <i class="icon-left-arrow"></i>
                                </a>
                            </article>
                        </div>
                        <div class="swiper-slide item filter-item-2 three">
                            <div class="img">
                                <img src="assets/img/paypal.png" alt="">
                            </div>
                            <article>
                                <h2 class="title">
                                    <b class="kalameh">
                                        نقـــد کـــردن درآمـــد ارزی از پـــی پـــال
                                    </b>
                                    انتخــاب بهتریــن و امــن تریــن مسیــر 2
                                </h2>
                                <p class="text">
                                    نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت های بین المللی تشکیل
                                    شده است. با سابقه ترین و با تجربه ترین افراد در زمینه ی پرداخت های بین المللی با پیش
                                    زمینه تشکیل چندین استارتاپ موفق در یک دهه ی اخیر، گرد هم آمده اند .
                                </p>
                                <a href="" class="more">
                                    سفارش دهید
                                    <i class="icon-left-arrow"></i>
                                </a>
                            </article>
                        </div>
                        <div class="swiper-slide item filter-item-2 four">
                            <div class="img">
                                <img src="assets/img/paypal.png" alt="">
                            </div>
                            <article>
                                <h2 class="title">
                                    <b class="kalameh">
                                        نقـــد کـــردن درآمـــد ارزی از پـــی پـــال
                                    </b>
                                    انتخــاب بهتریــن و امــن تریــن مسیــر 3
                                </h2>
                                <p class="text">
                                    نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت های بین المللی تشکیل
                                    شده است. با سابقه ترین و با تجربه ترین افراد در زمینه ی پرداخت های بین المللی با پیش
                                    زمینه تشکیل چندین استارتاپ موفق در یک دهه ی اخیر، گرد هم آمده اند .
                                </p>
                                <a href="" class="more">
                                    سفارش دهید
                                    <i class="icon-left-arrow"></i>
                                </a>
                            </article>
                        </div>
                    </div>
                </div>
                <div class="btn-nav next swiper-button-next-tab">
                    <i class="icon-left"></i>
                </div>
                <div class="btn-nav prev swiper-button-prev-tab">
                    <i class="icon-right"></i>
                </div>
            </div>
        </div>
    </div>
    <!--END-TAB-SECTION-->

    <!---START-OUR-SERVICES-->
    <div class="our-services">
        <div class="container">
            <div class="header-section d-flex align-items-center justify-content-between">
                <div class="clear-fix"></div>
                <span class="title text-center kalameh">
                    <span class="lines before">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                    ویژگــــی هــــای نویــــن پــــرداخت
                    <span class="light">
                        تمایــــز خــــدمات مــــا بــــا سایــــر رقــــبا
                    </span>
                    <span class="lines after">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                </span>
                <div class="clear-fix"></div>
            </div>
            <p class="text">
                نوین پرداخت میتواند هر پرداخت ارزی آنلاین را با بهترین نرخ ها و متمایز ترین خدمات برایتان انجام دهد.
                علاوه بر انجام همه انواع سفارشات ارزی، نوین پرداخت به دنبال ایجاد مشتری سالاری واقعی و ایجاد احساس
                خوشحالی در افرادی است که به هر نحوی با نوین پرداخت ارتباط دارند. تشکیل یک ارتباط انسانی، توام با احترام
                و شعف مهمترین هدفی است که تیم نوین پرداخت برای آن آموزش دیده اند و برای آن می کوشند .
            </p>
            <div class="row prl-5px">
                <div class="col-lg-4 col-md-6 col-12 prl-10px">
                    <div class="item">
                        <div class="icon">
                            <i class="icon-headphones1"></i>
                        </div>
                        <span class="title kalameh">
                            پشتیبانی قدرتمند
                        </span>
                        <span class="subtitle">
                            شبانه روزی و آنلاین
                        </span>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 prl-10px">
                    <div class="item">
                        <div class="icon">
                            <i class="icon-startup"></i>
                        </div>
                        <span class="title kalameh">
                            سرعت در انجام
                        </span>
                        <span class="subtitle">
                            توسط تیم مجرب
                        </span>
                    </div>
                </div>
                <div class="col-lg-4 col-12 prl-10px">
                    <div class="item">
                        <div class="icon">
                            <i class="icon-money-transfer"></i>
                        </div>
                        <span class="title kalameh">
                            نرخ کارمزد کم
                        </span>
                        <span class="subtitle">
                            در همه خدمات
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--END-OUR-SERVICES-->

    <!---START-I-ABOUT-US-->
    <div class="i-about-us">
        <img src="assets/img/shape.png" class="shape" alt="">
        <div class="bg">
            <div class="container p-0 d-flex align-items-end flex-wrap">
                <div class="col-lg-6 d-none d-lg-block">
                    <img src="assets/img/i-about-us.png" alt="" class="img">
                </div>
                <div class="col-lg-6">
                    <ul class="nav nav-tab">
                        <li class="nav-item tab-item-1 active" data-filter="one">
                            درباره گروه ما
                        </li>
                        <li class="nav-item tab-item-1" data-filter="two">
                            قوانین و مقررات
                        </li>
                    </ul>
                    <span class="title kalameh filter-item-1 one">
                        نوین پرداخت را بهتر بشناسید
                    </span>
                    <span class="title kalameh filter-item-1 two" style="display: none">
                        قوانین و مقررات نوین پرداخت
                    </span>
                </div>
                <div class="col-12">
                    <div class="box filter-item-1 one">
                        <p class="text">
                            نوین پرداخت میتواند هر پرداخت ارزی آنلاین را با بهترین نرخ ها و متمایز ترین خدمات برایتان
                            انجام دهد. علاوه بر انجام همه انواع سفارشات ارزی، نوین پرداخت به دنبال ایجاد مشتری سالاری
                            واقعی و ایجاد احساس خوشحالی در افرادی است که به هر نحوی با نوین پرداخت ارتباط دارند. تشکیل
                            یک ارتباط انسانی، توام با احترام و شعف مهمترین هدفی است که تیم نوین پرداخت برای آن آموزش
                            دیده اند و برای آن می کوشند.با انجام امور ارزی آنلاین توسط نوین پرداخت، در کنار استفاده از
                            سریعترین و کاملترین ترین پلاتفرم پرداخت ارزی آنلاین کشور، ارزش های سازمانی نوین پرداخت را
                            احساس خواهید کرد و با احترام و خوشحالی از یک رایطه ی انسانی لذت خواهید برد.تیم نوین پرداخت
                            برای انجام هر پرداخت ارزی آنلاین و نیز ایجاد این رابطه انسانی توام با احترام و خوشحالی آموزش
                            دیده اند.نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت ها است .
                        </p>
                        <div class="more show-more-text">
                            <i class="icon-down-chevron"></i>
                            <span>
                                مشــاهده کامــل توضیحــات
                            </span>
                            <span style="display: none">
                                مشــاهده کمتر توضیحــات
                            </span>
                        </div>
                    </div>
                    <div class="box filter-item-1 two" style="display: none">
                        <p class="text">
                            نوین پرداخت میتواند هر پرداخت ارزی آنلاین را با بهترین نرخ ها و متمایز ترین خدمات برایتان
                            انجام دهد. علاوه بر انجام همه انواع سفارشات ارزی، نوین پرداخت به دنبال ایجاد مشتری سالاری
                            واقعی و ایجاد احساس خوشحالی در افرادی است که به هر نحوی با نوین پرداخت ارتباط دارند. تشکیل
                            یک ارتباط انسانی، توام با احترام و شعف مهمترین هدفی است که تیم نوین پرداخت برای آن آموزش
                            دیده اند و برای آن می کوشند.با انجام امور ارزی آنلاین توسط نوین پرداخت، در کنار استفاده از
                            سریعترین و کاملترین ترین پلاتفرم پرداخت ارزی آنلاین کشور، ارزش های سازمانی نوین پرداخت را
                            احساس خواهید کرد و با احترام و خوشحالی از یک رایطه ی انسانی لذت خواهید برد.تیم نوین پرداخت
                            برای انجام هر پرداخت ارزی آنلاین و نیز ایجاد این رابطه انسانی توام با احترام و خوشحالی آموزش
                            دیده اند.نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت ها است .
                            نوین پرداخت میتواند هر پرداخت ارزی آنلاین را با بهترین نرخ ها و متمایز ترین خدمات برایتان
                            انجام دهد. علاوه بر انجام همه انواع سفارشات ارزی، نوین پرداخت به دنبال ایجاد مشتری سالاری
                            واقعی و ایجاد احساس خوشحالی در افرادی است که به هر نحوی با نوین پرداخت ارتباط دارند. تشکیل
                            یک ارتباط انسانی، توام با احترام و شعف مهمترین هدفی است که تیم نوین پرداخت برای آن آموزش
                            دیده اند و برای آن می کوشند.با انجام امور ارزی آنلاین توسط نوین پرداخت، در کنار استفاده از
                            سریعترین و کاملترین ترین پلاتفرم پرداخت ارزی آنلاین کشور، ارزش های سازمانی نوین پرداخت را
                            احساس خواهید کرد و با احترام و خوشحالی از یک رایطه ی انسانی لذت خواهید برد.تیم نوین پرداخت
                            برای انجام هر پرداخت ارزی آنلاین و نیز ایجاد این رابطه انسانی توام با احترام و خوشحالی آموزش
                            دیده اند.نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت ها است .
                        </p>
                        <div class="more show-more-text">
                            <i class="icon-down-chevron"></i>
                            <span>
                                مشــاهده کامــل توضیحــات
                            </span>
                            <span style="display: none">
                                مشــاهده کمتر توضیحــات
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--END-I-ABOUT-US-->

    <!--START-OUR-TESTIMONIAL-->
    <div class="testimonial">
        <div class="container">
            <div class="header-section d-flex align-items-center justify-content-between">
                <div class="clear-fix"></div>
                <span class="title text-center kalameh">
                    <span class="lines before">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                    نــــقل قــــول از مشتریــــان
                    <span class="light">
                        نتیجــــه اعتــــماد کاربــــران
                    </span>
                    <span class="lines after">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                </span>
                <div class="clear-fix"></div>
            </div>
            <div class="swiper-container swiper-testimonial">
                <div class="swiper-wrapper">
                    <div class="swiper-slide item">
                        <div class="name">
                            <i class="icon-quotation"></i>
                            <b>سید هادی حجازی فرد</b>
                            فروشگاه فراسو رایانه
                        </div>
                        <p class="text">
                            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
                            گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون است .
                        </p>
                    </div>
                    <div class="swiper-slide item">
                        <div class="name">
                            <i class="icon-quotation"></i>
                            <b>سید هادی حجازی فرد</b>
                            فروشگاه فراسو رایانه
                        </div>
                        <p class="text">
                            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
                            گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون است .
                        </p>
                    </div>
                    <div class="swiper-slide item">
                        <div class="name">
                            <i class="icon-quotation"></i>
                            <b>سید هادی حجازی فرد</b>
                            فروشگاه فراسو رایانه
                        </div>
                        <p class="text">
                            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
                            گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون است .
                        </p>
                    </div>
                    <div class="swiper-slide item">
                        <div class="name">
                            <i class="icon-quotation"></i>
                            <b>سید هادی حجازی فرد</b>
                            فروشگاه فراسو رایانه
                        </div>
                        <p class="text">
                            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
                            گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون است .
                        </p>
                    </div>
                    <div class="swiper-slide item">
                        <div class="name">
                            <i class="icon-quotation"></i>
                            <b>سید هادی حجازی فرد</b>
                            فروشگاه فراسو رایانه
                        </div>
                        <p class="text">
                            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
                            گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون است .
                        </p>
                    </div>
                    <div class="swiper-slide item">
                        <div class="name">
                            <i class="icon-quotation"></i>
                            <b>سید هادی حجازی فرد</b>
                            فروشگاه فراسو رایانه
                        </div>
                        <p class="text">
                            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
                            گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون است .
                        </p>
                    </div>
                    <div class="swiper-slide item">
                        <div class="name">
                            <i class="icon-quotation"></i>
                            <b>سید هادی حجازی فرد</b>
                            فروشگاه فراسو رایانه
                        </div>
                        <p class="text">
                            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
                            گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون است .
                        </p>
                    </div>
                </div>
            </div>
            <div class="pagination swiper-pagination-testimonial"></div>
        </div>
    </div>
    <!--END-OUR-TESTIMONIAL-->

    <!--START-OUR-BRANDS-->
    <div class="brands">
        <div class="swiper-container swiper-brands">
            <div class="swiper-wrapper">
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
                <a href="#" class="swiper-slide item">
                    <img src="assets/img/b-1.png" alt="">
                </a>
            </div>
        </div>
    </div>
    <!--END-OUR-BRANDS-->

    <!--START-ARTICLES-->
    <div class="articles">
        <div class="container">
            <div class="header-section d-flex align-items-center justify-content-between">
                <a href="" class="see-all">
                    مشاهده آرشیو
                </a>
                <span class="title kalameh">
                    <span class="lines before">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                    مجلـــــه خـــــبری
                    <span class="lines after">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                </span>
                <div class="swiper-pagination swiper-pagination-articles"></div>
            </div>
            <div class="swiper-container swiper-articles">
                <div class="swiper-wrapper">
                    <a href="#" class="swiper-slide item">
                        <div class="img">
                            <img src="assets/img/article-1.png" alt="">
                            <ul class="nav">
                                <li class="nav-item">
                                    <i class="icon-heart"></i>
                                    8 لایک
                                </li>
                                <li class="nav-item">
                                    <i class="icon-chat"></i>
                                    25 نظر
                                </li>
                            </ul>
                        </div>
                        <article>
                            <span class="info">
                                <b>دسته بندی</b>
                                فناوری
                                &nbsp;&nbsp;&nbsp;
                                <br class="d-none d-lg-block d-xl-none">
                                <b>در تاریخ</b>
                                17 فروردین ماه 1400
                            </span>
                            <span class="title">
                                یک آیفون از هواپیما سقوط کرد
و به طرزی معجزه‌آسا سالم ماند!
                            </span>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک
                                است .
                            </p>
                            <div class="more">
                                ادامه مطلب
                            </div>
                        </article>
                    </a>
                    <a href="#" class="swiper-slide item">
                        <div class="img">
                            <img src="assets/img/article-1.png" alt="">
                            <ul class="nav">
                                <li class="nav-item">
                                    <i class="icon-heart"></i>
                                    8 لایک
                                </li>
                                <li class="nav-item">
                                    <i class="icon-chat"></i>
                                    25 نظر
                                </li>
                            </ul>
                        </div>
                        <article>
                            <span class="info">
                                <b>دسته بندی</b>
                                فناوری
                                &nbsp;&nbsp;&nbsp;
                                <br class="d-none d-lg-block d-xl-none">
                                <b>در تاریخ</b>
                                17 فروردین ماه 1400
                            </span>
                            <span class="title">
                                یک آیفون از هواپیما سقوط کرد
و به طرزی معجزه‌آسا سالم ماند!
                            </span>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک
                                است .
                            </p>
                            <div class="more">
                                ادامه مطلب
                            </div>
                        </article>
                    </a>
                    <a href="#" class="swiper-slide item">
                        <div class="img">
                            <img src="assets/img/article-1.png" alt="">
                            <ul class="nav">
                                <li class="nav-item">
                                    <i class="icon-heart"></i>
                                    8 لایک
                                </li>
                                <li class="nav-item">
                                    <i class="icon-chat"></i>
                                    25 نظر
                                </li>
                            </ul>
                        </div>
                        <article>
                            <span class="info">
                                <b>دسته بندی</b>
                                فناوری
                                &nbsp;&nbsp;&nbsp;
                                <br class="d-none d-lg-block d-xl-none">
                                <b>در تاریخ</b>
                                17 فروردین ماه 1400
                            </span>
                            <span class="title">
                                یک آیفون از هواپیما سقوط کرد
و به طرزی معجزه‌آسا سالم ماند!
                            </span>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک
                                است .
                            </p>
                            <div class="more">
                                ادامه مطلب
                            </div>
                        </article>
                    </a>
                    <a href="#" class="swiper-slide item">
                        <div class="img">
                            <img src="assets/img/article-1.png" alt="">
                            <ul class="nav">
                                <li class="nav-item">
                                    <i class="icon-heart"></i>
                                    8 لایک
                                </li>
                                <li class="nav-item">
                                    <i class="icon-chat"></i>
                                    25 نظر
                                </li>
                            </ul>
                        </div>
                        <article>
                            <span class="info">
                                <b>دسته بندی</b>
                                فناوری
                                &nbsp;&nbsp;&nbsp;
                                <br class="d-none d-lg-block d-xl-none">
                                <b>در تاریخ</b>
                                17 فروردین ماه 1400
                            </span>
                            <span class="title">
                                یک آیفون از هواپیما سقوط کرد
و به طرزی معجزه‌آسا سالم ماند!
                            </span>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک
                                است .
                            </p>
                            <div class="more">
                                ادامه مطلب
                            </div>
                        </article>
                    </a>
                    <a href="#" class="swiper-slide item">
                        <div class="img">
                            <img src="assets/img/article-1.png" alt="">
                            <ul class="nav">
                                <li class="nav-item">
                                    <i class="icon-heart"></i>
                                    8 لایک
                                </li>
                                <li class="nav-item">
                                    <i class="icon-chat"></i>
                                    25 نظر
                                </li>
                            </ul>
                        </div>
                        <article>
                            <span class="info">
                                <b>دسته بندی</b>
                                فناوری
                                &nbsp;&nbsp;&nbsp;
                                <br class="d-none d-lg-block d-xl-none">
                                <b>در تاریخ</b>
                                17 فروردین ماه 1400
                            </span>
                            <span class="title">
                                یک آیفون از هواپیما سقوط کرد
و به طرزی معجزه‌آسا سالم ماند!
                            </span>
                            <p class="text">
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک
                                است .
                            </p>
                            <div class="more">
                                ادامه مطلب
                            </div>
                        </article>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!--END-ARTICLES-->
</main>
<!--END-MAIN-->


<?php get_footer() ?>

</body>
</html>