<?php

add_action('admin_menu', 'wpdocs_register_my_custom_submenu_page');
//require get_template_directory() . '/inc/call-back.php';


function wpdocs_register_my_custom_submenu_page()
{
	add_menu_page('My Custom Page',
		'تنظیمات قالب',
		'manage_options',
		'my-top-level-slug',
		'jobfinder_menu_setting_page');


	add_submenu_page('my-top-level-slug',
		'تنظیمات فوتر',
		'تنظیمات فوتر',
		'manage_options',
		'footer-setting',
		'footer_submenu_page_callback');


}

function jobfinder_menu_setting_page()
{
global $option;
	wp_enqueue_script('media-upload');
	wp_enqueue_script('thickbox');
	wp_enqueue_style('thickbox');

	define("ME_URL", rtrim(WP_PLUGIN_URL,'/') . '/'.basename(dirname(__FILE__)) );
	define("ME_DIR", rtrim(dirname(__FILE__), '/'));

	if (isset($_POST['save'])) {


		if (!empty($_POST['logo-img'])) {
			update_option('logo-img', $_POST['logo-img']);
		} else {
			update_option('logo-img', DU . '/assets/img/Logo.png');
		}


		update_option('cfi', $_POST['cfi']);




	}


	$logo_img = get_option('logo-img');
	$contact_form_id = get_option('cfi');




	?>
	<div class="setting-col">

		<form action="" method="post">

			<div>

				<div class="m-l-2">

					<div class="upload m-l-2 guid-fire" data-guid="img-upload">
						<p class="font-bold">
							بارگزاری لگو :
						</p>
						<img data-src="<?php echo DU . '/assets/img/Logo.png' ?>"
						     src="<?php echo !empty($logo_img) ? $logo_img : DU . '/assets/img/Logo.png' ?>" width="150"
						     height=""/>
						<div>
							<input type="hidden" name="logo-img" id="RssFeedIcon_settings"
							       value="<?php echo !empty($logo_img) ? $logo_img : DU . '/assets/img/Logo.png' ?>"/>
							<button type="submit" class="upload_image_button button">افزودن</button>
							<button type="submit" class="remove_image_button button">&times;</button>
						</div>
					</div>

				</div>
                <div>
                    <br>
                    <label for="">ای دی فرم تماس با ما :</label>
                    <input type="text" name="cfi" value="<?php echo $contact_form_id ?>">
                    <br>
                    <br>
                </div>

				<div>
					<input type="submit" style="margin-top: 15px" name="save" value="ذخیره">
				</div>
			</div>


		</form>
	</div>

    <script>
        jQuery('.upload_image_button').click(function (e) {
            e.preventDefault()
            var button = jQuery(this);
            formfield = jQuery('#upload_image').attr('name');
            tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
            window.send_to_editor = function (html) {
                imgurl = jQuery(html).attr('src');
                imgalt = jQuery(html).attr('alt');
                jQuery(button).parent().prev().attr('src', imgurl);
                jQuery(button).prev().val(imgurl);

                tb_remove();
            }

            return false;
        });
    </script>
	<script>
    /*    jQuery('.upload_image_button').click(function (e) {
            e.preventDefault()
            var send_attachment_bkp = wp.media.editor.send.attachment;
            var button = jQuery(this);
            wp.media.editor.send.attachment = function (props, attachment) {
                jQuery(button).parent().prev().attr('src', attachment.url);
                jQuery(button).prev().val(attachment.url);
                wp.media.editor.send.attachment = send_attachment_bkp;
            }
            wp.media.editor.open(button);
            return false;
        });*/
        jQuery('.remove_image_button').click(function () {
            var answer = confirm('Are you sure?');
            if (answer == true) {
                var src = jQuery(this).parent().prev().attr('data-src');
                jQuery(this).parent().prev().attr('src', src);
                jQuery(this).prev().prev().val('');
            }
            return false;
        });
	</script>
	<?php
}


function footer_submenu_page_callback()
{
	global $option;
	if (isset($_POST['newsave'])) {
        update_option('p-num', $_POST['p-num']);

        update_option('telegram', $_POST['telegram']);


	}
	$p_num = get_option('p-num', false);

	$telegram = get_option('telegram', false);


	?>
	<style>
        .footer-form {
        }

        .footer-form label {
            display: block;
        }

        .footer-form input {
            width: 400px;
        }

        .footer-form {
        }
	</style>
	<form action="" method="post" class="footer-form" style="margin-top: 20px">
        <label for="">تلفن تماس :</label>
        <input type="text" name="p-num" value="<?php echo $p_num ?>">
        <br>
        <br>
        <label for="">ادرس تماس واتس اپ :</label>
        <input type="text" name="whatsapp" value="<?php echo $whatsapp ?>">
        <br>
        <br>
        <label for="">ادرس تماس تلگرام :</label>
        <input type="text" name="telegram" value="<?php echo $telegram ?>">
        <br>
        <br>

		<input type="submit" class="w-100" value="ذخیره" name="newsave">
	</form>
	<?php
}

