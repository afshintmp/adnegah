<?php
global $post;


get_header();

$view = get_post_meta( get_the_ID(), "view", true );



if ( empty( $view ) ):
	$view = 0;
endif;

$new_view = $view + 1;


update_post_meta( get_the_ID(), "view", $new_view , $view);



?>
<body>

<?php get_template_part( "partials/top-bar-menu" ) ?>


<!--START-MAIN-->
<main>
    <!--START-CATEGORY-BAR-->
    <div class="category-bar">
        <div class="container d-flex align-items-center justify-content-between">
            <ul class="nav">
				<?php
				$terms = get_terms( array(
					'taxonomy'   => 'category',
					'hide_empty' => false,
				) );
				foreach ( $terms as $term ):
					$value = get_term_meta( $term->term_id, 'landing', true );
					?>
                    <li class="nav-item">
                        <a href="<?php echo get_term_link( $term ) ?>" class="nav-link">
                            <i class="<?php echo $value ?>"></i>
							<?php echo $term->name ?>
                        </a>
                    </li>
				<?php endforeach; ?>


            </ul>

            <button class="btn btn-search go-to-search  d-none d-lg-flex">
                <i class="icon-search"></i>
            </button>
        </div>
    </div>
    <!--END-CATEGORY-BAR-->
    <!--START-BLOG-SINGLE-->
    <div class="blog-single">
        <div class="container">
            <div class="box">
                <div class="main-img"
                     style="background-image: url(<?php echo wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ?>)">
                    <ul class="nav nav-info">
                        <li class="nav-item">
                            <div class="icon">
                                <img src="<?php echo get_avatar_url( $post->post_author ) ?>" alt="">
                            </div>
                            <span>
                                <b>
                                    نویسنده مطلب
                                </b>
                               <?php


                               echo get_the_author_meta( 'display_name', $post->post_author ); ?>
                            </span>
                        </li>


						<?php
						$term_obj_list = get_the_terms( $post->ID, 'category' );
						if ( $term_obj_list ) {
							?>
                            <li class="nav-item">
                                <div class="icon">
                                    <div class="bg">
                                        <i class="icon-category">
                                            <span class="path1"></span>
                                            <span class="path2"></span>
                                            <span class="path3"></span>
                                            <span class="path4"></span>
                                            <span class="path5"></span>
                                            <span class="path6"></span>
                                            <span class="path7"></span>
                                            <span class="path8"></span>
                                        </i>
                                    </div>
                                </div>
								<?php
								foreach ( $term_obj_list as $term_obj ):
									?>
                                    <span>
                                <b>
                               دسته بندی
                                </b>
                            <?php echo $term_obj->name ?>
                            </span>
								<?php endforeach; ?>
                            </li>
						<?php } ?>

                        <li class="nav-item">
                            <div class="icon">
                                <div class="bg">
                                    <i class="icon-calendar1">
                                        <span class="path1"></span>
                                        <span class="path2"></span>
                                        <span class="path3"></span>
                                        <span class="path4"></span>
                                        <span class="path5"></span>
                                        <span class="path6"></span>
                                        <span class="path7"></span>
                                        <span class="path8"></span>
                                    </i>
                                </div>
                            </div>
                            <span>
                                <b>
                                    انتشار در تاریخ
                                </b>
                                <?php echo get_the_date( 'd F Y', get_the_ID() ); ?>
                            </span>
                        </li>
                     
                    </ul>
                </div>
                <div class="top-bar">
                    <span class="title kalameh">
                      <?php echo get_the_title() ?>
                    </span>
					<?php
					$jobfinder_post_time = get_post_meta( $post->ID, 'jobfinder-post-time', true );

					if ( $jobfinder_post_time ) {
						?>
                        <div class="time">
                            <i class="icon-clock"></i>
                            زمان مطالعه مقاله
							<?php echo $jobfinder_post_time ?>
                            دقیقه
                        </div>

						<?php
					}
					?>

                </div>
                <?php $sliderone = get_post_meta( $post->ID, 'jobfinder-post-list', true ); 
                if(!empty($sliderone)) :
                ?>
                <div class="table-content">
                    <div class="head">
                        <i class="icon-document main-i">
                            <span class="path1"></span>
                            <span class="path2"></span>
                            <span class="path3"></span>
                            <span class="path4"></span>
                            <span class="path5"></span>
                            <span class="path6"></span>
                            <span class="path7"></span>
                            <span class="path8"></span>
                        </i>

                        <span class="d-none d-lg-block">
                            <b>فهرست مطالب در این مقاله را مشاهده کنید</b>
بررسی جزئیات بیشتر و مطالعه دقیق
                        </span>
                        <span class="d-block d-lg-none">
                            <b class="m-0">فهرست مطالب</b>
                        </span>
                        <div class="icon show-ul" onclick="postList(this)">
                            <i class="icon-down"></i>
                        </div>
                    </div>
                    <div class="nav nav-content">
						
						<?php echo $sliderone ?>
                    </div>

                </div>
                <script>
                    function postList(element) {

                        if (jQuery(".nav.nav-content").css("display") === "none") {
                            jQuery(element).removeClass("show")
                            jQuery(".nav.nav-content").slideDown()
                        } else {

                            jQuery(element).addClass("show")
                            jQuery(".nav.nav-content").slideUp()
                        }

                    }
                </script>
                <?php endif; ?>
                <div class="main-blog">
					<?php the_content(); ?>
                </div>
            </div>
        </div>
    </div>
    <!--END-BLOG-SINGLE-->

    <!--START-PREV-NEXT-BLOG-->
    <div class="prev-next-blog d-none d-lg-block">
        <div class="container prl-5px d-flex flex-wrap">
            <div class="col-md-6 prl-10px">
               <?php $next_post = get_next_post();
                if ( is_a( $next_post , 'WP_Post' ) ) : ?>

                    <a href="<?php echo get_permalink( $next_post->ID ); ?>" class="item">
                    <span class="circle">
                        <i class="icon-right-arrow"></i>
                    </span>
                        <span>
                        <b>مشاهده مقاله بعدی</b>
<?php echo get_the_title( $next_post->ID ); ?>
                    </span>
                    </a>

                <?php endif; ?>

            </div>
            <div class="col-md-6 prl-10px">

	            <?php $prv_post = get_previous_post();
	            if ( is_a( $prv_post , 'WP_Post' ) ) : ?>


                    <a href="<?php echo get_permalink( $prv_post->ID ); ?>" class="item blue-theme">
                    <span>
                          <b>مشاهده مقاله قبلی</b>
<?php echo get_the_title( $prv_post->ID ); ?>
                    </span>
                        <span class="circle">
                        <i class="icon-left-arrow"></i>
                    </span>
                    </a>
	            <?php endif; ?>

            </div>
        </div>
    </div>
    <!--END-PREV-NEXT-BLOG-->

    <!--START-TAG-BAR-->
    <div class="tag-bar">
        <div class="container d-flex flex-wrap">
            <div class="box">
                <span class="title kalameh">
                    <i class="icon-tag">
                                        <span class="path1"></span>
                                        <span class="path2"></span>
                                        <span class="path3"></span>
                                        <span class="path4"></span>
                                        <span class="path5"></span>
                                        <span class="path6"></span>
                                        <span class="path7"></span>
                                        <span class="path8"></span>
                                    </i>
                    لیست برچسب ها
                </span>
                <ul class="nav">
					<?php $term__ = get_the_terms( $post->ID, 'post_tag' ); ?>

					<?php
					if ( ! empty( $term__ ) ) :
						foreach ( $term__ as $term_ ) :
							$term_link = get_term_link( $term_ );
                            ?>
                            <li class="nav-item">
                                <a href="<?php echo $term_link ?>" class="nav-link">
									<?php echo $term_->name ?>
                                </a>
                            </li>
						<?php endforeach;
					endif;
					?>
                </ul>
            </div>
        </div>
    </div>
    <!--END-TAG-BAR-->

    <!--START-ARTICLES-->
    <div class="articles latest-theme">
        <div class="container">
            <div class="header-section d-flex align-items-center justify-content-between flex-row">
                <span class="title kalameh right-theme">
                    <span class="lines before">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </span>
                    مقالات مرتبط
                </span>
                <div class="swiper-pagination swiper-pagination-articles"></div>
            </div>

            <div class="swiper-container swiper-articles">
                <div class="swiper-wrapper">
					<?php
					$te = wp_get_post_terms( "category" );
					$args = array(
						"post_type"      => "post",
						"posts_per_page" => 8 ,
					);
                    if(!empty($te)){
	                    $args['tax_query'] = array(
		                    array(
			                    'taxonomy' => 'category',
			                    'terms'    => $te[0]->term_id,
		                    ),
	                    );
                    }
					$the_query = new WP_Query( $args );


					if ( $the_query->have_posts() ) {

						while ( $the_query->have_posts() ) {
							$the_query->the_post();
							?>
                            <a href="<?php echo get_the_permalink() ?>" class="swiper-slide item">
                                <div class="img">
									<?php $image_alt = get_post_meta( get_post_thumbnail_id( get_the_ID() ), '_wp_attachment_image_alt', true ); ?>
                                    <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ?>"
                                         alt="<?php echo $image_alt ?>">
                                </div>
                                <article>
                            <span class="info">
							<?php
							$term___ = wp_get_post_terms( "category" );
							if ( ! empty( $term___ ) ):
								?>
                                <b>دسته بندی</b>
								<?php foreach ( $term___ as $t ) {

								echo $t->name;

							}
							endif; ?>

                                <br class="d-none d-lg-block d-xl-none">
                                <b>در تاریخ</b>
                            <?php
                            echo get_the_date( 'd F Y', get_the_ID() );
                            ?>
                            </span>
                                    <span class="title">
                                        <?php echo get_the_title() ?>
                            </span>
                                </article>
                            </a>
							<?php
						}

					} else {

					}

					wp_reset_postdata();
					?>


                </div>
            </div>
        </div>
    </div>
    <!--END-ARTICLES-->
    <?php if(get_comments_number(get_the_ID())) :  ?>
    <!--START-COMMENT-SECTION-->
    <div class="comment-section">
        <div class="container">
            <div class="header-section d-flex align-items-center justify-content-between flex-row">
                <span class="title kalameh small-theme p-0 ">
                    دیدگاه و نظرات کاربران
                </span>
            </div>

			<?php
			$comment_args  = array(
				'orderby'                   => 'comment_date_gmt',
				'order'                     => 'DESC',
				'status'                    => 'approve',
				'post_id'                   => $post->ID,
				'no_found_rows'             => false,
				'update_comment_meta_cache' => false, // We lazy-load comment meta for performance.
			);
			$comment_query = new WP_Comment_Query( $comment_args );
			$_comments     = $comment_query->comments;


			$comments_flat = array();
			foreach ( $_comments as $_comment ) {
				$comments_flat[]  = $_comment;
				$comment_children = $_comment->get_children(
					array(
						'format'  => 'flat',
						'status'  => $comment_args['status'],
						'orderby' => $comment_args['orderby'],
					)
				);

				foreach ( $comment_children as $comment_child ) {
					$comments_flat[] = $comment_child;
				}
			}


			foreach ( $comments_flat as $comment ) {
				if ( $comment->comment_parent == 0 ) {
					?>

                    <div class="item">
                        <img src="<?php echo DU . '/assets/img/shape.png' ?>" alt="">
                        <div class="w-100">
                            <div class="top-bar">
                        <span class="name">
                            <?php echo $comment->comment_author ?>
                        </span>
                                <span class="date">
                                انتشار در تاریخ
                                       <?php echo get_comment_date( 'D M Y' ); ?>

                        </span>
                                <div class="w-100 d-block d-lg-none"></div>

                                <a onclick="cpmmentReplay(<?php comment_ID() ?>)" class="reply">
                                    <i class="icon-reply"></i>
                                    پاسخ دادن
                                </a>
                            </div>
                            <p class="text">
								<?php echo $comment->comment_content ?>      </p>
                        </div>
                    </div>

					<?php foreach ( $comment->get_children() as $child_cm ) {
						$aouther_id = $child_cm->user_id;

						if ( $aouther_id !== null && $aouther_id !== 0 ) {
							$user_meta = get_userdata( $aouther_id );
							if ( $user_meta ) {
								$user_roles = $user_meta->roles;
							}
						}
						?>

                        <div class="item reply-theme">
                            <img src="<?php echo DU . '/assets/img/shape.png' ?>" alt="">
                            <div class="w-100">
                                <div class="top-bar">
                        <span class="name">
                                 <?php echo $comment->comment_author ?>
                        </span>
                                    <span class="date">
                                انتشار در تاریخ
                                        <?php echo get_comment_date( 'D M Y' ); ?>

                        </span>
                                    <div class="w-100 d-block d-lg-none"></div>

                                    <a onclick="cpmmentReplay(<?php comment_ID() ?>)" class="reply">
                                        <i class="icon-reply"></i>
                                        پاسخ دادن
                                    </a>
                                </div>
                                <p class="text">
									<?php echo $comment->comment_content ?>              </p>
                            </div>
                        </div>
						<?php
					} ?>
				<?php } ?>

			<?php } ?>

        </div>
    </div>
    <!--END-COMMENT-SECTION-->
    <script>
        function cpmmentReplay(commentid) {
            jQuery("#comment_parent").val(commentid)
        }
    </script>
    <?php endif; ?>

    <!--START-FORM-ELEMENTS-->
    <div class="form-elements has-mb">
        <div class="container">
            <div class="header-section d-flex align-items-center justify-content-between flex-row">
                <span class="title kalameh small-theme p-0 ">
                    فرم ارسال دیدگاه و نظرات
                </span>
            </div>
            <form id="comments" action="<?php echo get_home_url() . '/wp-comments-post.php' ?>" method="post">
                <div class="row prl-5px">
                    <div class="col-xl-12 prl-10px">
                        <div class="form-group">
                            <textarea name="comment" required
                                      placeholder="دیدگاه خود را اینجا تایپ کنید . . ."></textarea>
                        </div>
                    </div>
					<?php if ( ! is_user_logged_in() ) {
						?>
                        <div class="col-md-4 prl-10px">
                            <div class="form-group">
                                <input type="text" name="author" required
                                       placeholder="با چه اسمی دیدگاه شما رو منتشر کنیم ؟">
                            </div>
                        </div>
                        <div class="col-md-4 prl-10px">
                            <div class="form-group">
                                <input type="email" name="email" required placeholder="آدرس ایمیل">
                            </div>
                        </div>
						<?php
					} else {

						$current_user = wp_get_current_user();
						?>
                        <div class="col-md-8 prl-10px">
                            <p
                                    class="login-use">شما با نام
                                <span class="cmmnt2">
                                <?php echo $current_user->display_name ?>
                            </span>
                                وارد شدید !

                                <br>
                                <a class="cmmnt2-l" href="<?php echo wp_logout_url() ?>">خارج شوید</a>
                            </p>
                        </div>
						<?php
					}
					?>

                    <div class="col-md-4 prl-10px">

                        <input type="hidden" name="comment_post_ID" value="<?php echo get_the_ID() ?>"
                               id="comment_post_ID">
                        <input type="hidden" name="comment_parent" id="comment_parent" value="0">

                        <button type="submit" form="comments" class="btn btn-submit relative-theme">
                            دیدگاه خود را ارسال کنید
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!--END-FORM-ELEMENTS-->

</main>
<!--END-MAIN-->


<?php get_footer() ?>

</body>
</html>
