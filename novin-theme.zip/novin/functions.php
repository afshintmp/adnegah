<?php
define("DU", get_template_directory_uri());
define("PU", get_template_directory());

add_action('add_meta_boxes', 'jobfinder_register_meta_box');

add_action('save_post', 'jobfinder_post_time_save');

add_action('save_post', 'jobfinder_page_time_save');
add_action('save_post', 'jobfinder_service_time_save');
add_action('save_post', 'jobfinder_companies_time_save');
add_action('save_post', 'jobfinder_our_team_time_save');

add_filter('nav_menu_css_class', 'so_37823371_menu_item_class', 10, 3);

add_filter('nav_menu_link_attributes', 'wpse156165_menu_add_class', 10, 3);

add_action('widgets_init', 'wpdocs_theme_slug_widgets_init');


add_action('category_add_form_fields', 'jobfinder_add_form_field_term_meta_text');
add_action('category_edit_form_fields', 'jobfinder_edit_form_field_term_meta_text');
add_action('edit_category', 'jobfinder_save_term_meta_text');
add_action('create_category', 'jobfinder_save_term_meta_text');
add_action('after_setup_theme', 'my_theme_setup');

add_filter('nav_menu_css_class', 'so_37823371_menu_item_class', 10, 3);
add_filter('nav_menu_link_attributes', 'wpse156165_menu_add_class', 10, 3);


add_action('init', 'custom_post_type', 0);
require_once PU . '/inc/admin-menu.php';

if (!function_exists('jobfinder_register_nav_menu')) {

    function jobfinder_register_nav_menu()
    {
        register_nav_menus(array(
            'top_bar_menu' => __('Top Bar Menu', 'jobfinder'),
            'footer_1' => __('Footer wrapper one', 'jobfinder'),
            'footer_2' => __('Footer wrapper two', 'jobfinder'),
            'footer_3' => __('Footer wrapper three', 'jobfinder'),
        ));
    }

    add_action('after_setup_theme', 'jobfinder_register_nav_menu', 0);
}

function so_37823371_menu_item_class($classes, $item, $args)
{

    $classes[] = 'nav-item';

    return $classes;
}

function wpse156165_menu_add_class($atts, $item, $args)
{
    $class = 'nav-link'; // or something based on $item
    $atts['class'] = $class;

    return $atts;
}


function my_theme_setup()
{
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
//	add_theme_support( 'widgets' );
}

function jobfinder_register_meta_box()
{

    $posts = ['post'];
    foreach ($posts as $post) {

        add_meta_box(
            'post-time-read',
            ' ',
            'jobfinder_post_time_html',
            $post
        );
    }

    $pages = ['page'];
    foreach ($pages as $page) {

        add_meta_box(
            'page-meta-box',
            ' ',
            'jobfinder_page_meta_html',
            $page
        );
    }

    $services = ["services"];
    foreach ($services as $service) {

        add_meta_box(
            'services-meta-box',
            ' ',
            'jobfinder_service_meta_html',
            $service
        );
    }

    $companies = ['companies'];
    foreach ($companies as $company) {

        add_meta_box(
            'companies-meta-box',
            ' ',
            'jobfinder_companies_meta_html',
            $company
        );
    }

    $our_team_prof = ['our-team'];
    foreach ($our_team_prof as $our_team_pro) {

        add_meta_box(
            'companies-meta-box',
            ' ',
            'jobfinder_our_team_meta_html',
            $our_team_pro
        );
    }
}

function jobfinder_our_team_meta_html($post)
{
    $job_tt = get_post_meta($post->ID, 'job-tt', true);
    $inst = get_post_meta($post->ID, 'inst', true);
    $twit = get_post_meta($post->ID, 'twit', true);
    $rez = get_post_meta($post->ID, 'rez', true);
    ?>
    <p>
        <label for="">عنوان شغلی :</label>
        <input id="" type="text" name="job-tt"
               value="<?php echo $job_tt ?>">

    </p>
    <p>
        <label for="">لینک اینستاگرام :</label>
        <input id="" type="text" name="inst"
               value="<?php echo $inst ?>">

    </p>
    <p>
        <label for="">لینک تویتر</label>
        <input id="" type="text" name="twit"
               value="<?php echo $twit ?>">

    </p><p>
    <label for="">لینک رزومه :</label>
    <input id="" type="text" name="rez"
           value="<?php echo $rez ?>">

</p>

    <?php
}

function jobfinder_our_team_time_save($post_id)
{
    if (array_key_exists('job-tt', $_POST)) {
        update_post_meta($post_id, 'job-tt', $_POST['job-tt']);
    }
    if (array_key_exists('inst', $_POST)) {
        update_post_meta($post_id, 'inst', $_POST['inst']);
    }
    if (array_key_exists('twit', $_POST)) {
        update_post_meta($post_id, 'twit', $_POST['twit']);
    }
    if (array_key_exists('rez', $_POST)) {
        update_post_meta($post_id, 'rez', $_POST['rez']);
    }

}

function jobfinder_page_meta_html($post)
{
    $jobfinder_index_select = get_post_meta($post->ID, 'jobfinder-index-select', true);
    ?>
    <p>
        <label for="best">مشاهده در صفحه ی اصلی :</label>
        <input id="best" type="checkbox" name="in-index-selected"
               value="on" <?php echo $jobfinder_index_select == 'on' ? "checked" : "" ?>>

    </p>
    <?php
}

function jobfinder_page_time_save($post_id)
{

    if (array_key_exists('in-index-selected', $_POST)) {
        update_post_meta($post_id, 'jobfinder-index-select', "on");
    } else {
        update_post_meta($post_id, 'jobfinder-index-select', "off");
    }

}

function jobfinder_service_meta_html($post)
{
    $tt = get_post_meta($post->ID, 'tt', true);
    $sub_tt = get_post_meta($post->ID, 'sub-tt', true);
    $tt_icon = get_post_meta($post->ID, 'tt-icon', true);
    $btn_txt = get_post_meta($post->ID, 'btn-txt', true);
    $btn_link = get_post_meta($post->ID, 'btn-link', true);
    ?>
    <p>
        <label for="tt">عنوان تب :</label>
        <input id="tt" type="text" name="tt"
               value="<?php echo $tt ?>">

    </p>
    <p>
        <label for="tt-icon">ایکن تب :</label>
        <input id="tt-icon" type="text" name="tt-icon"
               value="<?php echo $tt_icon ?>">

    </p>

    <p>
        <label for="sub-tt">زیر عنوان محتوا :</label>
        <input id="sub-tt" type="text" name="sub-tt"
               value="<?php echo $sub_tt ?>">

    </p>
    <p>
        <label for="btn-txt">متن دکمه :</label>
        <input id="btn-txt" type="text" name="btn-txt"
               value="<?php echo $btn_txt ?>">

    </p>
    <p>
        <label for="btn-link">لینک دکمه :</label>
        <input id="btn-link" type="text" name="btn-link"
               value="<?php echo $btn_link ?>">

    </p>
    <?php
}

function jobfinder_service_time_save($post_id)
{

    if (array_key_exists('tt', $_POST)) {
        update_post_meta($post_id, 'tt', $_POST['tt']);
    }

    if (array_key_exists('tt-icon', $_POST)) {
        update_post_meta($post_id, 'tt-icon', $_POST['tt-icon']);
    }
    if (array_key_exists('sub-tt', $_POST)) {
        update_post_meta($post_id, 'sub-tt', $_POST['sub-tt']);
    }
    if (array_key_exists('btn-txt', $_POST)) {
        update_post_meta($post_id, 'btn-txt', $_POST['btn-txt']);
    }
    if (array_key_exists('btn-link', $_POST)) {
        update_post_meta($post_id, 'btn-link', $_POST['btn-link']);
    }

}

function jobfinder_companies_meta_html($post)
{
    $companies_url = get_post_meta($post->ID, 'companies-url', true);

    ?>

    <p>
        <label for="companies-url">لینک سایت :</label>

        <input style="width: 100%;display: block" type="url" id="companies-url" name="companies-url"
               value="<?php echo $companies_url ?>">
    </p>

    <?php

}

function jobfinder_companies_time_save($post_id)
{
    if (array_key_exists('companies-url', $_POST)) {
        update_post_meta($post_id, 'companies-url', $_POST['companies-url']);
    }

}

function jobfinder_post_time_html($post)
{
    $jobfinder_post_time = get_post_meta($post->ID, 'jobfinder-post-time', true);
    $jobfinder_post_selected = get_post_meta($post->ID, 'jobfinder-post-selected', true);
    $jobfinder_slider_selected = get_post_meta($post->ID, 'jobfinder-slider-selected', true);
    $sliderone = get_post_meta($post->ID, 'jobfinder-post-list', true);
    ?>
    <p>
    <h1 style="margin-right: 25px;">فهرست مقاله</h1>
    <?php
    $settings = array('media_buttons' => false);


    $editor_id = 'sliderone';
    $content = $sliderone;
    wp_editor($content, $editor_id, $settings);
    ?>
    </p>
    <p>
        <label for="time">زمان :</label>
        <input id="time" type="url" name="post-read-time" value="<?php echo $jobfinder_post_time ?>">
        <span>(دقیقه)</span>
    </p>
    <p>
        <label for="best">مقالات منتخب (پیشنهاد سردبیر) :</label>
        <input id="best" type="checkbox" name="post-selected"
               value="on" <?php echo $jobfinder_post_selected == 'on' ? "checked" : "" ?>>

    </p>
    <p>
        <label for="best">نمایش در اسلایدر :</label>
        <input id="best" type="checkbox" name="slider-selected"
               value="on" <?php echo $jobfinder_slider_selected == 'on' ? "checked" : "" ?>>

    </p>
    <?php

}

function jobfinder_post_time_save($post_id)
{
    if (array_key_exists('post-read-time', $_POST)) {
        update_post_meta($post_id, 'jobfinder-post-time', $_POST['post-read-time']);
    }
    if (array_key_exists('post-selected', $_POST)) {
        update_post_meta($post_id, 'jobfinder-post-selected', "on");
    } else {
        update_post_meta($post_id, 'jobfinder-post-selected', "off");
    }
    if (array_key_exists('slider-selected', $_POST)) {
        update_post_meta($post_id, 'jobfinder-slider-selected', "on");
    } else {
        update_post_meta($post_id, 'jobfinder-slider-selected', "off");
    }
    if (array_key_exists('sliderone', $_POST)) {
        update_post_meta($post_id, 'jobfinder-post-list', $_POST['sliderone']);
    }
}

function wpdocs_theme_slug_widgets_init()
{
    register_sidebar(array(
        'name' => "تاب بار",
        'id' => 'top-menu',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
    register_sidebar(array(
        'name' => "تماس با ما",
        'id' => 'connect-us',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
    register_sidebar(array(
        'name' => "خبرنامه",
        'id' => 'newslatter',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));


    register_sidebar(array(
        'name' => "فوتر جایگاه یک",
        'id' => 'footer-1',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
    register_sidebar(array(
        'name' => "فوتر جایگاه دو",
        'id' => 'footer-2',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
    register_sidebar(array(
        'name' => "فوتر جایگاه سه",
        'id' => 'footer-3',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));


    register_sidebar(array(
        'name' => "متن فوتر ",
        'id' => 'txt-footer-1',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
    register_sidebar(array(
        'name' => "متن کپی رایت",
        'id' => 'txt-footer',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
    register_sidebar(array(
        'name' => "نماد اعتماد یک",
        'id' => 'enamed-1',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
    register_sidebar(array(
        'name' => "نماد اعتماد دو",
        'id' => 'enamed-2',
        'description' => '',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));

}


function ___get_landing_term_meta_text($term_id)
{
    $value = get_term_meta($term_id, 'landing', true);


    return $value;
}

function jobfinder_add_form_field_term_meta_text()
{ ?>
    <style>
        .w-100 {
            width: 100% !important;
        }
    </style>

    <div class="font-bold" style="margin-bottom: 15px;">
        <label for="term-meta-text">لینک ایکن :</label>

        <input type="text" style="width: 100%;" name="landing"
               value=""/>

    </div>
<?php }

function jobfinder_edit_form_field_term_meta_text($term)
{


    $landing_value = ___get_landing_term_meta_text($term->term_id);
    if (!$landing_value) {
        $landing_value = "";
    }

    ?>

    <tr class="form-field term-meta-text-wrap">
        <th scope="row">

            <label for="term-meta-text">
                لینک ایکن :
            </label>

        </th>
        <td>
            <?php wp_nonce_field(basename(__FILE__), 'term_meta_text_nonce'); ?>


            <div>
                <input type="text" name="landing"
                       value="<?php echo !empty($landing_value) ? $landing_value : '' ?>"/>
            </div>
        </td>
    </tr>


<?php }


function jobfinder_save_term_meta_text($term_id)
{

    // verify the nonce --- remove if you don't care
    if (!isset($_POST['term_meta_text_nonce']) || !wp_verify_nonce($_POST['term_meta_text_nonce'], basename(__FILE__))) {
        return;
    }

    $old_landing_value = ___get_landing_term_meta_text($term_id);
    $new_landing_value = isset($_POST['landing']) ? ($_POST['landing']) : '';

    if ($old_landing_value && '' === $new_landing_value) {
        delete_term_meta($term_id, 'landing');
    } else if ($old_landing_value !== $new_landing_value) {
        update_term_meta($term_id, 'landing', $new_landing_value);
    }
}


function custom_post_type()
{


    $labels = array(
        'name' => 'خدمات ما',
        'singular_name' => 'خدمات ما',
        'menu_name' => 'خدمات ما',
        'parent_item_colon' => 'والد',
        'all_items' => 'همه',
        'view_item' => 'مشاهده',
        'add_new_item' => 'افزودن',
        'add_new' => 'افزودن',
        'edit_item' => 'ویرایش',
        'update_item' => 'بروزرسانی',
        'search_items' => 'جستجو',
        'not_found' => 'یافت نشد',
        'not_found_in_trash' => 'یافت نشد',
    );


    $args = array(
        'label' => 'services',
        'description' => '',
        'labels' => $labels,

        'supports' => array('title', 'editor', 'thumbnail'),

        'taxonomies' => array('genres'),

        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => true,

    );


    register_post_type('services', $args);


    $labels_companies = array(
        'name' => 'همکاران ما',
        'singular_name' => 'همکاران ما',
        'menu_name' => 'همکاران ما',
        'parent_item_colon' => 'والد',
        'all_items' => 'همه',
        'view_item' => 'مشاهده',
        'add_new_item' => 'افزودن',
        'add_new' => 'افزودن',
        'edit_item' => 'ویرایش',
        'update_item' => 'بروزرسانی',
        'search_items' => 'جستجو',
        'not_found' => 'یافت نشد',
        'not_found_in_trash' => 'یافت نشد',
    );


    $args_companies = array(
        'label' => 'companies',
        'description' => '',
        'labels' => $labels_companies,

        'supports' => array('title', 'thumbnail'),

        'taxonomies' => array('genres'),

        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => true,

    );


    register_post_type('companies', $args_companies);


    $our_team_label = array(
        'name' => 'تیم ما',
        'singular_name' => 'تیم ما',
        'menu_name' => 'تیم ما',
        'parent_item_colon' => 'والد',
        'all_items' => 'همه',
        'view_item' => 'مشاهده',
        'add_new_item' => 'افزودن',
        'add_new' => 'افزودن',
        'edit_item' => 'ویرایش',
        'update_item' => 'بروزرسانی',
        'search_items' => 'جستجو',
        'not_found' => 'یافت نشد',
        'not_found_in_trash' => 'یافت نشد',
    );


    $our_team = array(
        'label' => 'our-team',
        'description' => '',
        'labels' => $our_team_label,

        'supports' => array('title', 'thumbnail'),

        'taxonomies' => array('genres'),

        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => true,

    );


    register_post_type('our-team', $our_team);

}
function wpbeginner_numeric_posts_nav() {

	

	global $wp_query;

	/** Stop execution if there's only 1 page */
	if( $wp_query->max_num_pages <= 1 )
		return;

	$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
	$max   = intval( $wp_query->max_num_pages );

	/** Add current page to the array */
	if ( $paged >= 1 )
		$links[] = $paged;

	/** Add the pages around the current page to the array */
	if ( $paged >= 3 ) {
		$links[] = $paged - 1;
		$links[] = $paged - 2;
	}

	if ( ( $paged + 2 ) <= $max ) {
		$links[] = $paged + 2;
		$links[] = $paged + 1;
	}

	echo '<div class="navigation"><ul>' . "\n";

	/** Previous Post Link */
	if ( get_previous_posts_link() )
		printf( '<li>%s</li>' . "\n", get_previous_posts_link() );

	/** Link to first page, plus ellipses if necessary */
	if ( ! in_array( 1, $links ) ) {
		$class = 1 == $paged ? ' class="active"' : '';

		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

		if ( ! in_array( 2, $links ) )
			echo '<li>…</li>';
	}

	/** Link to current page, plus 2 pages in either direction if necessary */
	sort( $links );
	foreach ( (array) $links as $link ) {
		$class = $paged == $link ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
	}

	/** Link to last page, plus ellipses if necessary */
	if ( ! in_array( $max, $links ) ) {
		if ( ! in_array( $max - 1, $links ) )
			echo '<li>…</li>' . "\n";

		$class = $paged == $max ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
	}

	/** Next Post Link */
	if ( get_next_posts_link() )
		printf( '<li>%s</li>' . "\n", get_next_posts_link() );

	echo '</ul></div>' . "\n";

}