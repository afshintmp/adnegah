<?php

/* Template Name: تماس با ما */
get_header();
global $options;
$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

?>
<body>

<?php get_template_part("partials/page-top-bar-menu") ?>



<!--START-MAIN-->
<main>
    <!--START-CONTACT-US-->
    <div class="contact-us">
        <div class="container p-0 d-flex flex-wrap">
            <div class="col-lg-6">
                <?php
                the_content();
                ?>
            </div>
            <?php
            $contact_form_id = get_option('cfi');


            ?>
            <div class="col-lg-6">
                <?php echo do_shortcode('[contact-form-7 id="'.$contact_form_id.'" title="تماس با ما - تماس با ما"]')?>

            </div>
        </div>
    </div>
    <!--END-CONTACT-US-->
</main>
<!--END-MAIN-->


<?php get_footer() ?>

</body>
</html>
