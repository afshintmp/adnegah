<?php

/* Template Name: api */
get_header();
$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

?>
<body>

<?php get_template_part("partials/top-bar-menu") ?>

<!--START-MAIN-->
<main>

    <div class="container">
        <div class="col-12">
            <?php
            $response = wp_remote_get('https://panel.novinpardakht.com/api/v1/currencies');
            $body = json_decode(wp_remote_retrieve_body($response));


            //            var_dump(json_decode($body, true));


            foreach ($body as $bo):
                echo "<pre>";
                var_dump($bo);
                echo "</pre>";
            endforeach;


            ?>
        </div>

    </div>
</main>
<!--END-MAIN-->


<?php get_footer() ?>

</body>
</html>
