$('.js-example-basic-single').select2({
    dir:'rtl',
});

$('.btn-menu').click(function () {
    $('.menu-mobile').fadeIn()
})
$('.menu-mobile .btn-close').click(function () {
    $('.menu-mobile').fadeOut()
})

$('.nav-social-footer .nav-item').hover(function () {
    $('.nav-item').removeClass('active')
    $(this).addClass('active')
})


// clicking button with class "category-button"
$(".tab-item").click(function(){
    // get the data-filter value of the button
    var filterValue = $(this).attr('data-filter');

    $('.filter-item').not('.'+filterValue).hide();
    $('.filter-item').filter('.'+filterValue).show();

    $(this).parent().find('.active').removeClass('active')
    $(this).addClass('active');
});

// clicking button with class "category-button"
$(".tab-item-1").click(function(){
    // get the data-filter value of the button
    var filterValue = $(this).attr('data-filter');

    $('.filter-item-1').not('.'+filterValue).hide();
    $('.filter-item-1').filter('.'+filterValue).show();

    $(this).parent().find('.active').removeClass('active')
    $(this).addClass('active');
});

$(".tab-item-2").click(function(){
    // get the data-filter value of the button
    var filterValue = $(this).attr('data-filter');

    $('.filter-item-2').not('.'+filterValue).hide();
    $('.filter-item-2').filter('.'+filterValue).show();

    $(this).parent().find('.active').removeClass('active')
    $(this).addClass('active');
});



$(function() {
    var Accordion = function(el, multiple) {
        this.el = el || {};
        // more then one submenu open?
        this.multiple = multiple || false;

        var dropdownlink = this.el.find('.dropdownlink');
        dropdownlink.on('click',
            { el: this.el, multiple: this.multiple },
            this.dropdown);
    };

    Accordion.prototype.dropdown = function(e) {
        var $el = e.data.el,
            $this = $(this),
            //this is the ul.submenuItems
            $next = $this.next();

        $next.slideToggle();
        $this.parent().toggleClass('active');

        if(!e.data.multiple) {
            //show only one menu at the same time
            $el.find('.submenu').not($next).slideUp().parent().removeClass('active');
        }
    }

    var accordion = new Accordion($('.accordion-menu'), false);
})



var swipermainslide = new Swiper('.swiper-main-slide', {
    slidesPerView: 7,
    spaceBetween: 10,
    pagination: {
        el: '.swiper-pagination-main-slide',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-main-slide',
        prevEl: '.swiper-button-prev-main-slide',
    },
    breakpoints: {
        992: {
            spaceBetween: 10,
            freeMode:true,
            slidesPerView: 'auto',
        },
    },

});





var swipertab = new Swiper('.swiper-tab', {
    spaceBetween: 0,
    slidesPerView: 1,
    pagination: {
        el: '.swiper-pagination-tab',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-tab',
        prevEl: '.swiper-button-prev-tab',
    },
    /*
    breakpoints: {
        992 : {
            spaceBetween: 15,
            slidesPerView: 2,
        },
    }
    */
});
$('.tab-section .nav-item').click(function (){
    swipertab.update()
})



var swipertestimonial = new Swiper('.swiper-testimonial', {
    slidesPerView: 2,
    spaceBetween: 25,
    slidesPerGroup: 2,
    pagination: {
        el: '.swiper-pagination-testimonial',
        // type: 'progressbar',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-testimonial',
        prevEl: '.swiper-button-prev-testimonial',
    },
    breakpoints: {
        992: {
            spaceBetween: 10,
            freeMode: true,
            slidesPerView: 'auto',
        },
    }
});

var swiperbrands = new Swiper('.swiper-brands', {
    spaceBetween: 10,
    freeMode: true,
    slidesPerView: 'auto',
    pagination: {
        el: '.swiper-pagination-brands',
        // type: 'progressbar',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-brands',
        prevEl: '.swiper-button-prev-brands',
    },
});

var swiperarticles = new Swiper('.swiper-articles', {
    slidesPerView: 2,
    spaceBetween: 20,
    pagination: {
        el: '.swiper-pagination-articles',
        // type: 'progressbar',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-articles',
        prevEl: '.swiper-button-prev-articles',
    },
    breakpoints: {
        992: {
            spaceBetween: 10,
            freeMode: true,
            slidesPerView: 'auto',
        },
    }
});

var swiperteam = new Swiper('.swiper-team', {
    slidesPerView: 2,
    spaceBetween: 20,
    loop:true,
    pagination: {
        el: '.swiper-pagination-team',
        // type: 'progressbar',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-team',
        prevEl: '.swiper-button-prev-team',
    },
    breakpoints: {
        992: {
            spaceBetween: 10,
            freeMode: true,
            slidesPerView: 'auto',
        },
    }
});


var swipermainslide1 = new Swiper('.swiper-main-1', {
    slidesPerView: 1,
    spaceBetween: 10,
    pagination: {
        el: '.swiper-pagination-main-1',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-main-1',
        prevEl: '.swiper-button-prev-main-1',
    },

});


var swiperblog1 = new Swiper('.swiper-blog-1', {
    slidesPerView: 3,
    spaceBetween: 20,
    pagination: {
        el: '.swiper-pagination-blog-1',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-blog-1',
        prevEl: '.swiper-button-prev-blog-1',
    },
    breakpoints: {
        450: {
            slidesPerView: 1,
        },
        992: {
            slidesPerView: 2,
        },
    }
});

var swiperblog2 = new Swiper('.swiper-blog-2', {
    slidesPerView: 3,
    spaceBetween: 20,
    pagination: {
        el: '.swiper-pagination-blog-2',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-blog-2',
        prevEl: '.swiper-button-prev-blog-2',
    },
    breakpoints: {
        450: {
            slidesPerView: 1,
        },
        992: {
            slidesPerView: 2,
        },
    }
});

var swiperlan2 = new Swiper('.swiper-lan-2', {
    slidesPerView: 3,
    spaceBetween: 20,
    pagination: {
        el: '.swiper-pagination-lan-2',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-lan-2',
        prevEl: '.swiper-button-prev-lan-2',
    },
    breakpoints: {
        992: {
            spaceBetween: 10,
            freeMode: true,
            slidesPerView: 'auto',
        },
    }
});
var swiperlan3 = new Swiper('.swiper-lan-3', {
    slidesPerView: 3,
    spaceBetween: 20,
    centeredSlides:true,
    loop: true,
    pagination: {
        el: '.swiper-pagination-lan-3',
        clickable:true,
    },
    navigation: {
        nextEl: '.swiper-button-next-lan-3',
        prevEl: '.swiper-button-prev-lan-3',
    },
    breakpoints: {
        992: {
            centeredSlides:false,
            loop: false,
            spaceBetween: 10,
            freeMode: true,
            slidesPerView: 'auto',
        },
    }
});