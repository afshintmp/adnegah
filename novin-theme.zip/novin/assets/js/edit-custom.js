
// top bar menu

var $ = jQuery
$('.menu-item-has-children').hover(function () {

    $(this).addClass('active')
    $(this).children('.sub-menu').stop(true, true).delay(50).slideDown(400);
}, function () {
    $(this).removeClass('active')
    $(this).children('.sub-menu').stop(true, true).delay(50).slideUp(400);
});




// end off top bar menu



$('.show-more-text').click(function () {
    $(this).parent().find('.text').toggleClass('show')
    $(this).find('span').toggle()
    $(this).toggleClass('active')
})

if (window.innerWidth > 1200) {
    swipermainslide.destroy();
}

$('.call-fix .btn-show').click(function () {
    $('.call-fix .drop').slideDown()
})
$('.call-fix .btn-close').click(function () {
    $('.call-fix .drop').slideUp()
})

var vid1 = document.getElementById("video1");

function playVid1() {
    vid1.play()
}

function pauseVid1() {
    vid1.pause()
}

jQuery('.play-vid').click(function () {
    jQuery(this).parent().find('.main-video').show();
})
jQuery('.main-video .btn-close').click(function () {
    jQuery(this).parent().parent().find('.main-video').hide();
})
