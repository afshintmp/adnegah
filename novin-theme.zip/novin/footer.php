<!--START-FOOTER-->
<footer class="footer">
	<?php if ( is_active_sidebar( 'connect-us' ) ) { ?>
		<?php dynamic_sidebar( 'connect-us' ); ?>
	<?php } ?>
    


	<?php if ( is_active_sidebar( 'newslatter' ) ) { ?>
		<?php dynamic_sidebar( 'newslatter' ); ?>
	<?php } ?>


    <div class="main-bar">
        <div class="container p-0 d-flex justify-content-start justify-content-lg-between flex-wrap">
            <div class="col-xl-4 col-lg-5 col-12">
				<?php if ( is_active_sidebar( 'footer-1' ) ) { ?>

					<?php dynamic_sidebar( 'footer-1' ); ?>

				<?php } ?>

            </div>
            <div class="col-sm-auto">
				<?php if ( is_active_sidebar( 'footer-2' ) ) { ?>

					<?php dynamic_sidebar( 'footer-2' ); ?>

				<?php } ?>

            </div>
            <div class="col-sm-auto">
				<?php if ( is_active_sidebar( 'footer-3' ) ) { ?>

					<?php dynamic_sidebar( 'footer-3' ); ?>

				<?php } ?>

            </div>
        </div>
    </div>
    <div class="bottom-bar">
        <div class="container p-0 d-flex align-items-center flex-wrap">
            <div class="col-xl-8">
                <a href="" class="brand">
                    <img src="<?php echo DU . '/assets/img/logo.png' ?> " alt="">
                </a>
				<?php if ( is_active_sidebar( 'txt-footer-1' ) ) { ?>

					<?php dynamic_sidebar( 'txt-footer-1' ); ?>

				<?php } ?>
                <!--                <p class="text">-->
                <!--                    نوین پرداخت توسط باسابقه ترین و مجرب ترین افراد در حوزه پرداخت های بین المللی تشکیل شده است. با سابقه ترین و با تجربه ترین افراد در زمینه ی پرداخت های بین المللی با پیش زمینه تشکیل چندین استارتاپ موفق در یک دهه ی اخیر، گرد هم آمده اند تا کمبودهای موجود در حوزه پرداخت های ارزی آنلاین را برطرف کنند.-->
                <!--                </p>-->
            </div>
            <div class="col-xl-4">
                <ul class="nav nav-namad">

					<?php if ( is_active_sidebar( 'enamed-1' ) ) { ?>
                        <li class="nav-item">
							<?php dynamic_sidebar( 'enamed-1' ); ?>
                        </li>
					<?php } ?>
					<?php if ( is_active_sidebar( 'enamed-2' ) ) { ?>
                        <li class="nav-item">
							<?php dynamic_sidebar( 'enamed-2' ); ?>
                        </li>
					<?php } ?>


                </ul>
            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="container">

			<?php if ( is_active_sidebar( 'txt-footer' ) ) { ?>

				<?php dynamic_sidebar( 'txt-footer' ); ?>

			<?php } ?>

        </div>
    </div>
</footer>
<!--END-FOOTER-->


<?php wp_footer(); ?>
<script src="<?php echo DU . '/assets/js/jquery-3.3.1.min.js' ?>"></script>
<script src="<?php echo DU . '/assets/js/Bootstrap/bootstrap.bundle.min.js' ?>"></script>
<script src="<?php echo DU . '/assets/js/swiper/swiper.min.js' ?>"></script>
<script src="<?php echo DU . '/assets/js/Select2/select2.min.js' ?>"></script>
<script src="<?php echo DU . '/assets/js/custom.js' ?>"></script>
<script src="<?php echo DU . '/assets/js/edit-custom.js' ?>"></script>
