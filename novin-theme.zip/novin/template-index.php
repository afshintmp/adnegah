<?php

/* Template Name: پیج خام */
get_header();
$url = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

?>
<body>

<?php get_template_part( "partials/top-bar-menu" ) ?>

<!--START-MAIN-->
<main>
	<?php the_content(); ?>
</main>
<!--END-MAIN-->


<?php get_footer() ?>

</body>
</html>
