<?php
global $options;
$logo_img = get_option('logo-img');
$p_num = get_option('p-num', false);
$telegram = get_option('telegram', false);
$whatsapp = get_option('whatsapp', false);
?>
<!--START-CALL-FIX-->

<div class="call-fix">
    <div class="drop">
        <?php if (!empty($p_num)) : ?>
            <a href="<?php echo 'tel:' . $p_num ?>" class="call">
            <span>
                <span class="kalameh">
                    تماس تلفنی
                </span>
            <?php echo $p_num ?>
            </span>
                <div class="icon">
                    <i class="icon-whatsapp"></i>
                </div>
            </a>
        <?php endif; ?>
        <?php if (!empty($telegram)) : ?>
            <a href="<?php echo 'https://telegram.me/' . $telegram ?>" class="call telegram">
            <span>
                <span class="kalameh">
                    پشتیبانی تلگرام
                </span>
            <?php echo $telegram ?>
            </span>
                <div class="icon">
                    <i class="icon-telegram2"></i>
                </div>
            </a>
        <?php endif; ?>
        <div class="btn btn-close">
            <i class="icon-multiply"></i>
        </div>
    </div>
    <div class="btn btn-show">
        <i class="icon-telephone-call"></i>
    </div>
</div>
<!--END-CALL-FIX-->


<!--START-MENU-MOBILE-->
<div class="menu-mobile">
	<div class="main-menu">
		<div class="top-bar">
			<a href="" class="brand">
				<img src="<?php echo ! empty( $logo_img ) ? $logo_img : DU . '/assets/img/Logo.png' ?>"
				     alt="<?php bloginfo( 'name' ); ?>">
			</a>
			<button class="btn btn-close">
				<i class="icon-close"></i>
			</button>
		</div>
		<div class="line"></div>
		<?php
		wp_nav_menu( array(
			'theme_location' => 'top_bar_menu',
			'container'      => "ul",
			'menu_class'     => "nav"
		) );
		?>

	</div>
</div>
<!--END-MENU-MOBILE-->

<!--START-HEADER-->
<header class="header">
<div class="top-bar">
        <div class="container d-flex align-items-center">
            <a href="<?php echo home_url() ?>" class="brand">
                <img src="<?php echo !empty($logo_img) ? $logo_img : DU . '/assets/img/Logo.png' ?>"
                     alt="<?php bloginfo('name'); ?>">
            </a>
           <?php if (!empty( $p_num )) :?>
            <a href="<?php echo 'tel:' . $p_num  ?>" class="support d-lg-flex d-none">
                <?php echo $p_num ?>
                <i class="icon-headphones">
                    <span class="path1"></span>
                    <span class="path2"></span>
                    <span class="path3"></span>
                </i>
            </a>
            <?php endif; ?>
            <ul class="nav">

                <?php if ( is_active_sidebar( 'top-menu' ) ) { ?>
                    <?php dynamic_sidebar( 'top-menu' ); ?>
                <?php } ?>

            </ul>
        </div>
    </div>
    <div class="bottom-bar">
        <div class="container d-lg-block d-flex align-items-center justify-content-between">
            <button class="btn btn-menu d-lg-none d-flex">
                <i class="icon-menu"></i>
                مشاهده منو
            </button>
          
            <?php
            wp_nav_menu(array(
                'theme_location' => 'top_bar_menu',
                'container' => "ul",
                'menu_class' => "nav d-lg-flex d-none"
            ));
            ?>
            <script>

            </script>
            <a href="" class="support d-lg-none d-flex">
                <?php echo $p_num ?>
                <i class="icon-headphones1"></i>
            </a>
        </div>
    </div>
	<div class="bread-crumb">
		<div class="container d-flex align-items-center justify-content-between flex-wrap">
			<h1 class="title">
			<?php echo get_the_title();?>
			</h1>
			<ul class="nav">
				<li class="nav-item">
					<a href="<?php get_home_url()?>" class="nav-link"> 
						صفحه نخست
					</a>
				</li>
				<li class="nav-item">
					<a href="" class="nav-link">
					<?php echo get_the_title() ?>
					</a>
				</li>
			</ul>
		</div>
	</div>
</header>
<!--END-HEADER-->


